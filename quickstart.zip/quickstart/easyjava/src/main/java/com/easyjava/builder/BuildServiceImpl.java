package com.easyjava.builder;

import com.easyjava.bean.Constants;
import com.easyjava.bean.FieldInfo;
import com.easyjava.bean.TableInfo;
import com.easyjava.utils.StringTools;

import java.io.*;
import java.util.List;
import java.util.Map;

public class BuildServiceImpl {

    public static void execute(TableInfo tableInfo) {

        File folder = new File(Constants.PATH_SERVICE_IMPL);
        if (!folder.exists()) {
            folder.mkdirs();
        }
        File beanFile = new File(Constants.PATH_SERVICE_IMPL, tableInfo.getBeanName() + Constants.SUFFIX_SERVICE_IMPL + ".java");
        OutputStream out = null;
        OutputStreamWriter outw = null;
        BufferedWriter bw = null;

        try {
            out = new FileOutputStream(beanFile);
            outw = new OutputStreamWriter(out, "utf-8");
            bw = new BufferedWriter(outw);
            bw.write("package " + Constants.PACKAGE_SERVICE_IMPL + ";");
            bw.newLine();
            bw.newLine();
            bw.write("import java.util.List;");
            bw.newLine();
            bw.newLine();
            if (Constants.SPRINGBOOT_VERSION == 2) {
                bw.write("import javax.annotation.Resource;");
            } else {
                bw.write("import jakarta.annotation.Resource;");
            }

            bw.newLine();
            bw.newLine();
            bw.write("import org.springframework.stereotype.Service;");
            bw.newLine();
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_ENUMS + ".PageSize;");
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_PARAM + "." + tableInfo.getBeanParamName() + ";");
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_BEAN + "." + tableInfo.getBeanName() + ";");
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_VO + ".PaginationResultVO;");
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_PARAM + ".SimplePage;");

            bw.newLine();
            bw.write("import " + Constants.PACKAGE_MAPPER + "." + tableInfo.getBeanName() + Constants.SUFFIX_MAPPER + ";");
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_SERVICE + "." + tableInfo.getBeanName() + Constants.SUFFIX_SERVICE + ";");
            bw.newLine();
            bw.write("import " + Constants.PACKAGE_UTILS + ".StringTools;");
            bw.newLine();

            bw = BuildComment.buildClassComment(bw, tableInfo.getComment() + " 业务接口实现");
            bw.newLine();
            String anServiceBean = tableInfo.getBeanName() + Constants.SUFFIX_SERVICE;
            anServiceBean = anServiceBean.substring(0, 1).toLowerCase() + anServiceBean.substring(1);
            bw.write("@Service(\"" + anServiceBean + "\")");
            bw.newLine();
            bw.write("public class " + tableInfo.getBeanName() + Constants.SUFFIX_SERVICE_IMPL + " implements " + tableInfo.getBeanName() + Constants.SUFFIX_SERVICE +
                    " {");
            bw.newLine();
            bw.newLine();
            bw.write("\t@Resource");
            bw.newLine();

            String beanName = tableInfo.getBeanName();
            String paramMapper = beanName + Constants.SUFFIX_MAPPER;
            paramMapper = paramMapper.substring(0, 1).toLowerCase() + paramMapper.substring(1);
            bw.write("\tprivate " + tableInfo.getBeanName() + Constants.SUFFIX_MAPPER + "<" + tableInfo.getBeanName() + ", " + tableInfo.getBeanParamName() + "> " + paramMapper + ";");
            bw.newLine();

            String tableNameParam = "";
            String tableNameParamName = "";
            Boolean splitTable = Constants.TABLE_SPLIT.contains(tableInfo.getSourceTableName());
            if (splitTable) {
                tableNameParam = "String tableName,";
                tableNameParamName = "tableName,";
            }


            //根据条件查询列表
            bw = BuildComment.buildMethodComment(bw, "根据条件查询列表");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic List<" + beanName + "> findListByParam(" + tableNameParam + tableInfo.getBeanParamName() + " param) {");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".selectList(" + tableNameParamName + "param);");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //根据条件查询记录数
            bw = BuildComment.buildMethodComment(bw, "根据条件查询列表");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic Integer findCountByParam(" + tableNameParam + tableInfo.getBeanParamName() + " param) {");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".selectCount(" + tableNameParamName + "param);");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //分页查询的方法
            bw = BuildComment.buildMethodComment(bw, "分页查询方法");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic PaginationResultVO<" + beanName + "> findListByPage(" + tableNameParam + tableInfo.getBeanParamName() + " param) {");
            bw.newLine();
            bw.write("\t\tint count = this.findCountByParam(" + tableNameParamName + "param);");
            bw.newLine();
            bw.write("\t\tint pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();");
            bw.newLine();
            bw.newLine();
            bw.write("\t\tSimplePage page = new SimplePage(param.getPageNo(), count, pageSize);");
            bw.newLine();
            bw.write("\t\tparam.setSimplePage(page);");
            bw.newLine();
            bw.write("\t\tList<" + beanName + "> list = this.findListByParam(" + tableNameParamName + "param);");
            bw.newLine();
            bw.write("\t\tPaginationResultVO<" + beanName + "> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);");
            bw.newLine();
            bw.write("\t\treturn result;");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //新增
            bw = BuildComment.buildMethodComment(bw, "新增");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic Integer add(" + tableNameParam + tableInfo.getBeanName() + " bean) {");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".insert(" + tableNameParamName + "bean);");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //批量新增
            bw = BuildComment.buildMethodComment(bw, "批量新增");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic Integer addBatch(" + tableNameParam + "List<" + tableInfo.getBeanName() + "> listBean) {");
            bw.newLine();
            bw.write("\t\tif (listBean == null || listBean.isEmpty()) {");
            bw.newLine();
            bw.write("\t\t\treturn 0;");
            bw.newLine();
            bw.write("\t\t}");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".insertBatch(" + tableNameParamName + "listBean);");

            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //批量新增
            bw = BuildComment.buildMethodComment(bw, "批量新增或者修改");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic Integer addOrUpdateBatch(" + tableNameParam + "List<" + tableInfo.getBeanName() + "> listBean) {");
            bw.newLine();
            bw.write("\t\tif (listBean == null || listBean.isEmpty()) {");
            bw.newLine();
            bw.write("\t\t\treturn 0;");
            bw.newLine();
            bw.write("\t\t}");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".insertOrUpdateBatch(" + tableNameParamName + "listBean);");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //多条件更新
            bw = BuildComment.buildMethodComment(bw, "多条件更新");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic Integer updateByParam(" + tableNameParam + tableInfo.getBeanName() + " bean, " + tableInfo.getBeanParamName() + " param) {");
            bw.newLine();
            bw.write("\t\tStringTools.checkParam(param);");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".updateByParam(" + tableNameParamName + "bean, param);");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            //多条件删除
            bw = BuildComment.buildMethodComment(bw, "多条件删除");
            bw.newLine();
            bw.write("\t@Override");
            bw.newLine();
            bw.write("\tpublic Integer deleteByParam(" + tableNameParam + tableInfo.getBeanParamName() + " param) {");
            bw.newLine();
            bw.write("\t\tStringTools.checkParam(param);");
            bw.newLine();
            bw.write("\t\treturn this." + paramMapper + ".deleteByParam(" + tableNameParamName + "param);");
            bw.newLine();
            bw.write("\t}");
            bw.newLine();

            Map<String, List<FieldInfo>> keyMap = tableInfo.getKeyIndexMap();
            for (Map.Entry<String, List<FieldInfo>> entry : keyMap.entrySet()) {
                List<FieldInfo> keyColumnList = entry.getValue();
                StringBuffer paramStr = new StringBuffer();
                StringBuffer paramValueStr = new StringBuffer();
                StringBuffer methodName = new StringBuffer();
                int index = 0;
                for (FieldInfo column : keyColumnList) {
                    if (index > 0) {
                        paramStr.append(", ");
                        methodName.append("And");
                        paramValueStr.append(", ");
                    }
                    paramStr.append(column.getJavaType() + " " + column.getPropertyName());
                    paramValueStr.append(column.getPropertyName());
                    methodName.append(StringTools.upperCaseFirstLetter(column.getPropertyName()));
                    index++;
                }
                if (paramStr.length() > 0) {
                    //根据主键查询
                    BuildComment.buildMethodComment(bw, "根据" + methodName + "获取对象");
                    bw.newLine();
                    bw.write("\t@Override");
                    bw.newLine();
                    bw.write("\tpublic " + tableInfo.getBeanName() + " get" + tableInfo.getBeanName() + "By" + methodName.toString() + "(" + tableNameParam + paramStr.toString() + ") {");
                    bw.newLine();
                    bw.write("\t\treturn this." + paramMapper + ".selectBy" + methodName.toString() + "(" + tableNameParamName + paramValueStr.toString() + ");");

                    bw.newLine();
                    bw.write("\t}");
                    bw.newLine();


                    //根据主键修改
                    bw = BuildComment.buildMethodComment(bw, "根据" + methodName + "修改");
                    bw.newLine();
                    bw.write("\t@Override");
                    bw.newLine();
                    bw.write("\tpublic Integer update" + tableInfo.getBeanName() + "By" + methodName.toString() + "(" + tableNameParam + tableInfo.getBeanName() + " " +
                            "bean, " + paramStr.toString() +
                            ") {");
                    bw.newLine();
                    bw.write("\t\treturn this." + paramMapper + ".updateBy" + methodName.toString() + "(" + tableNameParamName + "bean, " + paramValueStr.toString() +
                            ");");


                    bw.newLine();
                    bw.write("\t}");
                    bw.newLine();


                    //根据主键删除
                    bw = BuildComment.buildMethodComment(bw, "根据" + methodName + "删除");
                    bw.newLine();
                    bw.write("\t@Override");
                    bw.newLine();
                    bw.write("\tpublic Integer delete" + tableInfo.getBeanName() + "By" + methodName.toString() + "(" + tableNameParam + paramStr.toString() + ") {");
                    bw.newLine();
                    bw.write("\t\treturn this." + paramMapper + ".deleteBy" + methodName.toString() + "(" + tableNameParamName + paramValueStr.toString() + ");");

                    bw.newLine();
                    bw.write("\t}");
                    bw.newLine();
                }
            }

            bw.write("}");
            bw.flush();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (null != out) {
                try {
                    out.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            if (outw != null) {
                try {
                    outw.close();
                } catch (IOException e) {
                    e.printStackTrace();

                }
            }
            if (null != bw) {
                try {
                    bw.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
