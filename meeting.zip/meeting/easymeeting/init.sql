/*
 * 简易会议预约系统数据库
 * 数据库名：easymeeting
 * 字符集：utf8mb4（兼容emoji，支持所有中文）
 * 排序规则：utf8mb4_general_ci（通用排序，性能优）
 */
CREATE DATABASE IF NOT EXISTS easymeeting DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE easymeeting;
# 1. 用户表（核心基础表）
CREATE TABLE IF NOT EXISTS `sys_user` (
  `id` INT NOT NULL AUTO_INCREMENT COMMENT '用户主键ID',
  `user_name` VARCHAR(50) NOT NULL COMMENT '用户名（登录账号，唯一）',
  `password` VARCHAR(64) NOT NULL COMMENT '登录密码（建议MD5/SHA256加密存储）',
  `nick_name` VARCHAR(50) NOT NULL COMMENT '用户昵称（展示用）',
  `phone` VARCHAR(11) DEFAULT NULL COMMENT '手机号（唯一，可选）',
  `email` VARCHAR(100) DEFAULT NULL COMMENT '邮箱（唯一，可选）',
  `gender` TINYINT DEFAULT 0 COMMENT '性别 0:未知 1:男 2:女',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '用户状态 0:禁用 1:正常 2:注销',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间（自动生成）',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间（自动更新）',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_user_name` (`user_name`),
  UNIQUE KEY `uk_phone` (`phone`),
  UNIQUE KEY `uk_email` (`email`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='系统用户表';
# 2. 会议室表（会议资源表）
CREATE TABLE IF NOT EXISTS `meeting_room` (
  `id` INT NOT NULL AUTO_INCREMENT COMMENT '会议室主键ID',
  `room_name` VARCHAR(100) NOT NULL COMMENT '会议室名称（如：一号会议室/研发部会议室）',
  `capacity` INT NOT NULL COMMENT '容纳人数（如：10/20/50）',
  `location` VARCHAR(255) DEFAULT NULL COMMENT '会议室位置（如：1号楼3层301）',
  `equipment` VARCHAR(500) DEFAULT NULL COMMENT '配套设备（如：投影仪/麦克风/白板/视频会议）',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '状态 0:禁用/维护 1:可用 2:被占用',
  `description` TEXT DEFAULT NULL COMMENT '会议室描述（备注）',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_room_name` (`room_name`),
  KEY `idx_status` (`status`),
  KEY `idx_capacity` (`capacity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会议室信息表';
# 3. 会议信息表（核心业务表，关联用户+会议室）
CREATE TABLE IF NOT EXISTS `meeting_info` (
  `id` INT NOT NULL AUTO_INCREMENT COMMENT '会议主键ID',
  `meeting_title` VARCHAR(200) NOT NULL COMMENT '会议标题（如：项目启动会/技术评审会）',
  `room_id` INT NOT NULL COMMENT '关联会议室ID',
  `create_user_id` INT NOT NULL COMMENT '创建人ID（预约人，关联sys_user）',
  `meeting_type` TINYINT DEFAULT 1 COMMENT '会议类型 1:普通会议 2:部门会议 3:公司会议 4:外部会议',
  `start_time` DATETIME NOT NULL COMMENT '会议开始时间',
  `end_time` DATETIME NOT NULL COMMENT '会议结束时间',
  `status` TINYINT NOT NULL DEFAULT 1 COMMENT '会议状态 0:取消 1:待开始 2:进行中 3:已结束',
  `remark` TEXT DEFAULT NULL COMMENT '会议备注（如：需提前准备资料）',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`id`),
  KEY `idx_room_id` (`room_id`),
  KEY `idx_create_user_id` (`create_user_id`),
  KEY `idx_status` (`status`),
  KEY `idx_time` (`start_time`, `end_time`),
  CONSTRAINT `fk_meeting_room` FOREIGN KEY (`room_id`) REFERENCES `meeting_room` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_meeting_creator` FOREIGN KEY (`create_user_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会议预约信息表';
# 4. 会议参会人表（中间表，多对多：会议-用户）
CREATE TABLE IF NOT EXISTS `meeting_participant` (
  `id` INT NOT NULL AUTO_INCREMENT COMMENT '参会人记录ID',
  `meeting_id` INT NOT NULL COMMENT '关联会议ID',
  `user_id` INT NOT NULL COMMENT '关联参会人用户ID',
  `join_status` TINYINT DEFAULT 0 COMMENT '参会状态 0:未确认 1:已确认 2:拒绝 3:已参会 4:缺席',
  `create_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_meeting_user` (`meeting_id`, `user_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_join_status` (`join_status`),
  CONSTRAINT `fk_participant_meeting` FOREIGN KEY (`meeting_id`) REFERENCES `meeting_info` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_participant_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='会议参会人表';
# 插入初始测试数据
INSERT INTO `sys_user` (`user_name`, `password`, `nick_name`, `phone`, `email`, `gender`, `status`) 
VALUES 
('admin', 'e10adc3949ba59abbe56e057f20f883e', '系统管理员', '13800138000', 'admin@easymeeting.com', 1, 1),
('zhangsan', 'e10adc3949ba59abbe56e057f20f883e', '张三', '13800138001', 'zhangsan@easymeeting.com', 1, 1),
('lisi', 'e10adc3949ba59abbe56e057f20f883e', '李四', '13800138002', 'lisi@easymeeting.com', 2, 1);
INSERT INTO `meeting_room` (`room_name`, `capacity`, `location`, `equipment`, `status`) 
VALUES 
('一号会议室', 10, '1号楼3层301', '投影仪、麦克风、白板', 1),
('二号会议室', 20, '1号楼4层401', '投影仪、视频会议、茶歇', 1),
('大会议室', 50, '2号楼1层101', '大型投影仪、舞台、音响', 1);
INSERT INTO `meeting_info` (`meeting_title`, `room_id`, `create_user_id`, `meeting_type`, `start_time`, `end_time`, `status`) 
VALUES 
('项目启动会', 1, 1, 2, '2026-04-01 09:00:00', '2026-04-01 10:30:00', 1),
('技术评审会', 2, 2, 1, '2026-04-02 14:00:00', '2026-04-02 16:00:00', 1);
INSERT INTO `meeting_participant` (`meeting_id`, `user_id`, `join_status`) 
VALUES 
(1, 1, 1), (1, 2, 1), (1, 3, 0),
(2, 2, 1), (2, 3, 1);
SELECT 'easymeeting数据库创建成功！' AS tips;