/**
 * EasyMeeting 前端应用 - JavaScript 主逻辑
 */

(function() {
    'use strict';

    // 全局状态
    const state = {
        roomPage: 1,
        meetingPage: 1,
        userPage: 1,
        pageSize: 12,
        rooms: [],
        meetings: [],
        users: [],
        roomKeyword: '',
        meetingKeyword: '',
        userKeyword: '',
        theme: localStorage.getItem('theme') || 'light'
    };

    // API 路径（与后端完全一致）
    const API = {
        roomList: '/meetingRoom/loadDataList',
        roomAdd: '/meetingRoom/add',
        roomUpdate: '/meetingRoom/updateMeetingRoomById',
        roomDelete: '/meetingRoom/deleteMeetingRoomById',
        meetingList: '/meetingInfo/loadDataList',
        meetingAdd: '/meetingInfo/add',
        meetingDelete: '/meetingInfo/deleteMeetingInfoById',
        userList: '/sysUser/loadDataList',
        userAdd: '/sysUser/add',
        userUpdate: '/sysUser/updateSysUserById',
        userDelete: '/sysUser/deleteSysUserById'
    };

    // 工具函数
    async function fetchAPI(url, options = {}) {
        try {
            const response = await fetch(url, {
                headers: { 'Content-Type': 'application/json', ...options.headers },
                ...options
            });
            return await response.json();
        } catch (error) {
            console.error('API请求失败:', error);
            return { status: 'error', code: 500, info: '网络请求失败', data: null };
        }
    }

    function extractList(res) {
        if (!res || res.status !== 'success') return [];
        const d = res.data;
        if (!d) return [];
        if (Array.isArray(d)) return d;
        if (Array.isArray(d.list)) return d.list;
        if (Array.isArray(d.records)) return d.records;
        return [];
    }

    async function get(url, params = {}) {
        const qs = new URLSearchParams(params).toString();
        return fetchAPI(qs ? `${url}?${qs}` : url, { method: 'GET' });
    }

    async function post(url, data) {
        return fetchAPI(url, { method: 'POST', body: JSON.stringify(data) });
    }

    async function del(url, id) {
        return fetchAPI(url, { method: 'POST', body: JSON.stringify(id) });
    }

    function formatDateTime(dateStr) {
        if (!dateStr) return '-';
        const d = new Date(dateStr);
        const y = d.getFullYear();
        const m = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const h = String(d.getHours()).padStart(2, '0');
        const mi = String(d.getMinutes()).padStart(2, '0');
        return `${y}-${m}-${day} ${h}:${mi}`;
    }

    function getStatusBadge(status, type = 'room') {
        const maps = {
            room: { 0: ['可用', 'badge-success'], 1: ['已预订', 'badge-warning'], 2: ['维护中', 'badge-danger'] },
            meeting: { 0: ['已取消', 'badge-gray'], 1: ['待开始', 'badge-warning'], 2: ['进行中', 'badge-info'], 3: ['已结束', 'badge-success'] },
            user: { 0: ['禁用', 'badge-danger'], 1: ['正常', 'badge-success'], 2: ['注销', 'badge-gray'] }
        };
        const info = (maps[type] || maps.room)[status] || ['未知', 'badge-gray'];
        return `<span class="badge ${info[1]}">${info[0]}</span>`;
    }

    function getMeetingTypeBadge(type) {
        const types = { 1: ['普通会议', 'badge-info'], 2: ['部门会议', 'badge-purple'], 3: ['公司会议', 'badge-success'], 4: ['外部会议', 'badge-warning'] };
        const info = types[type] || ['未知', 'badge-gray'];
        return `<span class="badge ${info[1]}>${info[0]}</span>`;
    }

    // Toast 通知
    const Toast = {
        init() {
            this.container = document.getElementById('toast-container');
        },
        show(msg, type = 'info', duration = 3000) {
            if (!this.container) this.init();
            const t = document.createElement('div');
            t.className = `toast toast-${type}`;
            const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
            t.innerHTML = `<span class="toast-icon">${icons[type]}</span><span class="toast-message">${msg}</span>`;
            this.container.appendChild(t);
            requestAnimationFrame(() => t.classList.add('show'));
            setTimeout(() => { t.classList.remove('show'); setTimeout(() => t.remove(), 400); }, duration);
        },
        success(msg) { this.show(msg, 'success'); },
        error(msg) { this.show(msg, 'error'); },
        warning(msg) { this.show(msg, 'warning'); },
        info(msg) { this.show(msg, 'info'); }
    };

    // 模态框
    const Modal = {
        show(id) {
            const m = document.getElementById(id);
            if (m) { m.classList.add('show'); document.body.style.overflow = 'hidden'; }
        },
        hide(id) {
            const m = document.getElementById(id);
            if (m) { m.classList.remove('show'); document.body.style.overflow = ''; }
        },
        init() {
            document.querySelectorAll('.modal-overlay').forEach(o => {
                o.addEventListener('click', e => { if (e.target === o) { o.classList.remove('show'); document.body.style.overflow = ''; } });
            });
            document.querySelectorAll('.modal-close, .btn-cancel').forEach(b => {
                b.addEventListener('click', () => {
                    const m = b.closest('.modal-overlay');
                    if (m) { m.classList.remove('show'); document.body.style.overflow = ''; }
                });
            });
        }
    };

    // 页面导航
    function navigateTo(page) {
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        const nav = document.querySelector(`.nav-link[data-page="${page}"]`);
        const pg = document.getElementById(`page-${page}`);
        if (nav) nav.classList.add('active');
        if (pg) { pg.classList.add('active'); pg.classList.add('pageIn'); setTimeout(() => pg.classList.remove('pageIn'), 500); }
        switch (page) {
            case 'home': loadStats(); break;
            case 'rooms': loadRooms(); break;
            case 'booking': loadBookingRooms(); break;
            case 'meetings': loadMeetings(); break;
            case 'users': loadUsers(); break;
        }
    }

    // ========== 首页统计 ==========
    async function loadStats() {
        try {
            const [roomRes, meetingRes, userRes] = await Promise.all([
                get(API.roomList), get(API.meetingList), get(API.userList)
            ]);
            const rooms = extractList(roomRes);
            const meetings = extractList(meetingRes);
            const users = extractList(userRes);

            // 更新统计数字
            const el = (id, val) => { const e = document.getElementById(id); if (e) e.textContent = val; };
            el('stat-rooms', rooms.length);
            el('stat-meetings', meetings.length);
            el('stat-pending', meetings.filter(m => m.status === 1).length);
            el('stat-users', users.length);

            // 最近会议
            const recentContainer = document.getElementById('recent-meetings');
            if (recentContainer) {
                const roomMap = {};
                rooms.forEach(r => roomMap[r.id] = r.roomName);
                const recent = meetings.sort((a, b) => new Date(b.startTime) - new Date(a.startTime)).slice(0, 5);
                recentContainer.innerHTML = recent.length
                    ? recent.map(m => `<tr><td><strong>${m.meetingTitle || '-'}</strong></td><td>${roomMap[m.roomId] || '-'}</td><td>${formatDateTime(m.startTime)}</td><td>${formatDateTime(m.endTime)}</td><td>${getStatusBadge(m.status, 'meeting')}</td></tr>`).join('')
                    : '<tr><td colspan="5" class="text-center p-20"><div class="empty-state">暂无会议数据</div></td></tr>';
            }
        } catch (e) { console.error('加载统计失败:', e); }
    }

    // ========== 会议室管理 ==========
    async function loadRooms() {
        const container = document.getElementById('rooms-grid');
        if (!container) return;
        container.innerHTML = '<div class="loading-dots"><span></span><span></span><span></span></div>';
        try {
            const allRooms = extractList(await get(API.roomList));
            state.rooms = allRooms;
            let filtered = state.roomKeyword
                ? allRooms.filter(r => (r.roomName || '').toLowerCase().includes(state.roomKeyword.toLowerCase()))
                : allRooms;
            const pageData = filtered.slice((state.roomPage - 1) * state.pageSize, state.roomPage * state.pageSize);
            container.innerHTML = pageData.length
                ? pageData.map(r => `
                    <div class="room-card">
                        <div class="room-header">
                            <span class="room-name">${r.roomName || '未命名'}</span>
                            ${getStatusBadge(r.status, 'room')}
                        </div>
                        <div class="room-body">
                            <div class="room-info-item"><span class="room-info-icon">📍</span><span>${r.location || '未知位置'}</span></div>
                            <div class="room-info-item"><span class="room-info-icon">👥</span><span>容纳 ${r.capacity || 0} 人</span></div>
                            <div class="room-info-item"><span class="room-info-icon">💻</span><span>${r.equipment || '基础设备'}</span></div>
                        </div>
                        <div class="room-actions">
                            <button class="btn-sm btn-info" onclick="editRoom(${r.id})">编辑</button>
                            <button class="btn-sm btn-danger" onclick="deleteRoom(${r.id})">删除</button>
                        </div>
                    </div>`).join('')
                : '<div class="empty-state">暂无会议室数据</div>';
            renderPagination('rooms-pagination', filtered.length, state.roomPage, state.pageSize, 'goRoomPage');
        } catch (e) { container.innerHTML = '<div class="empty-state">加载失败</div>'; }
    }

    async function submitRoomForm() {
        const btn = document.getElementById('room-submit-btn');
        if (btn) { btn.disabled = true; btn.textContent = '提交中...'; }
        const id = document.getElementById('room-id').value;
        const data = {
            roomName: document.getElementById('room-name').value.trim(),
            location: document.getElementById('room-location').value.trim(),
            capacity: parseInt(document.getElementById('room-capacity').value) || 0,
            equipment: document.getElementById('room-equipment').value.trim(),
            description: document.getElementById('room-description').value.trim(),
            status: parseInt(document.getElementById('room-status').value) || 1
        };
        if (id) data.id = parseInt(id);
        if (!data.roomName) { Toast.warning('请输入会议室名称'); if (btn) { btn.disabled = false; btn.textContent = '保存'; } return; }
        console.log('📤 提交会议室数据:', JSON.stringify(data));
        try {
            let res;
            if (id) {
                res = await post(API.roomUpdate, data);
            } else {
                res = await post(API.roomAdd, data);
            }
            console.log('📥 服务器响应:', res);
            if (res && res.code === 200) {
                Toast.success(id ? '更新成功' : '添加成功');
                Modal.hide('room-modal');
                loadRooms();
                loadStats();  // 刷新首页统计数据
            } else {
                Toast.error(res && res.info ? res.info : '操作失败');
            }
        } catch (e) {
            console.error('❌ 提交失败:', e);
            Toast.error('操作失败: ' + e.message);
        } finally {
            if (btn) { btn.disabled = false; btn.textContent = '保存'; }
        }
    }

    // ========== 预约会议 ==========
    async function loadBookingRooms() {
        // 加载右侧可用会议室列表
        const container = document.getElementById('available-rooms-list');
        if (container) {
            try {
                const rooms = extractList(await get(API.roomList));
                container.innerHTML = rooms.length
                    ? rooms.map(r => `<div class="available-room-item"><span class="room-name">${r.roomName}</span><span class="room-info">${r.location} · ${r.capacity}人</span></div>`).join('')
                    : '<div class="empty-state">暂无会议室</div>';
            } catch (e) { container.innerHTML = '<div class="empty-state">加载失败</div>'; }
        }

        // 加载下拉框
        const selectRoom = document.getElementById('select-room');
        if (selectRoom) {
            try {
                const rooms = extractList(await get(API.roomList));
                selectRoom.innerHTML = '<option value="">请选择会议室</option>' +
                    rooms.map(r => `<option value="${r.id}">${r.roomName} - ${r.location} (${r.capacity}人)</option>`).join('');
            } catch (e) {
                selectRoom.innerHTML = '<option value="">加载失败</option>';
            }
        }
    }

    async function submitBookingForm() {
        const btn = document.getElementById('booking-submit-btn');
        if (btn) { btn.disabled = true; btn.textContent = '提交中...'; }
        const title = document.getElementById('input-title').value.trim();
        const roomId = document.getElementById('select-room').value;
        const type = parseInt(document.querySelector('input[name="meeting-type"]:checked')?.value) || 0;
        const startTime = document.getElementById('input-start').value;
        const endTime = document.getElementById('input-end').value;
        const remark = document.getElementById('input-remark').value.trim();

        if (!title) { Toast.warning('请输入会议标题'); if (btn) { btn.disabled = false; btn.innerHTML = '<span class="submit-icon">✓</span> 提交预约'; } return; }
        if (!roomId) { Toast.warning('请选择会议室'); if (btn) { btn.disabled = false; btn.innerHTML = '<span class="submit-icon">✓</span> 提交预约'; } return; }
        if (!startTime || !endTime) { Toast.warning('请选择会议时间'); if (btn) { btn.disabled = false; btn.innerHTML = '<span class="submit-icon">✓</span> 提交预约'; } return; }

        const fmtTime = dt => dt.replace('T', ' ') + ':00';
        try {
            const res = await post(API.meetingAdd, {
                meetingTitle: title,
                roomId: parseInt(roomId),
                meetingType: type,
                startTime: fmtTime(startTime),
                endTime: fmtTime(endTime),
                remark,
                status: 1
            });
            if (res.code === 200) {
                Toast.success('预约成功！');
                document.getElementById('booking-form').reset();
                Modal.hide('booking-modal');
                loadMeetings();  // 刷新会议列表
                loadStats();      // 刷新首页统计数据和最近会议
            } else {
                Toast.error(res.info || '预约失败');
            }
        } catch (e) { Toast.error('预约失败'); }
        finally { if (btn) { btn.disabled = false; btn.innerHTML = '<span class="submit-icon">✓</span> 提交预约'; } }
    }

    // ========== 会议列表 ==========
    async function loadMeetings() {
        const container = document.getElementById('meetings-list');
        if (!container) return;
        container.innerHTML = '<tr><td colspan="8" class="text-center p-20"><div class="loading-dots"><span></span><span></span><span></span></div></td></tr>';
        try {
            const [meetingRes, roomRes] = await Promise.all([get(API.meetingList), get(API.roomList)]);
            const allMeetings = extractList(meetingRes);
            const roomMap = {};
            extractList(roomRes).forEach(r => roomMap[r.id] = r.roomName);
            state.meetings = allMeetings;
            let filtered = state.meetingKeyword
                ? allMeetings.filter(m => (m.meetingTitle || '').toLowerCase().includes(state.meetingKeyword.toLowerCase()))
                : allMeetings;
            const pageData = filtered.slice((state.meetingPage - 1) * state.pageSize, state.meetingPage * state.pageSize);
            container.innerHTML = pageData.length
                ? pageData.map(m => `<tr><td>${m.id}</td><td><strong>${m.meetingTitle || '-'}</strong></td><td>${roomMap[m.roomId] || '-'}</td><td>${getMeetingTypeBadge(m.meetingType)}</td><td>${formatDateTime(m.startTime)}</td><td>${formatDateTime(m.endTime)}</td><td>${getStatusBadge(m.status, 'meeting')}</td><td><button class="btn-sm btn-danger" onclick="deleteMeeting(${m.id})">删除</button></td></tr>`).join('')
                : '<tr><td colspan="8" class="text-center p-20"><div class="empty-state">暂无会议数据</div></td></tr>';
            renderPagination('meetings-pagination', filtered.length, state.meetingPage, state.pageSize, 'goMeetingPage');
        } catch (e) { container.innerHTML = '<tr><td colspan="8" class="text-center p-20"><div class="empty-state">加载失败</div></td></tr>'; }
    }

    // ========== 用户管理 ==========
    async function loadUsers() {
        const container = document.getElementById('users-list');
        if (!container) return;
        container.innerHTML = '<tr><td colspan="8" class="text-center p-20"><div class="loading-dots"><span></span><span></span><span></span></div></td></tr>';
        try {
            const allUsers = extractList(await get(API.userList));
            state.users = allUsers;
            let filtered = state.userKeyword
                ? allUsers.filter(u => (u.userName || '').toLowerCase().includes(state.userKeyword.toLowerCase()) || (u.nickName || '').toLowerCase().includes(state.userKeyword.toLowerCase()))
                : allUsers;
            const pageData = filtered.slice((state.userPage - 1) * state.pageSize, state.userPage * state.pageSize);
            container.innerHTML = pageData.length
                ? pageData.map(u => `<tr><td>${u.id}</td><td><strong>${u.userName || '-'}</strong></td><td>${u.nickName || '-'}</td><td>${u.email || '-'}</td><td>${u.gender === 1 ? '男' : u.gender === 2 ? '女' : '未知'}</td><td>${getStatusBadge(u.status, 'user')}</td><td>${formatDateTime(u.createTime)}</td><td><button class="btn-sm btn-info" onclick="editUser(${u.id})">编辑</button><button class="btn-sm btn-danger" onclick="deleteUser(${u.id})">删除</button></td></tr>`).join('')
                : '<tr><td colspan="8" class="text-center p-20"><div class="empty-state">暂无用户数据</div></td></tr>';
            renderPagination('users-pagination', filtered.length, state.userPage, state.pageSize, 'goUserPage');
        } catch (e) { container.innerHTML = '<tr><td colspan="8" class="text-center p-20"><div class="empty-state">加载失败</div></td></tr>'; }
    }

    async function submitUserForm() {
        const btn = document.getElementById('user-submit-btn');
        if (btn) { btn.disabled = true; btn.textContent = '提交中...'; }
        const id = document.getElementById('user-id').value;
        const password = document.getElementById('user-password').value;
        const isEdit = !!id;
        const data = {
            userName: document.getElementById('user-username').value.trim(),
            nickName: document.getElementById('user-nickname').value.trim(),
            phone: document.getElementById('user-phone').value.trim(),
            email: document.getElementById('user-email').value.trim(),
            gender: parseInt(document.getElementById('user-gender').value) || 0,
            status: parseInt(document.getElementById('user-status').value) || 1
        };
        if (id) data.id = parseInt(id);
        if (!data.userName) { Toast.warning('请输入用户名'); if (btn) { btn.disabled = false; btn.textContent = '保存'; } return; }
        if (!isEdit && !password) { Toast.warning('请输入密码'); if (btn) { btn.disabled = false; btn.textContent = '保存'; } return; }
        if (password) data.password = password;
        try {
            let res;
            if (isEdit) {
                res = await post(API.userUpdate, data);
            } else {
                res = await post(API.userAdd, data);
            }
            if (res.code === 200) { Toast.success(isEdit ? '更新成功' : '添加成功'); Modal.hide('user-modal'); loadUsers(); loadStats(); }
            else Toast.error(res.info || '操作失败');
        } catch (e) { Toast.error('操作失败'); }
        finally { if (btn) { btn.disabled = false; btn.textContent = '保存'; } }
    }

    // ========== 分页 ==========
    function renderPagination(paginationId, total, page, size, goFn) {
        const container = document.getElementById(paginationId);
        if (!container) return;
        const totalPages = Math.ceil(total / size);
        if (totalPages <= 1) { container.innerHTML = ''; return; }
        let html = '';
        if (page > 1) html += `<button class="page-btn" onclick="${goFn}(${page - 1})">上一页</button>`;
        html += `<span class="page-info">第 ${page} / ${totalPages} 页</span>`;
        if (page < totalPages) html += `<button class="page-btn" onclick="${goFn}(${page + 1})">下一页</button>`;
        container.innerHTML = html;
    }

    // ========== 暴露到 window ==========
    window.navigateTo = navigateTo;
    window.Modal = Modal;
    window.loadStats = loadStats;
    window.loadRooms = loadRooms;
    window.loadMeetings = loadMeetings;
    window.loadUsers = loadUsers;

    window.filterRooms = function() {
        state.roomKeyword = (document.getElementById('room-search') || {}).value?.trim() || '';
        state.roomPage = 1;
        loadRooms();
    };
    window.filterMeetings = function() {
        state.meetingKeyword = (document.getElementById('meeting-search') || {}).value?.trim() || '';
        state.meetingPage = 1;
        loadMeetings();
    };
    window.filterUsers = function() {
        state.userKeyword = (document.getElementById('user-search') || {}).value?.trim() || '';
        state.userPage = 1;
        loadUsers();
    };

    window.goRoomPage = function(p) { state.roomPage = p; loadRooms(); };
    window.goMeetingPage = function(p) { state.meetingPage = p; loadMeetings(); };
    window.goUserPage = function(p) { state.userPage = p; loadUsers(); };

    window.editRoom = function(id) {
        const r = state.rooms.find(x => x.id === id);
        if (!r) return;
        document.getElementById('room-id').value = r.id;
        document.getElementById('room-name').value = r.roomName || '';
        document.getElementById('room-location').value = r.location || '';
        document.getElementById('room-capacity').value = r.capacity || '';
        document.getElementById('room-equipment').value = r.equipment || '';
        document.getElementById('room-description').value = r.description || '';
        document.getElementById('room-status').value = r.status || 0;
        document.getElementById('room-modal-title').textContent = '编辑会议室';
        document.getElementById('room-status-group').style.display = '';
        Modal.show('room-modal');
    };

    window.deleteRoom = async function(id) {
        if (!confirm('确定要删除该会议室吗？')) return;
        try {
            const res = await del(API.roomDelete, id);
            if (res.code === 200) { Toast.success('删除成功'); loadRooms(); }
            else Toast.error(res.info || '删除失败');
        } catch (e) { Toast.error('删除失败'); }
    };

    window.openAddRoomModal = function() {
        document.getElementById('room-form').reset();
        document.getElementById('room-id').value = '';
        document.getElementById('room-modal-title').textContent = '新增会议室';
        document.getElementById('room-status-group').style.display = 'none';
        Modal.show('room-modal');
    };

    window.editUser = function(id) {
        const u = state.users.find(x => x.id === id);
        if (!u) return;
        document.getElementById('user-id').value = u.id;
        document.getElementById('user-username').value = u.userName || '';
        document.getElementById('user-nickname').value = u.nickName || '';
        document.getElementById('user-password').value = '';
        document.getElementById('user-phone').value = u.phone || '';
        document.getElementById('user-email').value = u.email || '';
        document.getElementById('user-gender').value = u.gender ?? 0;
        document.getElementById('user-status').value = u.status ?? 0;
        document.getElementById('user-modal-title').textContent = '编辑用户';
        Modal.show('user-modal');
    };

    window.deleteUser = async function(id) {
        if (!confirm('确定要删除该用户吗？')) return;
        try {
            const res = await del(API.userDelete, id);
            if (res.code === 200) { Toast.success('删除成功'); loadUsers(); }
            else Toast.error(res.info || '删除失败');
        } catch (e) { Toast.error('删除失败'); }
    };

    window.openAddUserModal = function() {
        document.getElementById('user-form').reset();
        document.getElementById('user-id').value = '';
        document.getElementById('user-modal-title').textContent = '新增用户';
        Modal.show('user-modal');
    };

    window.deleteMeeting = async function(id) {
        if (!confirm('确定要删除该会议吗？')) return;
        try {
            const res = await del(API.meetingDelete, id);
            if (res.code === 200) { Toast.success('删除成功'); loadMeetings(); }
            else Toast.error(res.info || '删除失败');
        } catch (e) { Toast.error('删除失败'); }
    };

    window.submitRoomForm = submitRoomForm;
    window.submitBookingForm = submitBookingForm;
    window.submitUserForm = submitUserForm;

    // ========== 初始化 ==========
    function init() {
        Toast.init();
        Modal.init();

        // 主题切换
        const themeBtn = document.getElementById('themeToggle');
        if (themeBtn) {
            themeBtn.textContent = state.theme === 'light' ? '🌙' : '☀️';
            themeBtn.addEventListener('click', () => {
                state.theme = state.theme === 'light' ? 'dark' : 'light';
                document.documentElement.dataset.theme = state.theme;
                localStorage.setItem('theme', state.theme);
                themeBtn.textContent = state.theme === 'light' ? '🌙' : '☀️';
            });
        }

        // 导航链接
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', function(e) {
                e.preventDefault();
                const page = this.dataset.page;
                if (page) navigateTo(page);
            });
        });

        // 按钮绑定
        const btnAddRoom = document.getElementById('btn-add-room');
        if (btnAddRoom) btnAddRoom.addEventListener('click', openAddRoomModal);

        const btnAddUser = document.getElementById('btn-add-user');
        if (btnAddUser) btnAddUser.addEventListener('click', openAddUserModal);

        // 表单提交
        const roomForm = document.getElementById('room-form');
        if (roomForm) roomForm.addEventListener('submit', e => { e.preventDefault(); submitRoomForm(); });

        const bookingForm = document.getElementById('booking-form');
        if (bookingForm) bookingForm.addEventListener('submit', e => { e.preventDefault(); submitBookingForm(); });

        const userForm = document.getElementById('user-form');
        if (userForm) userForm.addEventListener('submit', e => { e.preventDefault(); submitUserForm(); });

        navigateTo('home');
        console.log('✅ EasyMeeting 前端初始化完成');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();
