package com.easymeeting.mapper;
import com.easymeeting.entity.MeetingRoom;
import java.util.List;
/**
 * 会议室 Mapper 接口 - 纯 XML 模式，不使用注解
 */
public interface MeetingRoomMapper {
    
    List<MeetingRoom> selectAll();
    
    MeetingRoom selectById(Integer id);
    
    int insert(MeetingRoom room);
    
    int update(MeetingRoom room);
    
    int deleteById(Integer id);
}