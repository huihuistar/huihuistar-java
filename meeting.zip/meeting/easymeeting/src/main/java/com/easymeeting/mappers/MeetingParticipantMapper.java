package com.easymeeting.mappers;

import org.apache.ibatis.annotations.Param;

/**
 * 会议参会人表 数据库操作接口
 */
public interface MeetingParticipantMapper<T,P> extends BaseMapper<T,P> {

	/**
	 * 根据Id更新
	 */
	 Integer updateById(@Param("bean") T t,@Param("id") Integer id);


	/**
	 * 根据Id删除
	 */
	 Integer deleteById(@Param("id") Integer id);


	/**
	 * 根据Id获取对象
	 */
	 T selectById(@Param("id") Integer id);


	/**
	 * 根据MeetingIdAndUserId更新
	 */
	 Integer updateByMeetingIdAndUserId(@Param("bean") T t,@Param("meetingId") Integer meetingId,@Param("userId") Integer userId);


	/**
	 * 根据MeetingIdAndUserId删除
	 */
	 Integer deleteByMeetingIdAndUserId(@Param("meetingId") Integer meetingId,@Param("userId") Integer userId);


	/**
	 * 根据MeetingIdAndUserId获取对象
	 */
	 T selectByMeetingIdAndUserId(@Param("meetingId") Integer meetingId,@Param("userId") Integer userId);


}
