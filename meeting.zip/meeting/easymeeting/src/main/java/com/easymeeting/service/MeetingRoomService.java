package com.easymeeting.service;

import java.util.List;

import com.easymeeting.entity.query.MeetingRoomQuery;
import com.easymeeting.entity.po.MeetingRoom;
import com.easymeeting.entity.vo.PaginationResultVO;


/**
 * 会议室信息表 业务接口
 */
public interface MeetingRoomService {

	/**
	 * 根据条件查询列表
	 */
	List<MeetingRoom> findListByParam(MeetingRoomQuery param);

	/**
	 * 根据条件查询列表
	 */
	Integer findCountByParam(MeetingRoomQuery param);

	/**
	 * 分页查询
	 */
	PaginationResultVO<MeetingRoom> findListByPage(MeetingRoomQuery param);

	/**
	 * 新增
	 */
	Integer add(MeetingRoom bean);

	/**
	 * 批量新增
	 */
	Integer addBatch(List<MeetingRoom> listBean);

	/**
	 * 批量新增/修改
	 */
	Integer addOrUpdateBatch(List<MeetingRoom> listBean);

	/**
	 * 多条件更新
	 */
	Integer updateByParam(MeetingRoom bean,MeetingRoomQuery param);

	/**
	 * 多条件删除
	 */
	Integer deleteByParam(MeetingRoomQuery param);

	/**
	 * 根据Id查询对象
	 */
	MeetingRoom getMeetingRoomById(Integer id);


	/**
	 * 根据Id修改
	 */
	Integer updateMeetingRoomById(MeetingRoom bean,Integer id);


	/**
	 * 根据Id删除
	 */
	Integer deleteMeetingRoomById(Integer id);


	/**
	 * 根据RoomName查询对象
	 */
	MeetingRoom getMeetingRoomByRoomName(String roomName);


	/**
	 * 根据RoomName修改
	 */
	Integer updateMeetingRoomByRoomName(MeetingRoom bean,String roomName);


	/**
	 * 根据RoomName删除
	 */
	Integer deleteMeetingRoomByRoomName(String roomName);

}