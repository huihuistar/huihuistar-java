package com.easymeeting.mappers;

import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 会议预约信息表 数据库操作接口
 */
public interface MeetingInfoMapper<T,P> extends BaseMapper<T,P> {

	/**
	 * 根据Id更新
	 */
	 Integer updateById(@Param("bean") T t,@Param("id") Integer id);


	/**
	 * 根据Id删除
	 */
	 Integer deleteById(@Param("id") Integer id);


	/**
	 * 根据Id获取对象
	 */
	 T selectById(@Param("id") Integer id);

	/**
	 * 批量更新会议状态（定时任务调用）
	 */
	 Integer updateStatusBatch(@Param("newStatus") Integer newStatus, @Param("oldStatusList") List<Integer> oldStatusList);

	/**
	 * 将已开始但未结束的会议状态更新为进行中
	 */
	 Integer updateToOngoing();

	/**
	 * 将已过结束时间的会议状态更新为已结束
	 */
	 Integer updateToFinished();

}
