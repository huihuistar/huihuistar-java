package com.easymeeting.entity;
import java.util.Date;
/**
 * 会议信息实体类
 * 对应数据库表: meeting_info
 */
public class MeetingInfo {
    
    private Integer id;
    private String meetingTitle;
    private Integer roomId;
    private Integer createUserId;
    private Integer meetingType;
    private Date startTime;
    private Date endTime;
    private Integer status;
    private String remark;
    private Date createTime;
    private Date updateTime;
    
    // 关联字段（非数据库字段，用于展示）
    private String roomName;
    private String createUserName;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public String getMeetingTitle() {
        return meetingTitle;
    }
    public void setMeetingTitle(String meetingTitle) {
        this.meetingTitle = meetingTitle;
    }
    public Integer getRoomId() {
        return roomId;
    }
    public void setRoomId(Integer roomId) {
        this.roomId = roomId;
    }
    public Integer getCreateUserId() {
        return createUserId;
    }
    public void setCreateUserId(Integer createUserId) {
        this.createUserId = createUserId;
    }
    public Integer getMeetingType() {
        return meetingType;
    }
    public void setMeetingType(Integer meetingType) {
        this.meetingType = meetingType;
    }
    public Date getStartTime() {
        return startTime;
    }
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }
    public Date getEndTime() {
        return endTime;
    }
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }
    public Integer getStatus() {
        return status;
    }
    public void setStatus(Integer status) {
        this.status = status;
    }
    public String getRemark() {
        return remark;
    }
    public void setRemark(String remark) {
        this.remark = remark;
    }
    public Date getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
    public Date getUpdateTime() {
        return updateTime;
    }
    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    public String getRoomName() {
        return roomName;
    }
    public void setRoomName(String roomName) {
        this.roomName = roomName;
    }
    public String getCreateUserName() {
        return createUserName;
    }
    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }
}