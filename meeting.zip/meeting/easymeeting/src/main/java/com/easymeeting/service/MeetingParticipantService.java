package com.easymeeting.service;

import java.util.List;

import com.easymeeting.entity.query.MeetingParticipantQuery;
import com.easymeeting.entity.po.MeetingParticipant;
import com.easymeeting.entity.vo.PaginationResultVO;


/**
 * 会议参会人表 业务接口
 */
public interface MeetingParticipantService {

	/**
	 * 根据条件查询列表
	 */
	List<MeetingParticipant> findListByParam(MeetingParticipantQuery param);

	/**
	 * 根据条件查询列表
	 */
	Integer findCountByParam(MeetingParticipantQuery param);

	/**
	 * 分页查询
	 */
	PaginationResultVO<MeetingParticipant> findListByPage(MeetingParticipantQuery param);

	/**
	 * 新增
	 */
	Integer add(MeetingParticipant bean);

	/**
	 * 批量新增
	 */
	Integer addBatch(List<MeetingParticipant> listBean);

	/**
	 * 批量新增/修改
	 */
	Integer addOrUpdateBatch(List<MeetingParticipant> listBean);

	/**
	 * 多条件更新
	 */
	Integer updateByParam(MeetingParticipant bean,MeetingParticipantQuery param);

	/**
	 * 多条件删除
	 */
	Integer deleteByParam(MeetingParticipantQuery param);

	/**
	 * 根据Id查询对象
	 */
	MeetingParticipant getMeetingParticipantById(Integer id);


	/**
	 * 根据Id修改
	 */
	Integer updateMeetingParticipantById(MeetingParticipant bean,Integer id);


	/**
	 * 根据Id删除
	 */
	Integer deleteMeetingParticipantById(Integer id);


	/**
	 * 根据MeetingIdAndUserId查询对象
	 */
	MeetingParticipant getMeetingParticipantByMeetingIdAndUserId(Integer meetingId,Integer userId);


	/**
	 * 根据MeetingIdAndUserId修改
	 */
	Integer updateMeetingParticipantByMeetingIdAndUserId(MeetingParticipant bean,Integer meetingId,Integer userId);


	/**
	 * 根据MeetingIdAndUserId删除
	 */
	Integer deleteMeetingParticipantByMeetingIdAndUserId(Integer meetingId,Integer userId);

}