package com.easymeeting.mappers;

import org.apache.ibatis.annotations.Param;

/**
 * 系统用户表 数据库操作接口
 */
public interface SysUserMapper<T,P> extends BaseMapper<T,P> {

	/**
	 * 根据Id更新
	 */
	 Integer updateById(@Param("bean") T t,@Param("id") Integer id);


	/**
	 * 根据Id删除
	 */
	 Integer deleteById(@Param("id") Integer id);


	/**
	 * 根据Id获取对象
	 */
	 T selectById(@Param("id") Integer id);


	/**
	 * 根据UserName更新
	 */
	 Integer updateByUserName(@Param("bean") T t,@Param("userName") String userName);


	/**
	 * 根据UserName删除
	 */
	 Integer deleteByUserName(@Param("userName") String userName);


	/**
	 * 根据UserName获取对象
	 */
	 T selectByUserName(@Param("userName") String userName);


	/**
	 * 根据Phone更新
	 */
	 Integer updateByPhone(@Param("bean") T t,@Param("phone") String phone);


	/**
	 * 根据Phone删除
	 */
	 Integer deleteByPhone(@Param("phone") String phone);


	/**
	 * 根据Phone获取对象
	 */
	 T selectByPhone(@Param("phone") String phone);


	/**
	 * 根据Email更新
	 */
	 Integer updateByEmail(@Param("bean") T t,@Param("email") String email);


	/**
	 * 根据Email删除
	 */
	 Integer deleteByEmail(@Param("email") String email);


	/**
	 * 根据Email获取对象
	 */
	 T selectByEmail(@Param("email") String email);


}
