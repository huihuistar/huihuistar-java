package com.easymeeting.mapper;
import com.easymeeting.entity.MeetingInfo;
import java.util.List;
/**
 * 会议信息 Mapper 接口 - 纯 XML 模式，不使用注解
 */
public interface MeetingInfoMapper {
    
    List<MeetingInfo> selectAll();
    
    MeetingInfo selectById(Integer id);
    
    int insert(MeetingInfo meeting);
    
    int update(MeetingInfo meeting);
    
    int deleteById(Integer id);
}