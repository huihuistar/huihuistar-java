package com.easymeeting.service;

import java.util.List;

import com.easymeeting.entity.query.MeetingInfoQuery;
import com.easymeeting.entity.po.MeetingInfo;
import com.easymeeting.entity.vo.PaginationResultVO;


/**
 * 会议预约信息表 业务接口
 */
public interface MeetingInfoService {

	/**
	 * 根据条件查询列表
	 */
	List<MeetingInfo> findListByParam(MeetingInfoQuery param);

	/**
	 * 根据条件查询列表
	 */
	Integer findCountByParam(MeetingInfoQuery param);

	/**
	 * 分页查询
	 */
	PaginationResultVO<MeetingInfo> findListByPage(MeetingInfoQuery param);

	/**
	 * 新增
	 */
	Integer add(MeetingInfo bean);

	/**
	 * 批量新增
	 */
	Integer addBatch(List<MeetingInfo> listBean);

	/**
	 * 批量新增/修改
	 */
	Integer addOrUpdateBatch(List<MeetingInfo> listBean);

	/**
	 * 多条件更新
	 */
	Integer updateByParam(MeetingInfo bean,MeetingInfoQuery param);

	/**
	 * 多条件删除
	 */
	Integer deleteByParam(MeetingInfoQuery param);

	/**
	 * 根据Id查询对象
	 */
	MeetingInfo getMeetingInfoById(Integer id);


	/**
	 * 根据Id修改
	 */
	Integer updateMeetingInfoById(MeetingInfo bean,Integer id);


	/**
	 * 根据Id删除
	 */
	Integer deleteMeetingInfoById(Integer id);

	/**
	 * 自动更新会议状态（定时任务调用）
	 */
	void autoUpdateMeetingStatus();

}