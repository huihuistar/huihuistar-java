package com.easymeeting.controller;

import java.util.List;

import com.easymeeting.entity.query.SysUserQuery;
import com.easymeeting.entity.po.SysUser;
import com.easymeeting.entity.vo.ResponseVO;
import com.easymeeting.service.SysUserService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 系统用户表 Controller
 */
@RestController("sysUserController")
@RequestMapping("/sysUser")
public class SysUserController extends ABaseController{

	@Resource
	private SysUserService sysUserService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(SysUserQuery query){
		return getSuccessResponseVO(sysUserService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(@RequestBody SysUser bean) {
		sysUserService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<SysUser> listBean) {
		sysUserService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<SysUser> listBean) {
		sysUserService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id查询对象
	 */
	@RequestMapping("/getSysUserById")
	public ResponseVO getSysUserById(Integer id) {
		return getSuccessResponseVO(sysUserService.getSysUserById(id));
	}

	/**
	 * 根据Id修改对象
	 */
	@RequestMapping("/updateSysUserById")
	public ResponseVO updateSysUserById(@RequestBody SysUser bean) {
		sysUserService.updateSysUserById(bean, bean.getId());
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id删除
	 */
	@RequestMapping("/deleteSysUserById")
	public ResponseVO deleteSysUserById(@RequestBody Integer id) {
		sysUserService.deleteSysUserById(id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据UserName查询对象
	 */
	@RequestMapping("/getSysUserByUserName")
	public ResponseVO getSysUserByUserName(String userName) {
		return getSuccessResponseVO(sysUserService.getSysUserByUserName(userName));
	}

	/**
	 * 根据UserName修改对象
	 */
	@RequestMapping("/updateSysUserByUserName")
	public ResponseVO updateSysUserByUserName(SysUser bean,String userName) {
		sysUserService.updateSysUserByUserName(bean,userName);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据UserName删除
	 */
	@RequestMapping("/deleteSysUserByUserName")
	public ResponseVO deleteSysUserByUserName(String userName) {
		sysUserService.deleteSysUserByUserName(userName);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Phone查询对象
	 */
	@RequestMapping("/getSysUserByPhone")
	public ResponseVO getSysUserByPhone(String phone) {
		return getSuccessResponseVO(sysUserService.getSysUserByPhone(phone));
	}

	/**
	 * 根据Phone修改对象
	 */
	@RequestMapping("/updateSysUserByPhone")
	public ResponseVO updateSysUserByPhone(SysUser bean,String phone) {
		sysUserService.updateSysUserByPhone(bean,phone);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Phone删除
	 */
	@RequestMapping("/deleteSysUserByPhone")
	public ResponseVO deleteSysUserByPhone(String phone) {
		sysUserService.deleteSysUserByPhone(phone);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Email查询对象
	 */
	@RequestMapping("/getSysUserByEmail")
	public ResponseVO getSysUserByEmail(String email) {
		return getSuccessResponseVO(sysUserService.getSysUserByEmail(email));
	}

	/**
	 * 根据Email修改对象
	 */
	@RequestMapping("/updateSysUserByEmail")
	public ResponseVO updateSysUserByEmail(SysUser bean,String email) {
		sysUserService.updateSysUserByEmail(bean,email);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Email删除
	 */
	@RequestMapping("/deleteSysUserByEmail")
	public ResponseVO deleteSysUserByEmail(String email) {
		sysUserService.deleteSysUserByEmail(email);
		return getSuccessResponseVO(null);
	}
}