package com.easymeeting.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import com.easymeeting.entity.enums.DateTimePatternEnum;
import com.easymeeting.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 会议室信息表
 */
public class MeetingRoom implements Serializable {


	/**
	 * 会议室主键ID
	 */
	private Integer id;

	/**
	 * 会议室名称（如：一号会议室/研发部会议室）
	 */
	private String roomName;

	/**
	 * 容纳人数（如：10/20/50）
	 */
	private Integer capacity;

	/**
	 * 会议室位置（如：1号楼3层301）
	 */
	private String location;

	/**
	 * 配套设备（如：投影仪/麦克风/白板/视频会议）
	 */
	private String equipment;

	/**
	 * 状态 0:禁用/维护 1:可用 2:被占用
	 */
	private Integer status;

	/**
	 * 会议室描述（备注）
	 */
	private String description;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	/**
	 * 更新时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setRoomName(String roomName){
		this.roomName = roomName;
	}

	public String getRoomName(){
		return this.roomName;
	}

	public void setCapacity(Integer capacity){
		this.capacity = capacity;
	}

	public Integer getCapacity(){
		return this.capacity;
	}

	public void setLocation(String location){
		this.location = location;
	}

	public String getLocation(){
		return this.location;
	}

	public void setEquipment(String equipment){
		this.equipment = equipment;
	}

	public String getEquipment(){
		return this.equipment;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return this.description;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}

	public Date getUpdateTime(){
		return this.updateTime;
	}

	@Override
	public String toString (){
		return "会议室主键ID:"+(id == null ? "空" : id)+"，会议室名称（如：一号会议室/研发部会议室）:"+(roomName == null ? "空" : roomName)+"，容纳人数（如：10/20/50）:"+(capacity == null ? "空" : capacity)+"，会议室位置（如：1号楼3层301）:"+(location == null ? "空" : location)+"，配套设备（如：投影仪/麦克风/白板/视频会议）:"+(equipment == null ? "空" : equipment)+"，状态 0:禁用/维护 1:可用 2:被占用:"+(status == null ? "空" : status)+"，会议室描述（备注）:"+(description == null ? "空" : description)+"，创建时间:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()))+"，更新时间:"+(updateTime == null ? "空" : DateUtil.format(updateTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
