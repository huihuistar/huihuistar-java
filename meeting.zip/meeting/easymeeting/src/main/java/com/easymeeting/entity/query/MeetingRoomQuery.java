package com.easymeeting.entity.query;

import java.util.Date;


/**
 * 会议室信息表参数
 */
public class MeetingRoomQuery extends BaseParam {


	/**
	 * 会议室主键ID
	 */
	private Integer id;

	/**
	 * 会议室名称（如：一号会议室/研发部会议室）
	 */
	private String roomName;

	private String roomNameFuzzy;

	/**
	 * 容纳人数（如：10/20/50）
	 */
	private Integer capacity;

	/**
	 * 会议室位置（如：1号楼3层301）
	 */
	private String location;

	private String locationFuzzy;

	/**
	 * 配套设备（如：投影仪/麦克风/白板/视频会议）
	 */
	private String equipment;

	private String equipmentFuzzy;

	/**
	 * 状态 0:禁用/维护 1:可用 2:被占用
	 */
	private Integer status;

	/**
	 * 会议室描述（备注）
	 */
	private String description;

	private String descriptionFuzzy;

	/**
	 * 创建时间
	 */
	private String createTime;

	private String createTimeStart;

	private String createTimeEnd;

	/**
	 * 更新时间
	 */
	private String updateTime;

	private String updateTimeStart;

	private String updateTimeEnd;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setRoomName(String roomName){
		this.roomName = roomName;
	}

	public String getRoomName(){
		return this.roomName;
	}

	public void setRoomNameFuzzy(String roomNameFuzzy){
		this.roomNameFuzzy = roomNameFuzzy;
	}

	public String getRoomNameFuzzy(){
		return this.roomNameFuzzy;
	}

	public void setCapacity(Integer capacity){
		this.capacity = capacity;
	}

	public Integer getCapacity(){
		return this.capacity;
	}

	public void setLocation(String location){
		this.location = location;
	}

	public String getLocation(){
		return this.location;
	}

	public void setLocationFuzzy(String locationFuzzy){
		this.locationFuzzy = locationFuzzy;
	}

	public String getLocationFuzzy(){
		return this.locationFuzzy;
	}

	public void setEquipment(String equipment){
		this.equipment = equipment;
	}

	public String getEquipment(){
		return this.equipment;
	}

	public void setEquipmentFuzzy(String equipmentFuzzy){
		this.equipmentFuzzy = equipmentFuzzy;
	}

	public String getEquipmentFuzzy(){
		return this.equipmentFuzzy;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setDescription(String description){
		this.description = description;
	}

	public String getDescription(){
		return this.description;
	}

	public void setDescriptionFuzzy(String descriptionFuzzy){
		this.descriptionFuzzy = descriptionFuzzy;
	}

	public String getDescriptionFuzzy(){
		return this.descriptionFuzzy;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setCreateTimeStart(String createTimeStart){
		this.createTimeStart = createTimeStart;
	}

	public String getCreateTimeStart(){
		return this.createTimeStart;
	}
	public void setCreateTimeEnd(String createTimeEnd){
		this.createTimeEnd = createTimeEnd;
	}

	public String getCreateTimeEnd(){
		return this.createTimeEnd;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

	public void setUpdateTimeStart(String updateTimeStart){
		this.updateTimeStart = updateTimeStart;
	}

	public String getUpdateTimeStart(){
		return this.updateTimeStart;
	}
	public void setUpdateTimeEnd(String updateTimeEnd){
		this.updateTimeEnd = updateTimeEnd;
	}

	public String getUpdateTimeEnd(){
		return this.updateTimeEnd;
	}

}
