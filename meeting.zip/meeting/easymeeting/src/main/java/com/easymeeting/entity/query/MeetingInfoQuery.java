package com.easymeeting.entity.query;

import java.util.Date;


/**
 * 会议预约信息表参数
 */
public class MeetingInfoQuery extends BaseParam {


	/**
	 * 会议主键ID
	 */
	private Integer id;

	/**
	 * 会议标题（如：项目启动会/技术评审会）
	 */
	private String meetingTitle;

	private String meetingTitleFuzzy;

	/**
	 * 关联会议室ID
	 */
	private Integer roomId;

	/**
	 * 创建人ID（预约人，关联sys_user）
	 */
	private Integer createUserId;

	/**
	 * 会议类型 1:普通会议 2:部门会议 3:公司会议 4:外部会议
	 */
	private Integer meetingType;

	/**
	 * 会议开始时间
	 */
	private String startTime;

	private String startTimeStart;

	private String startTimeEnd;

	/**
	 * 会议结束时间
	 */
	private String endTime;

	private String endTimeStart;

	private String endTimeEnd;

	/**
	 * 会议状态 0:取消 1:待开始 2:进行中 3:已结束
	 */
	private Integer status;

	/**
	 * 会议备注（如：需提前准备资料）
	 */
	private String remark;

	private String remarkFuzzy;

	/**
	 * 创建时间
	 */
	private String createTime;

	private String createTimeStart;

	private String createTimeEnd;

	/**
	 * 更新时间
	 */
	private String updateTime;

	private String updateTimeStart;

	private String updateTimeEnd;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setMeetingTitle(String meetingTitle){
		this.meetingTitle = meetingTitle;
	}

	public String getMeetingTitle(){
		return this.meetingTitle;
	}

	public void setMeetingTitleFuzzy(String meetingTitleFuzzy){
		this.meetingTitleFuzzy = meetingTitleFuzzy;
	}

	public String getMeetingTitleFuzzy(){
		return this.meetingTitleFuzzy;
	}

	public void setRoomId(Integer roomId){
		this.roomId = roomId;
	}

	public Integer getRoomId(){
		return this.roomId;
	}

	public void setCreateUserId(Integer createUserId){
		this.createUserId = createUserId;
	}

	public Integer getCreateUserId(){
		return this.createUserId;
	}

	public void setMeetingType(Integer meetingType){
		this.meetingType = meetingType;
	}

	public Integer getMeetingType(){
		return this.meetingType;
	}

	public void setStartTime(String startTime){
		this.startTime = startTime;
	}

	public String getStartTime(){
		return this.startTime;
	}

	public void setStartTimeStart(String startTimeStart){
		this.startTimeStart = startTimeStart;
	}

	public String getStartTimeStart(){
		return this.startTimeStart;
	}
	public void setStartTimeEnd(String startTimeEnd){
		this.startTimeEnd = startTimeEnd;
	}

	public String getStartTimeEnd(){
		return this.startTimeEnd;
	}

	public void setEndTime(String endTime){
		this.endTime = endTime;
	}

	public String getEndTime(){
		return this.endTime;
	}

	public void setEndTimeStart(String endTimeStart){
		this.endTimeStart = endTimeStart;
	}

	public String getEndTimeStart(){
		return this.endTimeStart;
	}
	public void setEndTimeEnd(String endTimeEnd){
		this.endTimeEnd = endTimeEnd;
	}

	public String getEndTimeEnd(){
		return this.endTimeEnd;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setRemark(String remark){
		this.remark = remark;
	}

	public String getRemark(){
		return this.remark;
	}

	public void setRemarkFuzzy(String remarkFuzzy){
		this.remarkFuzzy = remarkFuzzy;
	}

	public String getRemarkFuzzy(){
		return this.remarkFuzzy;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setCreateTimeStart(String createTimeStart){
		this.createTimeStart = createTimeStart;
	}

	public String getCreateTimeStart(){
		return this.createTimeStart;
	}
	public void setCreateTimeEnd(String createTimeEnd){
		this.createTimeEnd = createTimeEnd;
	}

	public String getCreateTimeEnd(){
		return this.createTimeEnd;
	}

	public void setUpdateTime(String updateTime){
		this.updateTime = updateTime;
	}

	public String getUpdateTime(){
		return this.updateTime;
	}

	public void setUpdateTimeStart(String updateTimeStart){
		this.updateTimeStart = updateTimeStart;
	}

	public String getUpdateTimeStart(){
		return this.updateTimeStart;
	}
	public void setUpdateTimeEnd(String updateTimeEnd){
		this.updateTimeEnd = updateTimeEnd;
	}

	public String getUpdateTimeEnd(){
		return this.updateTimeEnd;
	}

}
