package com.easymeeting.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.easymeeting.entity.enums.PageSize;
import com.easymeeting.entity.query.MeetingRoomQuery;
import com.easymeeting.entity.po.MeetingRoom;
import com.easymeeting.entity.vo.PaginationResultVO;
import com.easymeeting.entity.query.SimplePage;
import com.easymeeting.mappers.MeetingRoomMapper;
import com.easymeeting.service.MeetingRoomService;
import com.easymeeting.utils.StringTools;


/**
 * 会议室信息表 业务接口实现
 */
@Service("meetingRoomService")
public class MeetingRoomServiceImpl implements MeetingRoomService {

	@Resource
	private MeetingRoomMapper<MeetingRoom, MeetingRoomQuery> meetingRoomMapper;

	/**
	 * 根据条件查询列表
	 */
	@Override
	public List<MeetingRoom> findListByParam(MeetingRoomQuery param) {
		return this.meetingRoomMapper.selectList(param);
	}

	/**
	 * 根据条件查询列表
	 */
	@Override
	public Integer findCountByParam(MeetingRoomQuery param) {
		return this.meetingRoomMapper.selectCount(param);
	}

	/**
	 * 分页查询方法
	 */
	@Override
	public PaginationResultVO<MeetingRoom> findListByPage(MeetingRoomQuery param) {
		int count = this.findCountByParam(param);
		int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

		SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
		param.setSimplePage(page);
		List<MeetingRoom> list = this.findListByParam(param);
		PaginationResultVO<MeetingRoom> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
		return result;
	}

	/**
	 * 新增
	 */
	@Override
	public Integer add(MeetingRoom bean) {
		return this.meetingRoomMapper.insert(bean);
	}

	/**
	 * 批量新增
	 */
	@Override
	public Integer addBatch(List<MeetingRoom> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.meetingRoomMapper.insertBatch(listBean);
	}

	/**
	 * 批量新增或者修改
	 */
	@Override
	public Integer addOrUpdateBatch(List<MeetingRoom> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.meetingRoomMapper.insertOrUpdateBatch(listBean);
	}

	/**
	 * 多条件更新
	 */
	@Override
	public Integer updateByParam(MeetingRoom bean, MeetingRoomQuery param) {
		StringTools.checkParam(param);
		return this.meetingRoomMapper.updateByParam(bean, param);
	}

	/**
	 * 多条件删除
	 */
	@Override
	public Integer deleteByParam(MeetingRoomQuery param) {
		StringTools.checkParam(param);
		return this.meetingRoomMapper.deleteByParam(param);
	}

	/**
	 * 根据Id获取对象
	 */
	@Override
	public MeetingRoom getMeetingRoomById(Integer id) {
		return this.meetingRoomMapper.selectById(id);
	}

	/**
	 * 根据Id修改
	 */
	@Override
	public Integer updateMeetingRoomById(MeetingRoom bean, Integer id) {
		return this.meetingRoomMapper.updateById(bean, id);
	}

	/**
	 * 根据Id删除
	 */
	@Override
	public Integer deleteMeetingRoomById(Integer id) {
		return this.meetingRoomMapper.deleteById(id);
	}

	/**
	 * 根据RoomName获取对象
	 */
	@Override
	public MeetingRoom getMeetingRoomByRoomName(String roomName) {
		return this.meetingRoomMapper.selectByRoomName(roomName);
	}

	/**
	 * 根据RoomName修改
	 */
	@Override
	public Integer updateMeetingRoomByRoomName(MeetingRoom bean, String roomName) {
		return this.meetingRoomMapper.updateByRoomName(bean, roomName);
	}

	/**
	 * 根据RoomName删除
	 */
	@Override
	public Integer deleteMeetingRoomByRoomName(String roomName) {
		return this.meetingRoomMapper.deleteByRoomName(roomName);
	}
}