package com.easymeeting.entity.query;

import java.util.Date;


/**
 * 会议参会人表参数
 */
public class MeetingParticipantQuery extends BaseParam {


	/**
	 * 参会人记录ID
	 */
	private Integer id;

	/**
	 * 关联会议ID
	 */
	private Integer meetingId;

	/**
	 * 关联参会人用户ID
	 */
	private Integer userId;

	/**
	 * 参会状态 0:未确认 1:已确认 2:拒绝 3:已参会 4:缺席
	 */
	private Integer joinStatus;

	/**
	 * 创建时间
	 */
	private String createTime;

	private String createTimeStart;

	private String createTimeEnd;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setMeetingId(Integer meetingId){
		this.meetingId = meetingId;
	}

	public Integer getMeetingId(){
		return this.meetingId;
	}

	public void setUserId(Integer userId){
		this.userId = userId;
	}

	public Integer getUserId(){
		return this.userId;
	}

	public void setJoinStatus(Integer joinStatus){
		this.joinStatus = joinStatus;
	}

	public Integer getJoinStatus(){
		return this.joinStatus;
	}

	public void setCreateTime(String createTime){
		this.createTime = createTime;
	}

	public String getCreateTime(){
		return this.createTime;
	}

	public void setCreateTimeStart(String createTimeStart){
		this.createTimeStart = createTimeStart;
	}

	public String getCreateTimeStart(){
		return this.createTimeStart;
	}
	public void setCreateTimeEnd(String createTimeEnd){
		this.createTimeEnd = createTimeEnd;
	}

	public String getCreateTimeEnd(){
		return this.createTimeEnd;
	}

}
