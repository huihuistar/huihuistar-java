package com.easymeeting.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.easymeeting.entity.enums.PageSize;
import com.easymeeting.entity.query.MeetingParticipantQuery;
import com.easymeeting.entity.po.MeetingParticipant;
import com.easymeeting.entity.vo.PaginationResultVO;
import com.easymeeting.entity.query.SimplePage;
import com.easymeeting.mappers.MeetingParticipantMapper;
import com.easymeeting.service.MeetingParticipantService;
import com.easymeeting.utils.StringTools;


/**
 * 会议参会人表 业务接口实现
 */
@Service("meetingParticipantService")
public class MeetingParticipantServiceImpl implements MeetingParticipantService {

	@Resource
	private MeetingParticipantMapper<MeetingParticipant, MeetingParticipantQuery> meetingParticipantMapper;

	/**
	 * 根据条件查询列表
	 */
	@Override
	public List<MeetingParticipant> findListByParam(MeetingParticipantQuery param) {
		return this.meetingParticipantMapper.selectList(param);
	}

	/**
	 * 根据条件查询列表
	 */
	@Override
	public Integer findCountByParam(MeetingParticipantQuery param) {
		return this.meetingParticipantMapper.selectCount(param);
	}

	/**
	 * 分页查询方法
	 */
	@Override
	public PaginationResultVO<MeetingParticipant> findListByPage(MeetingParticipantQuery param) {
		int count = this.findCountByParam(param);
		int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

		SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
		param.setSimplePage(page);
		List<MeetingParticipant> list = this.findListByParam(param);
		PaginationResultVO<MeetingParticipant> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
		return result;
	}

	/**
	 * 新增
	 */
	@Override
	public Integer add(MeetingParticipant bean) {
		return this.meetingParticipantMapper.insert(bean);
	}

	/**
	 * 批量新增
	 */
	@Override
	public Integer addBatch(List<MeetingParticipant> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.meetingParticipantMapper.insertBatch(listBean);
	}

	/**
	 * 批量新增或者修改
	 */
	@Override
	public Integer addOrUpdateBatch(List<MeetingParticipant> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.meetingParticipantMapper.insertOrUpdateBatch(listBean);
	}

	/**
	 * 多条件更新
	 */
	@Override
	public Integer updateByParam(MeetingParticipant bean, MeetingParticipantQuery param) {
		StringTools.checkParam(param);
		return this.meetingParticipantMapper.updateByParam(bean, param);
	}

	/**
	 * 多条件删除
	 */
	@Override
	public Integer deleteByParam(MeetingParticipantQuery param) {
		StringTools.checkParam(param);
		return this.meetingParticipantMapper.deleteByParam(param);
	}

	/**
	 * 根据Id获取对象
	 */
	@Override
	public MeetingParticipant getMeetingParticipantById(Integer id) {
		return this.meetingParticipantMapper.selectById(id);
	}

	/**
	 * 根据Id修改
	 */
	@Override
	public Integer updateMeetingParticipantById(MeetingParticipant bean, Integer id) {
		return this.meetingParticipantMapper.updateById(bean, id);
	}

	/**
	 * 根据Id删除
	 */
	@Override
	public Integer deleteMeetingParticipantById(Integer id) {
		return this.meetingParticipantMapper.deleteById(id);
	}

	/**
	 * 根据MeetingIdAndUserId获取对象
	 */
	@Override
	public MeetingParticipant getMeetingParticipantByMeetingIdAndUserId(Integer meetingId, Integer userId) {
		return this.meetingParticipantMapper.selectByMeetingIdAndUserId(meetingId, userId);
	}

	/**
	 * 根据MeetingIdAndUserId修改
	 */
	@Override
	public Integer updateMeetingParticipantByMeetingIdAndUserId(MeetingParticipant bean, Integer meetingId, Integer userId) {
		return this.meetingParticipantMapper.updateByMeetingIdAndUserId(bean, meetingId, userId);
	}

	/**
	 * 根据MeetingIdAndUserId删除
	 */
	@Override
	public Integer deleteMeetingParticipantByMeetingIdAndUserId(Integer meetingId, Integer userId) {
		return this.meetingParticipantMapper.deleteByMeetingIdAndUserId(meetingId, userId);
	}
}