package com.easymeeting;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@MapperScan("com.easymeeting.mappers")
@EnableScheduling
public class EasyMeetingApplication {
    public static void main(String[] args) {
        SpringApplication.run(EasyMeetingApplication.class, args);
    }
}