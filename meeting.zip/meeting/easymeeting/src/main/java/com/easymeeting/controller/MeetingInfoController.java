package com.easymeeting.controller;

import java.util.List;

import com.easymeeting.entity.query.MeetingInfoQuery;
import com.easymeeting.entity.po.MeetingInfo;
import com.easymeeting.entity.vo.ResponseVO;
import com.easymeeting.service.MeetingInfoService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 会议预约信息表 Controller
 */
@RestController("meetingInfoController")
@RequestMapping("/meetingInfo")
@CrossOrigin
public class MeetingInfoController extends ABaseController{

	@Resource
	private MeetingInfoService meetingInfoService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(MeetingInfoQuery query){
		return getSuccessResponseVO(meetingInfoService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(@RequestBody MeetingInfo bean) {
		meetingInfoService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<MeetingInfo> listBean) {
		meetingInfoService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<MeetingInfo> listBean) {
		meetingInfoService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id查询对象
	 */
	@RequestMapping("/getMeetingInfoById")
	public ResponseVO getMeetingInfoById(Integer id) {
		return getSuccessResponseVO(meetingInfoService.getMeetingInfoById(id));
	}

	/**
	 * 根据Id修改对象
	 */
	@RequestMapping("/updateMeetingInfoById")
	public ResponseVO updateMeetingInfoById(@RequestBody MeetingInfo bean) {
		meetingInfoService.updateMeetingInfoById(bean, bean.getId());
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id删除
	 */
	@RequestMapping("/deleteMeetingInfoById")
	public ResponseVO deleteMeetingInfoById(@RequestBody Integer id) {
		meetingInfoService.deleteMeetingInfoById(id);
		return getSuccessResponseVO(null);
	}
}