package com.easymeeting.entity;
import java.util.Date;
/**
 * 会议参会人实体类
 * 对应数据库表: meeting_participant
 */
public class MeetingParticipant {
    
    private Integer id;
    private Integer meetingId;
    private Integer userId;
    private Integer joinStatus;
    private Date createTime;
    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }
    public Integer getMeetingId() {
        return meetingId;
    }
    public void setMeetingId(Integer meetingId) {
        this.meetingId = meetingId;
    }
    public Integer getUserId() {
        return userId;
    }
    public void setUserId(Integer userId) {
        this.userId = userId;
    }
    public Integer getJoinStatus() {
        return joinStatus;
    }
    public void setJoinStatus(Integer joinStatus) {
        this.joinStatus = joinStatus;
    }
    public Date getCreateTime() {
        return createTime;
    }
    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }
}