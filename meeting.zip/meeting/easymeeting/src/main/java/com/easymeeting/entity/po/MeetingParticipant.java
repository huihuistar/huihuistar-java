package com.easymeeting.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import com.easymeeting.entity.enums.DateTimePatternEnum;
import com.easymeeting.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 会议参会人表
 */
public class MeetingParticipant implements Serializable {


	/**
	 * 参会人记录ID
	 */
	private Integer id;

	/**
	 * 关联会议ID
	 */
	private Integer meetingId;

	/**
	 * 关联参会人用户ID
	 */
	private Integer userId;

	/**
	 * 参会状态 0:未确认 1:已确认 2:拒绝 3:已参会 4:缺席
	 */
	private Integer joinStatus;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setMeetingId(Integer meetingId){
		this.meetingId = meetingId;
	}

	public Integer getMeetingId(){
		return this.meetingId;
	}

	public void setUserId(Integer userId){
		this.userId = userId;
	}

	public Integer getUserId(){
		return this.userId;
	}

	public void setJoinStatus(Integer joinStatus){
		this.joinStatus = joinStatus;
	}

	public Integer getJoinStatus(){
		return this.joinStatus;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	@Override
	public String toString (){
		return "参会人记录ID:"+(id == null ? "空" : id)+"，关联会议ID:"+(meetingId == null ? "空" : meetingId)+"，关联参会人用户ID:"+(userId == null ? "空" : userId)+"，参会状态 0:未确认 1:已确认 2:拒绝 3:已参会 4:缺席:"+(joinStatus == null ? "空" : joinStatus)+"，创建时间:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
