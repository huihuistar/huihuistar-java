package com.easymeeting.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import com.easymeeting.entity.enums.DateTimePatternEnum;
import com.easymeeting.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 会议预约信息表
 */
public class MeetingInfo implements Serializable {


	/**
	 * 会议主键ID
	 */
	private Integer id;

	/**
	 * 会议标题（如：项目启动会/技术评审会）
	 */
	private String meetingTitle;

	/**
	 * 关联会议室ID
	 */
	private Integer roomId;

	/**
	 * 创建人ID（预约人，关联sys_user）
	 */
	private Integer createUserId;

	/**
	 * 会议类型 1:普通会议 2:部门会议 3:公司会议 4:外部会议
	 */
	private Integer meetingType;

	/**
	 * 会议开始时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date startTime;

	/**
	 * 会议结束时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date endTime;

	/**
	 * 会议状态 0:取消 1:待开始 2:进行中 3:已结束
	 */
	private Integer status;

	/**
	 * 会议备注（如：需提前准备资料）
	 */
	private String remark;

	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	/**
	 * 更新时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setMeetingTitle(String meetingTitle){
		this.meetingTitle = meetingTitle;
	}

	public String getMeetingTitle(){
		return this.meetingTitle;
	}

	public void setRoomId(Integer roomId){
		this.roomId = roomId;
	}

	public Integer getRoomId(){
		return this.roomId;
	}

	public void setCreateUserId(Integer createUserId){
		this.createUserId = createUserId;
	}

	public Integer getCreateUserId(){
		return this.createUserId;
	}

	public void setMeetingType(Integer meetingType){
		this.meetingType = meetingType;
	}

	public Integer getMeetingType(){
		return this.meetingType;
	}

	public void setStartTime(Date startTime){
		this.startTime = startTime;
	}

	public Date getStartTime(){
		return this.startTime;
	}

	public void setEndTime(Date endTime){
		this.endTime = endTime;
	}

	public Date getEndTime(){
		return this.endTime;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setRemark(String remark){
		this.remark = remark;
	}

	public String getRemark(){
		return this.remark;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}

	public Date getUpdateTime(){
		return this.updateTime;
	}

	@Override
	public String toString (){
		return "会议主键ID:"+(id == null ? "空" : id)+"，会议标题（如：项目启动会/技术评审会）:"+(meetingTitle == null ? "空" : meetingTitle)+"，关联会议室ID:"+(roomId == null ? "空" : roomId)+"，创建人ID（预约人，关联sys_user）:"+(createUserId == null ? "空" : createUserId)+"，会议类型 1:普通会议 2:部门会议 3:公司会议 4:外部会议:"+(meetingType == null ? "空" : meetingType)+"，会议开始时间:"+(startTime == null ? "空" : DateUtil.format(startTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()))+"，会议结束时间:"+(endTime == null ? "空" : DateUtil.format(endTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()))+"，会议状态 0:取消 1:待开始 2:进行中 3:已结束:"+(status == null ? "空" : status)+"，会议备注（如：需提前准备资料）:"+(remark == null ? "空" : remark)+"，创建时间:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()))+"，更新时间:"+(updateTime == null ? "空" : DateUtil.format(updateTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
