package com.easymeeting.controller;

import java.util.List;

import com.easymeeting.entity.query.MeetingParticipantQuery;
import com.easymeeting.entity.po.MeetingParticipant;
import com.easymeeting.entity.vo.ResponseVO;
import com.easymeeting.service.MeetingParticipantService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 会议参会人表 Controller
 */
@RestController("meetingParticipantController")
@RequestMapping("/meetingParticipant")
public class MeetingParticipantController extends ABaseController{

	@Resource
	private MeetingParticipantService meetingParticipantService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(MeetingParticipantQuery query){
		return getSuccessResponseVO(meetingParticipantService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(MeetingParticipant bean) {
		meetingParticipantService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<MeetingParticipant> listBean) {
		meetingParticipantService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<MeetingParticipant> listBean) {
		meetingParticipantService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id查询对象
	 */
	@RequestMapping("/getMeetingParticipantById")
	public ResponseVO getMeetingParticipantById(Integer id) {
		return getSuccessResponseVO(meetingParticipantService.getMeetingParticipantById(id));
	}

	/**
	 * 根据Id修改对象
	 */
	@RequestMapping("/updateMeetingParticipantById")
	public ResponseVO updateMeetingParticipantById(MeetingParticipant bean,Integer id) {
		meetingParticipantService.updateMeetingParticipantById(bean,id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id删除
	 */
	@RequestMapping("/deleteMeetingParticipantById")
	public ResponseVO deleteMeetingParticipantById(Integer id) {
		meetingParticipantService.deleteMeetingParticipantById(id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据MeetingIdAndUserId查询对象
	 */
	@RequestMapping("/getMeetingParticipantByMeetingIdAndUserId")
	public ResponseVO getMeetingParticipantByMeetingIdAndUserId(Integer meetingId,Integer userId) {
		return getSuccessResponseVO(meetingParticipantService.getMeetingParticipantByMeetingIdAndUserId(meetingId,userId));
	}

	/**
	 * 根据MeetingIdAndUserId修改对象
	 */
	@RequestMapping("/updateMeetingParticipantByMeetingIdAndUserId")
	public ResponseVO updateMeetingParticipantByMeetingIdAndUserId(MeetingParticipant bean,Integer meetingId,Integer userId) {
		meetingParticipantService.updateMeetingParticipantByMeetingIdAndUserId(bean,meetingId,userId);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据MeetingIdAndUserId删除
	 */
	@RequestMapping("/deleteMeetingParticipantByMeetingIdAndUserId")
	public ResponseVO deleteMeetingParticipantByMeetingIdAndUserId(Integer meetingId,Integer userId) {
		meetingParticipantService.deleteMeetingParticipantByMeetingIdAndUserId(meetingId,userId);
		return getSuccessResponseVO(null);
	}
}