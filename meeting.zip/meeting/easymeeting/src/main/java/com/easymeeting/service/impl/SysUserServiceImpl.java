package com.easymeeting.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.easymeeting.entity.enums.PageSize;
import com.easymeeting.entity.query.SysUserQuery;
import com.easymeeting.entity.po.SysUser;
import com.easymeeting.entity.vo.PaginationResultVO;
import com.easymeeting.entity.query.SimplePage;
import com.easymeeting.mappers.SysUserMapper;
import com.easymeeting.service.SysUserService;
import com.easymeeting.utils.StringTools;


/**
 * 系统用户表 业务接口实现
 */
@Service("sysUserService")
public class SysUserServiceImpl implements SysUserService {

	@Resource
	private SysUserMapper<SysUser, SysUserQuery> sysUserMapper;

	/**
	 * 根据条件查询列表
	 */
	@Override
	public List<SysUser> findListByParam(SysUserQuery param) {
		return this.sysUserMapper.selectList(param);
	}

	/**
	 * 根据条件查询列表
	 */
	@Override
	public Integer findCountByParam(SysUserQuery param) {
		return this.sysUserMapper.selectCount(param);
	}

	/**
	 * 分页查询方法
	 */
	@Override
	public PaginationResultVO<SysUser> findListByPage(SysUserQuery param) {
		int count = this.findCountByParam(param);
		int pageSize = param.getPageSize() == null ? PageSize.SIZE15.getSize() : param.getPageSize();

		SimplePage page = new SimplePage(param.getPageNo(), count, pageSize);
		param.setSimplePage(page);
		List<SysUser> list = this.findListByParam(param);
		PaginationResultVO<SysUser> result = new PaginationResultVO(count, page.getPageSize(), page.getPageNo(), page.getPageTotal(), list);
		return result;
	}

	/**
	 * 新增
	 */
	@Override
	public Integer add(SysUser bean) {
		return this.sysUserMapper.insert(bean);
	}

	/**
	 * 批量新增
	 */
	@Override
	public Integer addBatch(List<SysUser> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.sysUserMapper.insertBatch(listBean);
	}

	/**
	 * 批量新增或者修改
	 */
	@Override
	public Integer addOrUpdateBatch(List<SysUser> listBean) {
		if (listBean == null || listBean.isEmpty()) {
			return 0;
		}
		return this.sysUserMapper.insertOrUpdateBatch(listBean);
	}

	/**
	 * 多条件更新
	 */
	@Override
	public Integer updateByParam(SysUser bean, SysUserQuery param) {
		StringTools.checkParam(param);
		return this.sysUserMapper.updateByParam(bean, param);
	}

	/**
	 * 多条件删除
	 */
	@Override
	public Integer deleteByParam(SysUserQuery param) {
		StringTools.checkParam(param);
		return this.sysUserMapper.deleteByParam(param);
	}

	/**
	 * 根据Id获取对象
	 */
	@Override
	public SysUser getSysUserById(Integer id) {
		return this.sysUserMapper.selectById(id);
	}

	/**
	 * 根据Id修改
	 */
	@Override
	public Integer updateSysUserById(SysUser bean, Integer id) {
		return this.sysUserMapper.updateById(bean, id);
	}

	/**
	 * 根据Id删除
	 */
	@Override
	public Integer deleteSysUserById(Integer id) {
		return this.sysUserMapper.deleteById(id);
	}

	/**
	 * 根据UserName获取对象
	 */
	@Override
	public SysUser getSysUserByUserName(String userName) {
		return this.sysUserMapper.selectByUserName(userName);
	}

	/**
	 * 根据UserName修改
	 */
	@Override
	public Integer updateSysUserByUserName(SysUser bean, String userName) {
		return this.sysUserMapper.updateByUserName(bean, userName);
	}

	/**
	 * 根据UserName删除
	 */
	@Override
	public Integer deleteSysUserByUserName(String userName) {
		return this.sysUserMapper.deleteByUserName(userName);
	}

	/**
	 * 根据Phone获取对象
	 */
	@Override
	public SysUser getSysUserByPhone(String phone) {
		return this.sysUserMapper.selectByPhone(phone);
	}

	/**
	 * 根据Phone修改
	 */
	@Override
	public Integer updateSysUserByPhone(SysUser bean, String phone) {
		return this.sysUserMapper.updateByPhone(bean, phone);
	}

	/**
	 * 根据Phone删除
	 */
	@Override
	public Integer deleteSysUserByPhone(String phone) {
		return this.sysUserMapper.deleteByPhone(phone);
	}

	/**
	 * 根据Email获取对象
	 */
	@Override
	public SysUser getSysUserByEmail(String email) {
		return this.sysUserMapper.selectByEmail(email);
	}

	/**
	 * 根据Email修改
	 */
	@Override
	public Integer updateSysUserByEmail(SysUser bean, String email) {
		return this.sysUserMapper.updateByEmail(bean, email);
	}

	/**
	 * 根据Email删除
	 */
	@Override
	public Integer deleteSysUserByEmail(String email) {
		return this.sysUserMapper.deleteByEmail(email);
	}
}