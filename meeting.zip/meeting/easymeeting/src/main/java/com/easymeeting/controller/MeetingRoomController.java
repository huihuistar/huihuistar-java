package com.easymeeting.controller;

import java.util.List;

import com.easymeeting.entity.query.MeetingRoomQuery;
import com.easymeeting.entity.po.MeetingRoom;
import com.easymeeting.entity.vo.ResponseVO;
import com.easymeeting.service.MeetingRoomService;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * 会议室信息表 Controller
 */
@RestController("meetingRoomController")
@RequestMapping("/meetingRoom")
public class MeetingRoomController extends ABaseController{

	@Resource
	private MeetingRoomService meetingRoomService;
	/**
	 * 根据条件分页查询
	 */
	@RequestMapping("/loadDataList")
	public ResponseVO loadDataList(MeetingRoomQuery query){
		return getSuccessResponseVO(meetingRoomService.findListByPage(query));
	}

	/**
	 * 新增
	 */
	@RequestMapping("/add")
	public ResponseVO add(@RequestBody MeetingRoom bean) {
		meetingRoomService.add(bean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增
	 */
	@RequestMapping("/addBatch")
	public ResponseVO addBatch(@RequestBody List<MeetingRoom> listBean) {
		meetingRoomService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 批量新增/修改
	 */
	@RequestMapping("/addOrUpdateBatch")
	public ResponseVO addOrUpdateBatch(@RequestBody List<MeetingRoom> listBean) {
		meetingRoomService.addBatch(listBean);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id查询对象
	 */
	@RequestMapping("/getMeetingRoomById")
	public ResponseVO getMeetingRoomById(Integer id) {
		return getSuccessResponseVO(meetingRoomService.getMeetingRoomById(id));
	}

	/**
	 * 根据Id修改对象
	 */
	@RequestMapping("/updateMeetingRoomById")
	public ResponseVO updateMeetingRoomById(@RequestBody MeetingRoom bean) {
		meetingRoomService.updateMeetingRoomById(bean, bean.getId());
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据Id删除
	 */
	@RequestMapping("/deleteMeetingRoomById")
	public ResponseVO deleteMeetingRoomById(@RequestBody Integer id) {
		meetingRoomService.deleteMeetingRoomById(id);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据RoomName查询对象
	 */
	@RequestMapping("/getMeetingRoomByRoomName")
	public ResponseVO getMeetingRoomByRoomName(String roomName) {
		return getSuccessResponseVO(meetingRoomService.getMeetingRoomByRoomName(roomName));
	}

	/**
	 * 根据RoomName修改对象
	 */
	@RequestMapping("/updateMeetingRoomByRoomName")
	public ResponseVO updateMeetingRoomByRoomName(MeetingRoom bean,String roomName) {
		meetingRoomService.updateMeetingRoomByRoomName(bean,roomName);
		return getSuccessResponseVO(null);
	}

	/**
	 * 根据RoomName删除
	 */
	@RequestMapping("/deleteMeetingRoomByRoomName")
	public ResponseVO deleteMeetingRoomByRoomName(String roomName) {
		meetingRoomService.deleteMeetingRoomByRoomName(roomName);
		return getSuccessResponseVO(null);
	}
}