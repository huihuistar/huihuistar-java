package com.easymeeting.mappers;

import org.apache.ibatis.annotations.Param;

/**
 * 会议室信息表 数据库操作接口
 */
public interface MeetingRoomMapper<T,P> extends BaseMapper<T,P> {

	/**
	 * 根据Id更新
	 */
	 Integer updateById(@Param("bean") T t,@Param("id") Integer id);


	/**
	 * 根据Id删除
	 */
	 Integer deleteById(@Param("id") Integer id);


	/**
	 * 根据Id获取对象
	 */
	 T selectById(@Param("id") Integer id);


	/**
	 * 根据RoomName更新
	 */
	 Integer updateByRoomName(@Param("bean") T t,@Param("roomName") String roomName);


	/**
	 * 根据RoomName删除
	 */
	 Integer deleteByRoomName(@Param("roomName") String roomName);


	/**
	 * 根据RoomName获取对象
	 */
	 T selectByRoomName(@Param("roomName") String roomName);


}
