package com.easymeeting.entity.po;

import com.fasterxml.jackson.annotation.JsonIgnore;
import java.util.Date;
import com.easymeeting.entity.enums.DateTimePatternEnum;
import com.easymeeting.utils.DateUtil;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;


/**
 * 系统用户表
 */
public class SysUser implements Serializable {


	/**
	 * 用户主键ID
	 */
	private Integer id;

	/**
	 * 用户名（登录账号，唯一）
	 */
	private String userName;

	/**
	 * 登录密码（建议MD5/SHA256加密存储）
	 */
	private String password;

	/**
	 * 用户昵称（展示用）
	 */
	private String nickName;

	/**
	 * 手机号（唯一，可选）
	 */
	@JsonIgnore
	private String phone;

	/**
	 * 邮箱（唯一，可选）
	 */
	private String email;

	/**
	 * 性别 0:未知 1:男 2:女
	 */
	private Integer gender;

	/**
	 * 用户状态 0:禁用 1:正常 2:注销
	 */
	private Integer status;

	/**
	 * 创建时间（自动生成）
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date createTime;

	/**
	 * 更新时间（自动更新）
	 */
	@JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
	private Date updateTime;


	public void setId(Integer id){
		this.id = id;
	}

	public Integer getId(){
		return this.id;
	}

	public void setUserName(String userName){
		this.userName = userName;
	}

	public String getUserName(){
		return this.userName;
	}

	public void setPassword(String password){
		this.password = password;
	}

	public String getPassword(){
		return this.password;
	}

	public void setNickName(String nickName){
		this.nickName = nickName;
	}

	public String getNickName(){
		return this.nickName;
	}

	public void setPhone(String phone){
		this.phone = phone;
	}

	public String getPhone(){
		return this.phone;
	}

	public void setEmail(String email){
		this.email = email;
	}

	public String getEmail(){
		return this.email;
	}

	public void setGender(Integer gender){
		this.gender = gender;
	}

	public Integer getGender(){
		return this.gender;
	}

	public void setStatus(Integer status){
		this.status = status;
	}

	public Integer getStatus(){
		return this.status;
	}

	public void setCreateTime(Date createTime){
		this.createTime = createTime;
	}

	public Date getCreateTime(){
		return this.createTime;
	}

	public void setUpdateTime(Date updateTime){
		this.updateTime = updateTime;
	}

	public Date getUpdateTime(){
		return this.updateTime;
	}

	@Override
	public String toString (){
		return "用户主键ID:"+(id == null ? "空" : id)+"，用户名（登录账号，唯一）:"+(userName == null ? "空" : userName)+"，登录密码（建议MD5/SHA256加密存储）:"+(password == null ? "空" : password)+"，用户昵称（展示用）:"+(nickName == null ? "空" : nickName)+"，手机号（唯一，可选）:"+(phone == null ? "空" : phone)+"，邮箱（唯一，可选）:"+(email == null ? "空" : email)+"，性别 0:未知 1:男 2:女:"+(gender == null ? "空" : gender)+"，用户状态 0:禁用 1:正常 2:注销:"+(status == null ? "空" : status)+"，创建时间（自动生成）:"+(createTime == null ? "空" : DateUtil.format(createTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()))+"，更新时间（自动更新）:"+(updateTime == null ? "空" : DateUtil.format(updateTime, DateTimePatternEnum.YYYY_MM_DD_HH_MM_SS.getPattern()));
	}
}
