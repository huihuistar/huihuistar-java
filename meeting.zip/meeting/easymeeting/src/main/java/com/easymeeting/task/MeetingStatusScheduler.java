package com.easymeeting.task;

import com.easymeeting.service.MeetingInfoService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 会议状态自动更新定时任务
 * 每分钟检查一次，根据当前时间自动更新会议状态：
 *   待开始(1) → 进行中(2)：会议已开始且未结束
 *   待开始(1)/进行中(2) → 已结束(3)：会议已过结束时间
 */
@Component
public class MeetingStatusScheduler {

    private static final Logger log = LoggerFactory.getLogger(MeetingStatusScheduler.class);

    @Resource
    private MeetingInfoService meetingInfoService;

    /**
     * 每分钟执行一次
     * 避免重复更新：先把"待开始"更新为"进行中"，再把"已结束"的更新为"已结束"
     * 注意：已结束的会议不会再被"进行中"条件匹配到（因为 end_time <= NOW()）
     */
    @Scheduled(cron = "0 * * * * ?")
    public void autoUpdateStatus() {
        try {
            meetingInfoService.autoUpdateMeetingStatus();
            log.info("会议状态自动更新完成");
        } catch (Exception e) {
            log.error("会议状态自动更新失败", e);
        }
    }
}
