package com.easymeeting.service;

import java.util.List;

import com.easymeeting.entity.query.SysUserQuery;
import com.easymeeting.entity.po.SysUser;
import com.easymeeting.entity.vo.PaginationResultVO;


/**
 * 系统用户表 业务接口
 */
public interface SysUserService {

	/**
	 * 根据条件查询列表
	 */
	List<SysUser> findListByParam(SysUserQuery param);

	/**
	 * 根据条件查询列表
	 */
	Integer findCountByParam(SysUserQuery param);

	/**
	 * 分页查询
	 */
	PaginationResultVO<SysUser> findListByPage(SysUserQuery param);

	/**
	 * 新增
	 */
	Integer add(SysUser bean);

	/**
	 * 批量新增
	 */
	Integer addBatch(List<SysUser> listBean);

	/**
	 * 批量新增/修改
	 */
	Integer addOrUpdateBatch(List<SysUser> listBean);

	/**
	 * 多条件更新
	 */
	Integer updateByParam(SysUser bean,SysUserQuery param);

	/**
	 * 多条件删除
	 */
	Integer deleteByParam(SysUserQuery param);

	/**
	 * 根据Id查询对象
	 */
	SysUser getSysUserById(Integer id);


	/**
	 * 根据Id修改
	 */
	Integer updateSysUserById(SysUser bean,Integer id);


	/**
	 * 根据Id删除
	 */
	Integer deleteSysUserById(Integer id);


	/**
	 * 根据UserName查询对象
	 */
	SysUser getSysUserByUserName(String userName);


	/**
	 * 根据UserName修改
	 */
	Integer updateSysUserByUserName(SysUser bean,String userName);


	/**
	 * 根据UserName删除
	 */
	Integer deleteSysUserByUserName(String userName);


	/**
	 * 根据Phone查询对象
	 */
	SysUser getSysUserByPhone(String phone);


	/**
	 * 根据Phone修改
	 */
	Integer updateSysUserByPhone(SysUser bean,String phone);


	/**
	 * 根据Phone删除
	 */
	Integer deleteSysUserByPhone(String phone);


	/**
	 * 根据Email查询对象
	 */
	SysUser getSysUserByEmail(String email);


	/**
	 * 根据Email修改
	 */
	Integer updateSysUserByEmail(SysUser bean,String email);


	/**
	 * 根据Email删除
	 */
	Integer deleteSysUserByEmail(String email);

}