package com.easymeeting.controller;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;

/**
 * 首页控制器
 */
@org.springframework.stereotype.Controller
public class IndexController {
    
    @GetMapping("/")
    public String index() {
        return "redirect:/static/index.html";
    }

    @GetMapping("/static/index.html")
    @ResponseBody
    public String staticIndex() throws IOException {
        Resource resource = new ClassPathResource("static/index.html");
        try (InputStream inputStream = resource.getInputStream()) {
            return StreamUtils.copyToString(inputStream, StandardCharsets.UTF_8);
        }
    }

    @GetMapping("/test")
    public String test() {
        return "test";
    }
}