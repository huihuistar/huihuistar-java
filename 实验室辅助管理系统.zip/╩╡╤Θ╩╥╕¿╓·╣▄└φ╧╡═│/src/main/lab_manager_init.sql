-- =====================================================
-- 实验室辅助管理系统 - 数据库初始化SQL
-- 系统名称：实验室/教室设备故障上报与维修管理系统
-- 数据库：MySQL 5.7+
-- 创建时间：2026-05-22
-- =====================================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS lab_manager
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE lab_manager;

-- =====================================================
-- 1. 用户表 user
-- 角色分段规则（通过 ID 区间区分）：
--   普通用户   : id 范围 1 ~ 1000
--   维修人员   : id 范围 1001 ~ 1020
--   超级管理员 : id 范围 1021 ~ 1025
-- role 字段：0=普通用户, 1=维修人员, 2=超级管理员（冗余字段，便于查询）
-- =====================================================
DROP TABLE IF EXISTS `repair_order`;
DROP TABLE IF EXISTS `fault`;
DROP TABLE IF EXISTS `site_stat`;
DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
    `id`          INT(11)      NOT NULL AUTO_INCREMENT COMMENT '用户ID（分段：1~1000普通用户，1001~1020维修人员，1021~1025超级管理员）',
    `username`    VARCHAR(50)  NOT NULL COMMENT '登录账号',
    `password`    VARCHAR(255) NOT NULL COMMENT '登录密码（建议存储加密后的哈希值）',
    `role`        TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '角色：0=普通用户，1=维修人员，2=超级管理员',
    `name`        VARCHAR(50)  NOT NULL COMMENT '真实姓名',
    `phone`       VARCHAR(20)           COMMENT '联系电话',
    `create_time` DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '账号创建时间',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_username` (`username`),
    KEY `idx_role` (`role`)
) ENGINE=InnoDB
  AUTO_INCREMENT=1
  DEFAULT CHARSET=utf8mb4
  COMMENT='用户表（统一管理三种角色）';

-- =====================================================
-- 2. 故障上报表 fault
-- status 状态说明：
--   0 = 未派单（刚上报，等待管理员审核/派单）
--   1 = 已派单（待维修）
--   2 = 维修中
--   3 = 已修复
--   4 = 无法修复
--   5 = 无效上报（管理员作废）
-- =====================================================
CREATE TABLE `fault` (
    `id`          INT(11)       NOT NULL AUTO_INCREMENT COMMENT '故障ID',
    `site_type`   TINYINT(1)    NOT NULL COMMENT '场地类型：0=教室，1=实验室',
    `site_num`    VARCHAR(30)   NOT NULL COMMENT '场地编号（如：A101、LAB-201）',
    `device_name` VARCHAR(100)  NOT NULL COMMENT '故障设备/仪器名称',
    `fault_desc`  TEXT          NOT NULL COMMENT '故障详细描述',
    `user_id`     INT(11)       NOT NULL COMMENT '上报人用户ID（外键 → user.id）',
    `status`      TINYINT(1)    NOT NULL DEFAULT 0 COMMENT '故障状态：0=未派单,1=已派单,2=维修中,3=已修复,4=无法修复,5=无效上报',
    `upload_time` DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '上报时间',
    PRIMARY KEY (`id`),
    KEY `idx_user_id` (`user_id`),
    KEY `idx_site_num` (`site_num`),
    KEY `idx_status` (`status`),
    KEY `idx_upload_time` (`upload_time`),
    CONSTRAINT `fk_fault_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB
  AUTO_INCREMENT=1
  DEFAULT CHARSET=utf8mb4
  COMMENT='故障上报表';

-- =====================================================
-- 3. 维修工单表 repair_order
-- repair_status 状态说明：
--   0 = 待维修（刚派单，未开始）
--   1 = 维修中
--   2 = 已修复
--   3 = 无法修复
-- =====================================================
CREATE TABLE `repair_order` (
    `id`             INT(11)      NOT NULL AUTO_INCREMENT COMMENT '工单ID',
    `fault_id`       INT(11)      NOT NULL COMMENT '关联故障ID（外键 → fault.id）',
    `repair_user_id` INT(11)      NOT NULL COMMENT '维修人员ID（id 范围 1001~1020）',
    `admin_id`       INT(11)      NOT NULL COMMENT '派单管理员ID（id 范围 1021~1025）',
    `assign_time`    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '派单时间',
    `repair_status`  TINYINT(1)   NOT NULL DEFAULT 0 COMMENT '维修状态：0=待维修,1=维修中,2=已修复,3=无法修复',
    `repair_result`  VARCHAR(500)          COMMENT '维修结果备注（维修人员填写）',
    `finish_time`    DATETIME              COMMENT '完工时间（状态变为已修复/无法修复时记录）',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_fault_id` (`fault_id`) COMMENT '一个故障只生成一张工单',
    KEY `idx_repair_user_id` (`repair_user_id`),
    KEY `idx_admin_id` (`admin_id`),
    KEY `idx_repair_status` (`repair_status`),
    CONSTRAINT `fk_repair_fault` FOREIGN KEY (`fault_id`) REFERENCES `fault` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_repair_user` FOREIGN KEY (`repair_user_id`) REFERENCES `user` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,
    CONSTRAINT `fk_repair_admin` FOREIGN KEY (`admin_id`) REFERENCES `user` (`id`)
        ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB
  AUTO_INCREMENT=1
  DEFAULT CHARSET=utf8mb4
  COMMENT='维修工单表';

-- =====================================================
-- 4. 场地故障统计表 site_stat（前缀和算法数据源）
-- 每次故障上报时由触发器自动累加 daily_count
-- 前缀和查询（后端SQL）：
--   SELECT SUM(daily_count) FROM site_stat
--   WHERE site_num = ? AND stat_date BETWEEN ? AND ?
-- =====================================================
CREATE TABLE `site_stat` (
    `id`          INT(11)     NOT NULL AUTO_INCREMENT COMMENT '主键',
    `site_num`    VARCHAR(30) NOT NULL COMMENT '场地编号（与 fault.site_num 一致）',
    `stat_date`   DATE        NOT NULL COMMENT '统计日期',
    `daily_count` INT(11)     NOT NULL DEFAULT 0 COMMENT '当日故障上报数量',
    PRIMARY KEY (`id`),
    UNIQUE KEY `uk_site_date` (`site_num`, `stat_date`) COMMENT '同一场地同一日期唯一',
    KEY `idx_stat_date` (`stat_date`),
    KEY `idx_site_num` (`site_num`)
) ENGINE=InnoDB
  AUTO_INCREMENT=1
  DEFAULT CHARSET=utf8mb4
  COMMENT='场地故障统计表（前缀和算法数据源）';


-- =====================================================
-- 初始化数据：预置账号
-- 密码：MD5('123456') = e10adc3949ba59abbe56e057f20f883e
-- 生产环境建议使用 BCrypt 算法
-- =====================================================

-- 超级管理员（id = 1021）
INSERT INTO `user` (`id`, `username`, `password`, `role`, `name`, `phone`) VALUES
(1021, 'admin', 'e10adc3949ba59abbe56e057f20f883e', 2, '超级管理员', '13800000000');

-- 维修人员（id = 1001 ~ 1003）
INSERT INTO `user` (`id`, `username`, `password`, `role`, `name`, `phone`) VALUES
(1001, 'repair01', 'e10adc3949ba59abbe56e057f20f883e', 1, '张师傅', '13811111111'),
(1002, 'repair02', 'e10adc3949ba59abbe56e057f20f883e', 1, '李师傅', '13822222222'),
(1003, 'repair03', 'e10adc3949ba59abbe56e057f20f883e', 1, '王师傅', '13833333333');

-- 普通用户（id = 1, 2）
INSERT INTO `user` (`id`, `username`, `password`, `role`, `name`, `phone`) VALUES
(1, 'student01', 'e10adc3949ba59abbe56e057f20f883e', 0, '测试学生甲', '13844444444'),
(2, 'teacher01', 'e10adc3949ba59abbe56e057f20f883e', 0, '测试教职工甲', '13855555555');

-- 重置自增种子为学生区间起点（3），后续注册学生自动获得 3,4,5...
-- 维修人员由 Java 代码显式分配 1001~1020 区间 ID
ALTER TABLE `user` AUTO_INCREMENT = 3;


-- =====================================================
-- 示例数据：故障上报
-- =====================================================
INSERT INTO `fault` (`site_type`, `site_num`, `device_name`, `fault_desc`, `user_id`, `status`, `upload_time`) VALUES
(1, 'LAB-201', '投影仪',    '投影仪无法正常开机，按电源键无反应',          1, 0, '2026-05-20 09:00:00'),
(1, 'LAB-202', '电脑主机',  '计算机主机频繁蓝屏，已影响上课使用',          2, 1, '2026-05-21 10:30:00'),
(0, 'CLASS-301','空调',     '空调不制冷，室内温度持续偏高',               1, 2, '2026-05-22 08:00:00');

-- =====================================================
-- 示例数据：维修工单
-- =====================================================
INSERT INTO `repair_order` (`fault_id`, `repair_user_id`, `admin_id`, `assign_time`, `repair_status`, `repair_result`, `finish_time`) VALUES
(2, 1001, 1021, '2026-05-21 14:00:00', 1, '内存条松动，正在处理中', NULL),
(3, 1002, 1021, '2026-05-22 09:00:00', 1, '维修人员已到场检查',     NULL);

-- =====================================================
-- 示例数据：场地故障统计
-- =====================================================
INSERT INTO `site_stat` (`site_num`, `stat_date`, `daily_count`) VALUES
('LAB-201',   '2026-05-18', 2),
('LAB-201',   '2026-05-19', 1),
('LAB-201',   '2026-05-20', 1),
('LAB-202',   '2026-05-21', 1),
('CLASS-301', '2026-05-22', 1);


-- =====================================================
-- 常用视图：故障与工单联查（供后端直接查询）
-- =====================================================
CREATE OR REPLACE VIEW `v_fault_repair` AS
SELECT
    f.id              AS fault_id,
    CASE f.site_type WHEN 0 THEN '教室' WHEN 1 THEN '实验室' END AS site_type_name,
    f.site_num,
    f.device_name,
    f.fault_desc,
    f.upload_time,
    CASE f.status
        WHEN 0 THEN '未派单'
        WHEN 1 THEN '已派单'
        WHEN 2 THEN '维修中'
        WHEN 3 THEN '已修复'
        WHEN 4 THEN '无法修复'
        WHEN 5 THEN '无效上报'
    END               AS fault_status_name,
    u_rep.name        AS reporter_name,
    u_rep.phone       AS reporter_phone,
    ro.id             AS order_id,
    CASE ro.repair_status
        WHEN 0 THEN '待维修'
        WHEN 1 THEN '维修中'
        WHEN 2 THEN '已修复'
        WHEN 3 THEN '无法修复'
    END               AS repair_status_name,
    ro.repair_result,
    ro.assign_time,
    ro.finish_time,
    u_wkr.name        AS worker_name,
    u_wkr.phone       AS worker_phone,
    u_adm.name        AS admin_name
FROM `fault` f
LEFT JOIN `user`         u_rep ON f.user_id        = u_rep.id
LEFT JOIN `repair_order` ro    ON f.id             = ro.fault_id
LEFT JOIN `user`         u_wkr ON ro.repair_user_id = u_wkr.id
LEFT JOIN `user`         u_adm ON ro.admin_id       = u_adm.id;


-- =====================================================
-- 触发器1：工单状态变更时同步更新 fault.status
-- =====================================================
DELIMITER $$

DROP TRIGGER IF EXISTS trg_sync_fault_status$$
CREATE TRIGGER trg_sync_fault_status
AFTER UPDATE ON `repair_order`
FOR EACH ROW
BEGIN
    DECLARE new_fault_status TINYINT(1);
    -- repair_status 0→待维修→fault.status=1(已派单)
    -- repair_status 1→维修中→fault.status=2
    -- repair_status 2→已修复→fault.status=3
    -- repair_status 3→无法修复→fault.status=4
    CASE NEW.repair_status
        WHEN 0 THEN SET new_fault_status = 1;
        WHEN 1 THEN SET new_fault_status = 2;
        WHEN 2 THEN SET new_fault_status = 3;
        WHEN 3 THEN SET new_fault_status = 4;
        ELSE        SET new_fault_status = 1;
    END CASE;
    UPDATE `fault` SET status = new_fault_status WHERE id = NEW.fault_id;
END$$

-- =====================================================
-- 触发器2：新增故障上报时自动累加 site_stat 每日统计
-- =====================================================
DROP TRIGGER IF EXISTS trg_update_site_stat$$
CREATE TRIGGER trg_update_site_stat
AFTER INSERT ON `fault`
FOR EACH ROW
BEGIN
    INSERT INTO `site_stat` (`site_num`, `stat_date`, `daily_count`)
    VALUES (NEW.site_num, DATE(NEW.upload_time), 1)
    ON DUPLICATE KEY UPDATE `daily_count` = `daily_count` + 1;
END$$

DELIMITER ;


-- =====================================================
-- 验证：前缀和查询示例
-- 查询 LAB-201 在 2026-05-18 ~ 2026-05-20 故障总次数
-- =====================================================
-- SELECT SUM(daily_count) AS total_fault_count
-- FROM site_stat
-- WHERE site_num = 'LAB-201'
--   AND stat_date BETWEEN '2026-05-18' AND '2026-05-20';
-- 预期结果：2 + 1 + 1 = 4

SELECT '========================================' AS '';
SELECT '  lab_manager 数据库初始化完成！         ' AS '';
SELECT '  预置账号密码统一为：123456             ' AS '';
SELECT '  admin(管理员)                          ' AS '';
SELECT '  repair01 / repair02 / repair03(维修人员)' AS '';
SELECT '  student01 / teacher01(普通用户)        ' AS '';
SELECT '========================================' AS '';
