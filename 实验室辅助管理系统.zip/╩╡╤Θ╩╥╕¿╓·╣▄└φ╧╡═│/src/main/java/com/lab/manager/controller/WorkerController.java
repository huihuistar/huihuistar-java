package com.lab.manager.controller;

import com.lab.manager.common.Result;
import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.RepairOrder;
import com.lab.manager.entity.User;
import com.lab.manager.service.RepairOrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 维修人员 Controller
 */
@Controller
@RequestMapping("/worker")
public class WorkerController {

    private static final Logger log = LoggerFactory.getLogger(WorkerController.class);

    @Autowired
    private RepairOrderService repairOrderService;

    /** 维修人员首页 */
    @GetMapping("/index")
    public String index(HttpSession session, Model model) {
        try {
            User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
            List<RepairOrder> orders = repairOrderService.getByRepairUserId(loginUser.getId());
            model.addAttribute("orders", orders);
            model.addAttribute("user", loginUser);
            return "worker/index";
        } catch (Exception e) {
            log.error("维修人员首页加载失败", e);
            model.addAttribute("error", e.getMessage());
            return "error";
        }
    }

    /** 获取我的工单列表（JSON） */
    @GetMapping("/api/orders")
    @ResponseBody
    public Result<List<RepairOrder>> myOrders(HttpSession session) {
        User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
        List<RepairOrder> orders = repairOrderService.getByRepairUserId(loginUser.getId());
        return Result.ok(orders);
    }

    /**
     * 更新工单状态（JSON）
     * 只能更新自己的工单
     */
    @PutMapping("/api/order/{orderId}/status")
    @ResponseBody
    public Result<Void> updateStatus(@PathVariable Integer orderId,
                                      @RequestParam Integer repairStatus,
                                      @RequestParam(required = false) String repairResult,
                                      HttpSession session) {
        User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
        // 校验工单归属
        RepairOrder order = repairOrderService.getById(orderId);
        if (order == null || !order.getRepairUserId().equals(loginUser.getId())) {
            return Result.fail("无权操作此工单");
        }
        boolean ok = repairOrderService.updateStatus(orderId, repairStatus, repairResult);
        return ok ? Result.ok(null) : Result.fail("更新失败");
    }
}
