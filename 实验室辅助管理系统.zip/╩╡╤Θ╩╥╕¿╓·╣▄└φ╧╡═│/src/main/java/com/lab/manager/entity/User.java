package com.lab.manager.entity;

import lombok.Data;
import java.util.Date;

/**
 * 用户表实体
 * id 分段：1~1000=普通用户，1001~1020=维修人员，1021~1025=超级管理员
 */
@Data
public class User {
    private Integer id;
    private String username;
    private String password;
    /** 角色：0=普通用户，1=维修人员，2=超级管理员 */
    private Integer role;
    private String name;
    private String phone;
    private Date createTime;
}
