package com.lab.manager.mapper;

import org.apache.ibatis.annotations.Param;

public interface SiteStatMapper {
    /**
     * 前缀和查询：某场地在[startDate, endDate]内的故障总次数
     */
    int sumByDateRange(@Param("siteNum") String siteNum,
                       @Param("startDate") String startDate,
                       @Param("endDate") String endDate);
}
