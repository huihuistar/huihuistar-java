package com.lab.manager.entity;

import lombok.Data;
import java.util.Date;

/**
 * 场地故障统计表（前缀和算法数据源）
 */
@Data
public class SiteStat {
    private Integer id;
    private String siteNum;
    private Date statDate;
    private Integer dailyCount;
}
