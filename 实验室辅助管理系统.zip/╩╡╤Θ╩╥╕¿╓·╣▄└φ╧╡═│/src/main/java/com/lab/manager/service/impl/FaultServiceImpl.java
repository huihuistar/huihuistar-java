package com.lab.manager.service.impl;

import com.lab.manager.entity.Fault;
import com.lab.manager.mapper.FaultMapper;
import com.lab.manager.service.FaultService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class FaultServiceImpl implements FaultService {

    @Autowired
    private FaultMapper faultMapper;

    @Override
    public List<Fault> getAll() {
        return faultMapper.findAll();
    }

    @Override
    public List<Fault> getByUserId(Integer userId) {
        return faultMapper.findByUserId(userId);
    }

    @Override
    public Fault getById(Integer id) {
        return faultMapper.findById(id);
    }

    @Override
    public boolean report(Fault fault) {
        return faultMapper.insert(fault) > 0;
    }

    @Override
    public boolean update(Fault fault) {
        return faultMapper.update(fault) > 0;
    }

    @Override
    public boolean updateStatus(Integer id, Integer status) {
        return faultMapper.updateStatus(id, status) > 0;
    }

    @Override
    public boolean delete(Integer id) {
        return faultMapper.deleteById(id) > 0;
    }
}
