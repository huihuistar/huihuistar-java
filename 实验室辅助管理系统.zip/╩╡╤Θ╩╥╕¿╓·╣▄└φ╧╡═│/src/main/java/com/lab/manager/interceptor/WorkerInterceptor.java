package com.lab.manager.interceptor;

import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.User;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 维修人员权限拦截器：只允许维修人员访问 /worker/** 路径
 */
public class WorkerInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                              HttpServletResponse response,
                              Object handler) throws Exception {
        User loginUser = (User) request.getSession().getAttribute(RoleConst.SESSION_USER);
        if (loginUser == null || loginUser.getRole() != RoleConst.ROLE_WORKER) {
            response.sendRedirect(request.getContextPath() + "/login?msg=no_permission");
            return false;
        }
        return true;
    }
}
