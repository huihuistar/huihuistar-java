package com.lab.manager.service;

import com.lab.manager.entity.Fault;
import java.util.List;

public interface FaultService {
    List<Fault> getAll();
    List<Fault> getByUserId(Integer userId);
    Fault getById(Integer id);
    boolean report(Fault fault);
    boolean update(Fault fault);
    boolean updateStatus(Integer id, Integer status);
    boolean delete(Integer id);
}
