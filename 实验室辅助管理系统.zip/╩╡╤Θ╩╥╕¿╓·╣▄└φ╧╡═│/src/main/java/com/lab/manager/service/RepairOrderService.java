package com.lab.manager.service;

import com.lab.manager.entity.RepairOrder;
import java.util.List;

public interface RepairOrderService {
    List<RepairOrder> getAll();
    List<RepairOrder> getByRepairUserId(Integer repairUserId);
    RepairOrder getByFaultId(Integer faultId);
    RepairOrder getById(Integer id);
    /** 管理员派单 */
    boolean assign(Integer faultId, Integer repairUserId, Integer adminId);
    /** 维修人员更新工单状态 */
    boolean updateStatus(Integer orderId, Integer repairStatus, String repairResult);
    boolean delete(Integer id);
}
