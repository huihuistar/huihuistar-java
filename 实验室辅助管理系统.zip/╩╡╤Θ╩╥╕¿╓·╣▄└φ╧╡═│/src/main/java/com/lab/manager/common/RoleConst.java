package com.lab.manager.common;

/**
 * 角色常量
 * 普通用户 id: 1~1000    role=0
 * 维修人员 id: 1001~1020  role=1
 * 超级管理员 id: 1021~1025 role=2
 */
public class RoleConst {
    public static final int ROLE_USER   = 0;  // 普通用户
    public static final int ROLE_WORKER = 1;  // 维修人员
    public static final int ROLE_ADMIN  = 2;  // 超级管理员

    // 故障状态
    public static final int FAULT_UNASSIGNED  = 0; // 未派单
    public static final int FAULT_ASSIGNED    = 1; // 已派单
    public static final int FAULT_REPAIRING   = 2; // 维修中
    public static final int FAULT_FIXED       = 3; // 已修复
    public static final int FAULT_UNFIXABLE   = 4; // 无法修复
    public static final int FAULT_INVALID     = 5; // 无效上报

    // 工单状态
    public static final int ORDER_PENDING    = 0; // 待维修
    public static final int ORDER_REPAIRING  = 1; // 维修中
    public static final int ORDER_FIXED      = 2; // 已修复
    public static final int ORDER_UNFIXABLE  = 3; // 无法修复

    // Session key
    public static final String SESSION_USER = "loginUser";
}
