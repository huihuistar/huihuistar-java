package com.lab.manager.controller;

import com.lab.manager.common.Result;
import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.Fault;
import com.lab.manager.entity.RepairOrder;
import com.lab.manager.entity.User;
import com.lab.manager.service.FaultService;
import com.lab.manager.service.RepairOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * 普通用户 Controller
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private FaultService faultService;

    @Autowired
    private RepairOrderService repairOrderService;

    /** 普通用户首页 */
    @GetMapping("/index")
    public String index(HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
        if (loginUser == null || loginUser.getRole() != RoleConst.ROLE_USER) {
            return "redirect:/login";
        }
        model.addAttribute("user", loginUser);
        return "user/index";
    }

    /** 故障上报页 */
    @GetMapping("/report")
    public String reportPage() {
        return "user/report";
    }

    /** 提交上报（JSON） */
    @PostMapping("/api/fault/report")
    @ResponseBody
    public Result<Void> report(@RequestBody Fault fault, HttpSession session) {
        User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
        if (loginUser == null) return Result.fail("未登录");
        fault.setUserId(loginUser.getId());
        boolean ok = faultService.report(fault);
        return ok ? Result.ok(null) : Result.fail("上报失败，请重试");
    }

    /** 我的上报记录页 */
    @GetMapping("/my-reports")
    public String myReports(HttpSession session, Model model) {
        User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
        List<Fault> faults = faultService.getByUserId(loginUser.getId());
        model.addAttribute("faults", faults);
        return "user/my-reports";
    }

    /** 查询某条故障的维修进度（JSON） */
    @GetMapping("/api/fault/{faultId}/progress")
    @ResponseBody
    public Result<RepairOrder> progress(@PathVariable Integer faultId, HttpSession session) {
        User loginUser = (User) session.getAttribute(RoleConst.SESSION_USER);
        // 校验该故障属于当前用户
        Fault fault = faultService.getById(faultId);
        if (fault == null || !fault.getUserId().equals(loginUser.getId())) {
            return Result.fail("无权查看");
        }
        RepairOrder order = repairOrderService.getByFaultId(faultId);
        if (order == null) return Result.fail("暂未派单，请耐心等待");
        return Result.ok(order);
    }
}
