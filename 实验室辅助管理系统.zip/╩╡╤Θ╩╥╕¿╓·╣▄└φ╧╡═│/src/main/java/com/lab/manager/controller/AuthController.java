package com.lab.manager.controller;

import com.lab.manager.common.Result;
import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.User;
import com.lab.manager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@Controller
public class AuthController {

    @Autowired
    private UserService userService;

    /** 跳转登录页 */
    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    /** 登录接口（JSON） */
    @PostMapping("/api/auth/login")
    @ResponseBody
    public Result<User> login(@RequestParam String username,
                               @RequestParam String password,
                               HttpSession session) {
        User user = userService.login(username, password);
        if (user == null) {
            return Result.fail("用户名或密码错误");
        }
        // 密码不回传给前端
        user.setPassword(null);
        session.setAttribute(RoleConst.SESSION_USER, user);
        return Result.ok("登录成功", user);
    }

    /** 登出 */
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }
}
