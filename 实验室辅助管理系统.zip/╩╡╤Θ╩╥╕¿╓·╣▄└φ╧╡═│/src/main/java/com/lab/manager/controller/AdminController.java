package com.lab.manager.controller;

import com.lab.manager.common.Result;
import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.Fault;
import com.lab.manager.entity.RepairOrder;
import com.lab.manager.entity.User;
import com.lab.manager.mapper.SiteStatMapper;
import com.lab.manager.service.FaultService;
import com.lab.manager.service.RepairOrderService;
import com.lab.manager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 超级管理员 Controller
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired private FaultService faultService;
    @Autowired private RepairOrderService repairOrderService;
    @Autowired private UserService userService;
    @Autowired private SiteStatMapper siteStatMapper;

    // ==================== 页面跳转 ====================

    @GetMapping("/index")
    public String index(Model model) {
        model.addAttribute("faultCount",  faultService.getAll().size());
        model.addAttribute("orderCount",  repairOrderService.getAll().size());
        model.addAttribute("workerCount", userService.getAllWorkers().size());
        return "admin/index";
    }

    @GetMapping("/fault-list")
    public String faultList(Model model) {
        model.addAttribute("faults", faultService.getAll());
        model.addAttribute("workers", userService.getAllWorkers());
        return "admin/fault-list";
    }

    @GetMapping("/order-list")
    public String orderList(Model model) {
        model.addAttribute("orders", repairOrderService.getAll());
        return "admin/order-list";
    }

    @GetMapping("/user-manage")
    public String userManage(Model model) {
        model.addAttribute("allUsers", userService.getAll());
        return "admin/user-manage";
    }

    @GetMapping("/statistics")
    public String statistics() {
        return "admin/statistics";
    }

    // ==================== 故障 CRUD API ====================

    @GetMapping("/api/fault/list")
    @ResponseBody
    public Result<List<Fault>> faultListApi() {
        return Result.ok(faultService.getAll());
    }

    @PutMapping("/api/fault/{id}/status")
    @ResponseBody
    public Result<Void> updateFaultStatus(@PathVariable Integer id,
                                           @RequestParam Integer status) {
        faultService.updateStatus(id, status);
        return Result.ok(null);
    }

    @PutMapping("/api/fault/{id}/void")
    @ResponseBody
    public Result<Void> voidFault(@PathVariable Integer id) {
        faultService.updateStatus(id, RoleConst.FAULT_INVALID);
        return Result.ok("已作废", null);
    }

    @DeleteMapping("/api/fault/{id}")
    @ResponseBody
    public Result<Void> deleteFault(@PathVariable Integer id) {
        faultService.delete(id);
        return Result.ok(null);
    }

    // ==================== 派单 API ====================

    @PostMapping("/api/order/assign")
    @ResponseBody
    public Result<Void> assign(@RequestParam Integer faultId,
                                @RequestParam Integer repairUserId,
                                HttpSession session) {
        User admin = (User) session.getAttribute(RoleConst.SESSION_USER);
        repairOrderService.assign(faultId, repairUserId, admin.getId());
        return Result.ok("派单成功", null);
    }

    // ==================== 用户管理 API ====================

    @GetMapping("/api/user/list")
    @ResponseBody
    public Result<List<User>> userList(@RequestParam(required = false) Integer role) {
        List<User> list = (role != null) ? userService.getAll() : userService.getAll();
        // 清除密码字段
        list.forEach(u -> u.setPassword(null));
        return Result.ok(list);
    }

    @PostMapping("/api/user/add")
    @ResponseBody
    public Result<Void> addUser(@RequestBody User user) {
        userService.addUser(user);
        return Result.ok(null);
    }

    @PutMapping("/api/user/{id}")
    @ResponseBody
    public Result<Void> updateUser(@PathVariable Integer id, @RequestBody User user) {
        user.setId(id);
        userService.updateUser(user);
        return Result.ok(null);
    }

    @DeleteMapping("/api/user/{id}")
    @ResponseBody
    public Result<Void> deleteUser(@PathVariable Integer id) {
        userService.deleteUser(id);
        return Result.ok(null);
    }

    @GetMapping("/api/worker/list")
    @ResponseBody
    public Result<List<User>> workerList() {
        List<User> workers = userService.getAllWorkers();
        workers.forEach(u -> u.setPassword(null));
        return Result.ok(workers);
    }

    // ==================== 前缀和统计 API ====================

    /**
     * 前缀和统计：查询某场地在[startDate, endDate]内的故障总次数
     */
    @GetMapping("/api/stat/fault-count")
    @ResponseBody
    public Result<Map<String, Object>> faultCount(@RequestParam String siteNum,
                                                   @RequestParam String startDate,
                                                   @RequestParam String endDate) {
        int total = siteStatMapper.sumByDateRange(siteNum, startDate, endDate);
        Map<String, Object> data = new HashMap<>();
        data.put("siteNum", siteNum);
        data.put("startDate", startDate);
        data.put("endDate", endDate);
        data.put("total", total);
        return Result.ok(data);
    }
}
