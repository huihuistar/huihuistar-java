package com.lab.manager.mapper;

import com.lab.manager.entity.User;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface UserMapper {
    /** 根据用户名查询（登录用） */
    User findByUsername(@Param("username") String username);

    /** 查询所有维修人员（派单下拉列表） */
    List<User> findAllWorkers();

    /** 查询所有普通用户 */
    List<User> findAllUsers();

    /** 查询所有用户 */
    List<User> findAll();

    /** 根据角色查询 */
    List<User> findByRole(@Param("role") Integer role);

    /** 根据ID查询 */
    User findById(@Param("id") Integer id);

    /** 查询某角色的最大ID（用于分配新ID） */
    Integer findMaxIdByRole(@Param("role") Integer role);

    /** 新增用户 */
    int insert(User user);

    /** 更新用户（不含密码） */
    int update(User user);

    /** 更新密码 */
    int updatePassword(@Param("id") Integer id, @Param("password") String password);

    /** 删除用户 */
    int deleteById(@Param("id") Integer id);
}
