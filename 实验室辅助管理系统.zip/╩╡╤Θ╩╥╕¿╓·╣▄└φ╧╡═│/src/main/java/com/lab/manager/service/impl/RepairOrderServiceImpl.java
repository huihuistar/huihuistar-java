package com.lab.manager.service.impl;

import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.RepairOrder;
import com.lab.manager.mapper.FaultMapper;
import com.lab.manager.mapper.RepairOrderMapper;
import com.lab.manager.service.RepairOrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class RepairOrderServiceImpl implements RepairOrderService {

    @Autowired
    private RepairOrderMapper repairOrderMapper;

    @Autowired
    private FaultMapper faultMapper;

    @Override
    public List<RepairOrder> getAll() {
        return repairOrderMapper.findAll();
    }

    @Override
    public List<RepairOrder> getByRepairUserId(Integer repairUserId) {
        return repairOrderMapper.findByRepairUserId(repairUserId);
    }

    @Override
    public RepairOrder getByFaultId(Integer faultId) {
        return repairOrderMapper.findByFaultId(faultId);
    }

    @Override
    public RepairOrder getById(Integer id) {
        return repairOrderMapper.findById(id);
    }

    /**
     * 管理员派单：
     * 1. 生成维修工单
     * 2. 更新故障状态为"已派单(1)"
     */
    @Override
    @Transactional
    public boolean assign(Integer faultId, Integer repairUserId, Integer adminId) {
        RepairOrder order = new RepairOrder();
        order.setFaultId(faultId);
        order.setRepairUserId(repairUserId);
        order.setAdminId(adminId);
        repairOrderMapper.insert(order);
        // 更新故障状态 → 已派单
        faultMapper.updateStatus(faultId, RoleConst.FAULT_ASSIGNED);
        return true;
    }

    /**
     * 维修人员更新工单状态：
     * 同步更新故障表状态（也可依赖触发器，此处双保险）
     */
    @Override
    @Transactional
    public boolean updateStatus(Integer orderId, Integer repairStatus, String repairResult) {
        RepairOrder order = new RepairOrder();
        order.setId(orderId);
        order.setRepairStatus(repairStatus);
        order.setRepairResult(repairResult);
        repairOrderMapper.updateStatus(order);

        // 同步 fault.status
        RepairOrder existing = repairOrderMapper.findById(orderId);
        if (existing != null) {
            int faultStatus;
            switch (repairStatus) {
                case 0: faultStatus = RoleConst.FAULT_ASSIGNED;  break;
                case 1: faultStatus = RoleConst.FAULT_REPAIRING; break;
                case 2: faultStatus = RoleConst.FAULT_FIXED;     break;
                case 3: faultStatus = RoleConst.FAULT_UNFIXABLE; break;
                default: faultStatus = RoleConst.FAULT_ASSIGNED;
            }
            faultMapper.updateStatus(existing.getFaultId(), faultStatus);
        }
        return true;
    }

    @Override
    public boolean delete(Integer id) {
        return repairOrderMapper.deleteById(id) > 0;
    }
}
