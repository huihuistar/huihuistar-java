package com.lab.manager.entity;

import lombok.Data;
import java.util.Date;

/**
 * 故障上报表实体
 * status: 0=未派单,1=已派单,2=维修中,3=已修复,4=无法修复,5=无效上报
 */
@Data
public class Fault {
    private Integer id;
    /** 场地类型：0=教室，1=实验室 */
    private Integer siteType;
    private String siteNum;
    private String deviceName;
    private String faultDesc;
    private Integer userId;
    /** 故障状态 */
    private Integer status;
    private Date uploadTime;

    // ===== 联查非数据库字段 =====
    /** 上报人姓名（联查） */
    private String reporterName;
    /** 场地类型中文（联查） */
    private String siteTypeName;
    /** 状态中文（联查） */
    private String statusName;
}
