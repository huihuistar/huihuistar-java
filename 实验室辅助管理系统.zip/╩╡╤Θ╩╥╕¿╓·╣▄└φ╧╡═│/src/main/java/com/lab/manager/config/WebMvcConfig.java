package com.lab.manager.config;

import com.lab.manager.interceptor.AdminInterceptor;
import com.lab.manager.interceptor.LoginInterceptor;
import com.lab.manager.interceptor.WorkerInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebMvcConfig implements WebMvcConfigurer {

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        // 全局登录拦截（排除登录、静态资源）
        registry.addInterceptor(new LoginInterceptor())
                .addPathPatterns("/**")
                .excludePathPatterns("/login", "/api/auth/login", "/css/**", "/js/**", "/error");

        // 管理员路径拦截
        registry.addInterceptor(new AdminInterceptor())
                .addPathPatterns("/admin/**", "/api/admin/**");

        // 维修人员路径拦截
        registry.addInterceptor(new WorkerInterceptor())
                .addPathPatterns("/worker/**", "/api/worker/**");
    }
}
