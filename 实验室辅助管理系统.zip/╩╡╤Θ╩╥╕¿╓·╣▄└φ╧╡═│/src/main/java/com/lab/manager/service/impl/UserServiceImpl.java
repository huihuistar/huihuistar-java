package com.lab.manager.service.impl;

import com.lab.manager.entity.User;
import com.lab.manager.mapper.UserMapper;
import com.lab.manager.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.DigestUtils;
import java.util.List;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    /** MD5 加密密码 */
    private String md5(String password) {
        return DigestUtils.md5DigestAsHex(password.getBytes());
    }

    @Override
    public User login(String username, String password) {
        User user = userMapper.findByUsername(username);
        if (user == null) return null;
        if (!user.getPassword().equals(md5(password))) return null;
        return user;
    }

    @Override
    public List<User> getAllWorkers() {
        return userMapper.findAllWorkers();
    }

    @Override
    public List<User> getAllUsers() {
        return userMapper.findAllUsers();
    }

    @Override
    public List<User> getAll() {
        return userMapper.findAll();
    }

    @Override
    public User getById(Integer id) {
        return userMapper.findById(id);
    }

    @Override
    public boolean addUser(User user) {
        user.setPassword(md5(user.getPassword()));
        // 维修人员（role=1）：需要显式分配 1001~1020 区间 ID
        if (user.getRole() != null && user.getRole() == 1) {
            Integer maxId = userMapper.findMaxIdByRole(1);
            int nextId = (maxId == null || maxId < 1001) ? 1001 : maxId + 1;
            if (nextId > 1020) {
                throw new RuntimeException("维修人员数量已达上限（20人）");
            }
            user.setId(nextId);
        }
        // 普通学生（role=0）：不设 id，由数据库 AUTO_INCREMENT（从3起）自动分配
        return userMapper.insert(user) > 0;
    }

    @Override
    public boolean updateUser(User user) {
        return userMapper.update(user) > 0;
    }

    @Override
    public boolean deleteUser(Integer id) {
        return userMapper.deleteById(id) > 0;
    }
}
