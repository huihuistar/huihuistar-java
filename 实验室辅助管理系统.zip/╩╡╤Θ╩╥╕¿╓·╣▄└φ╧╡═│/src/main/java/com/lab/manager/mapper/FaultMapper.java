package com.lab.manager.mapper;

import com.lab.manager.entity.Fault;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface FaultMapper {
    /** 查询所有故障（管理员用，含联查字段） */
    List<Fault> findAll();

    /** 根据用户ID查询自己的上报（普通用户用） */
    List<Fault> findByUserId(@Param("userId") Integer userId);

    /** 根据ID查询 */
    Fault findById(@Param("id") Integer id);

    /** 根据状态筛选 */
    List<Fault> findByStatus(@Param("status") Integer status);

    /** 新增故障上报 */
    int insert(Fault fault);

    /** 更新故障信息 */
    int update(Fault fault);

    /** 更新故障状态 */
    int updateStatus(@Param("id") Integer id, @Param("status") Integer status);

    /** 删除故障 */
    int deleteById(@Param("id") Integer id);
}
