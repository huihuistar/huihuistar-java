package com.lab.manager.service;

import com.lab.manager.entity.User;
import java.util.List;

public interface UserService {
    /** 登录验证，成功返回用户对象，失败返回null */
    User login(String username, String password);
    List<User> getAllWorkers();
    List<User> getAllUsers();
    List<User> getAll();
    User getById(Integer id);
    boolean addUser(User user);
    boolean updateUser(User user);
    boolean deleteUser(Integer id);
}
