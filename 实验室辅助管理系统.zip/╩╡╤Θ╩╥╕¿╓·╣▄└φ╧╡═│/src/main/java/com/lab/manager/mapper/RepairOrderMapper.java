package com.lab.manager.mapper;

import com.lab.manager.entity.RepairOrder;
import org.apache.ibatis.annotations.Param;
import java.util.List;

public interface RepairOrderMapper {
    /** 查询所有工单（管理员用，含联查） */
    List<RepairOrder> findAll();

    /** 根据维修人员ID查询（维修人员自己的工单） */
    List<RepairOrder> findByRepairUserId(@Param("repairUserId") Integer repairUserId);

    /** 根据故障ID查询（普通用户查进度） */
    RepairOrder findByFaultId(@Param("faultId") Integer faultId);

    /** 根据ID查询 */
    RepairOrder findById(@Param("id") Integer id);

    /** 新增工单（派单） */
    int insert(RepairOrder order);

    /** 维修人员更新工单状态与备注 */
    int updateStatus(RepairOrder order);

    /** 删除工单 */
    int deleteById(@Param("id") Integer id);
}
