package com.lab.manager.interceptor;

import com.lab.manager.common.RoleConst;
import com.lab.manager.entity.User;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * 角色权限拦截器：只允许管理员访问 /admin/** 路径
 */
public class AdminInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                              HttpServletResponse response,
                              Object handler) throws Exception {
        User loginUser = (User) request.getSession().getAttribute(RoleConst.SESSION_USER);
        if (loginUser == null || loginUser.getRole() != RoleConst.ROLE_ADMIN) {
            response.sendRedirect(request.getContextPath() + "/login?msg=no_permission");
            return false;
        }
        return true;
    }
}
