package com.lab.manager.entity;

import lombok.Data;
import java.util.Date;

/**
 * 维修工单表实体
 * repairStatus: 0=待维修,1=维修中,2=已修复,3=无法修复
 */
@Data
public class RepairOrder {
    private Integer id;
    private Integer faultId;
    /** 维修人员ID（1001~1020） */
    private Integer repairUserId;
    /** 派单管理员ID（1021~1025） */
    private Integer adminId;
    private Date assignTime;
    /** 维修状态 */
    private Integer repairStatus;
    private String repairResult;
    private Date finishTime;

    // ===== 联查非数据库字段 =====
    private String workerName;
    private String adminName;
    private String repairStatusName;
    // 故障相关
    private String siteNum;
    private String deviceName;
    private String faultDesc;
    private String siteTypeName;
}
