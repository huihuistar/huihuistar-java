-- =============================================================
-- 教室智能感应节能管理系统 · 数据库初始化脚本（完整版）
-- 数据库名：classroom_detection
-- 字符集：utf8mb4
-- =============================================================

DROP DATABASE IF EXISTS classroom_detection;
CREATE DATABASE classroom_detection
    DEFAULT CHARACTER SET utf8mb4
    DEFAULT COLLATE utf8mb4_unicode_ci;

USE classroom_detection;

-- -------------------------------------------------------------
-- 1. 用户表
-- -------------------------------------------------------------
CREATE TABLE tb_user (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    username    VARCHAR(64)  NOT NULL COMMENT '用户名',
    password    VARCHAR(128) NOT NULL COMMENT '密码',
    role        VARCHAR(32)  NOT NULL DEFAULT 'USER' COMMENT 'ADMIN / USER',
    create_time BIGINT       NOT NULL COMMENT '创建时间戳（秒）',
    PRIMARY KEY (id),
    UNIQUE KEY uk_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

INSERT INTO tb_user (username, password, role, create_time)
VALUES ('admin', 'admin123', 'ADMIN', UNIX_TIMESTAMP());


-- -------------------------------------------------------------
-- 2. 红外原始数据表
-- -------------------------------------------------------------
CREATE TABLE tb_sensor_record (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id     VARCHAR(32)  NOT NULL COMMENT '教室 ID',
    device_id   VARCHAR(64)  NOT NULL COMMENT '设备 ID',
    status      TINYINT      NOT NULL COMMENT '0=无人 1=有人',
    create_time BIGINT       NOT NULL COMMENT '上报时间戳（秒）',
    PRIMARY KEY (id),
    INDEX idx_room_time (room_id, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='红外原始数据表';


-- -------------------------------------------------------------
-- 3. 前缀和统计表（O(1) 查询时间段是否有人）
-- -------------------------------------------------------------
CREATE TABLE tb_prefix_sum (
    id          BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id     VARCHAR(32)  NOT NULL COMMENT '教室 ID',
    time_slot   BIGINT       NOT NULL COMMENT '时间片（精确到分钟）',
    prefix_sum  BIGINT       NOT NULL DEFAULT 0 COMMENT '累计 status=1 数量',
    PRIMARY KEY (id),
    UNIQUE KEY uk_room_slot (room_id, time_slot),
    INDEX idx_room_time_slot (room_id, time_slot)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='前缀和统计表';


-- -------------------------------------------------------------
-- 4. 教室状态表（核心状态机）
-- 记录每间教室的灯状态 + 弹窗状态 + 下次检查时间
-- -------------------------------------------------------------
CREATE TABLE tb_room_state (
    room_id          VARCHAR(32)  NOT NULL COMMENT '教室 ID',
    light_on         TINYINT      NOT NULL DEFAULT 1 COMMENT '灯状态：0=关 1=开',
    popup_active     TINYINT      NOT NULL DEFAULT 0 COMMENT '弹窗是否正在显示：0=无 1=显示中',
    popup_started_at BIGINT       NOT NULL DEFAULT 0 COMMENT '弹窗开始时间戳（秒），用于 30s 超时',
    next_check_at    BIGINT       NOT NULL DEFAULT 0 COMMENT '下次检查时间戳（秒），0=无等待',
    postpone_minutes INT          NOT NULL DEFAULT 0 COMMENT '用户设置的等待分钟数',
    update_time      BIGINT       NOT NULL COMMENT '最后更新时间',
    PRIMARY KEY (room_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='教室状态表';

-- 初始化四间教室（默认开灯，无弹窗）
INSERT INTO tb_room_state (room_id, light_on, popup_active, popup_started_at, next_check_at, postpone_minutes, update_time)
VALUES
    ('A101', 1, 0, 0, 0, 0, UNIX_TIMESTAMP()),
    ('A102', 1, 0, 0, 0, 0, UNIX_TIMESTAMP()),
    ('B201', 1, 0, 0, 0, 0, UNIX_TIMESTAMP()),
    ('B202', 1, 0, 0, 0, 0, UNIX_TIMESTAMP());


-- -------------------------------------------------------------
-- 5. 操作记录表
-- 记录关灯 / 延时 / 手动开灯等所有操作
-- -------------------------------------------------------------
CREATE TABLE tb_light_action (
    id               BIGINT       NOT NULL AUTO_INCREMENT COMMENT '主键',
    room_id          VARCHAR(32)  NOT NULL COMMENT '教室 ID',
    action_type      VARCHAR(16)  NOT NULL COMMENT 'POSTPONE=延时等待 / AUTO_OFF=超时自动关灯 / MANUAL_OFF=手动关灯 / MANUAL_ON=手动开灯',
    interval_minutes INT          NOT NULL DEFAULT 0 COMMENT 'POSTPONE 时为用户输入的等待分钟数',
    operator         VARCHAR(64)  NOT NULL DEFAULT 'system' COMMENT '操作人',
    create_time      BIGINT       NOT NULL COMMENT '操作时间戳（秒）',
    PRIMARY KEY (id),
    INDEX idx_room_time (room_id, create_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='操作记录表';
