package com.classroom.detection.dto;

import lombok.Data;

/**
 * 用户延时请求（弹窗中用户输入"等 X 分钟"）
 */
@Data
public class PostponeRequest {
    private String roomId;
    private Integer minutes;    // 等待分钟数
}
