package com.classroom.detection.dto;

import lombok.Data;

/**
 * 手动开关灯请求
 */
@Data
public class LightToggleRequest {
    private String roomId;
}
