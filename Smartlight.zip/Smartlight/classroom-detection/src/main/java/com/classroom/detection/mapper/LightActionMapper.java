package com.classroom.detection.mapper;

import com.classroom.detection.entity.LightAction;
import org.apache.ibatis.annotations.Param;

import java.util.List;

/**
 * 关灯操作记录 Mapper
 */
public interface LightActionMapper {
    int insert(LightAction action);

    /** 查询某教室最近一次关灯操作 */
    LightAction getLatestByRoomId(@Param("roomId") String roomId);
    
    /** 查询操作记录列表 */
    List<LightAction> selectList(@Param("roomId") String roomId, 
                                  @Param("actionType") String actionType,
                                  @Param("offset") Integer offset,
                                  @Param("limit") Integer limit);
    
    /** 按时间范围查询操作记录列表 */
    List<LightAction> selectListByTimeRange(@Param("roomId") String roomId, 
                                             @Param("actionType") String actionType,
                                             @Param("startTime") Long startTime,
                                             @Param("endTime") Long endTime,
                                             @Param("offset") Integer offset,
                                             @Param("limit") Integer limit);
    
    /** 统计操作记录数量 */
    Integer countList(@Param("roomId") String roomId, 
                      @Param("actionType") String actionType);
    
    /** 按时间范围统计操作记录数量 */
    Integer countListByTimeRange(@Param("roomId") String roomId, 
                                  @Param("actionType") String actionType,
                                  @Param("startTime") Long startTime,
                                  @Param("endTime") Long endTime);
    
    /** 按类型统计 */
    Integer countByType(@Param("actionType") String actionType);
    
    /** 按教室统计 */
    Integer countByRoom(@Param("roomId") String roomId);
    
    /** 按时间和类型统计趋势数据 */
    List<java.util.Map<String, Object>> countTrendByHour(@Param("hours") Integer hours);
}
