package com.classroom.detection.mapper;

import com.classroom.detection.entity.SensorRecord;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface SensorRecordMapper {

    /**
     * 插入一条原始数据记录
     */
    int insert(SensorRecord record);

    /**
     * 按教室查询传感器记录
     */
    List<SensorRecord> selectByRoomId(@Param("roomId") String roomId,
                                       @Param("offset") Integer offset,
                                       @Param("limit") Integer limit);

    /**
     * 按时间范围查询传感器记录
     */
    List<SensorRecord> selectByTimeRange(@Param("roomId") String roomId,
                                          @Param("startTime") Long startTime,
                                          @Param("endTime") Long endTime);

    /**
     * 查询某教室最新一条传感器记录（用于判断当前是否有人）
     */
    SensorRecord getLatestByRoomId(@Param("roomId") String roomId);

    /**
     * 查询时间窗口内 status=1 的记录数（直接查原始表，作为前缀和的二重校验）
     */
    int countStatus1InWindow(@Param("roomId") String roomId,
                              @Param("startTime") long startTime,
                              @Param("endTime") long endTime);
}
