package com.classroom.detection.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 教室状态查询响应
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class RoomStateResponse {
    private String roomId;
    private boolean lightOn;
    private boolean occupied;       // 教室是否有人（来自最新传感器数据）
    private boolean popupActive;
    private Long popupStartedAt;     // 毫秒
    private Long nextCheckAt;        // 毫秒
    private Integer postponeMinutes;
    private boolean needPopup;       // check-status 接口返回是否需要弹窗
}
