package com.classroom.detection.service;

import com.classroom.detection.entity.RoomState;
import com.classroom.detection.mapper.RoomStateMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * 教室状态管理 Service
 * 管理 tb_room_state 表，跟踪灯开关 / 弹窗 / 等待计时
 */
@Service
public class RoomStateService {

    @Autowired
    private RoomStateMapper roomStateMapper;

    /**
     * 获取教室状态，不存在则创建默认状态（开灯、无弹窗）
     */
    public RoomState getOrCreate(String roomId) {
        RoomState state = roomStateMapper.getByRoomId(roomId);
        if (state == null) {
            state = new RoomState();
            state.setRoomId(roomId);
            state.setLightOn(1);
            state.setPopupActive(0);
            state.setPopupStartedAt(0L);
            state.setNextCheckAt(0L);
            state.setPostponeMinutes(0);
            state.setUpdateTime(System.currentTimeMillis() / 1000);
            roomStateMapper.insert(state);
        }
        return state;
    }

    public RoomState getByRoomId(String roomId) {
        return roomStateMapper.getByRoomId(roomId);
    }

    public void update(RoomState state) {
        roomStateMapper.update(state);
    }

    public List<RoomState> getAll() {
        return roomStateMapper.getAll();
    }
}
