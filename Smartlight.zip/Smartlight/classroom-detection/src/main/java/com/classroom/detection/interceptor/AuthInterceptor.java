package com.classroom.detection.interceptor;

import com.classroom.detection.util.JwtUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.lang.NonNull;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

/**
 * JWT 鉴权拦截器
 * 所有需要登录的接口均需携带 Authorization: Bearer <token>
 */
@Component
public class AuthInterceptor implements HandlerInterceptor {

    @Autowired
    private JwtUtil jwtUtil;

    private final ObjectMapper objectMapper = new ObjectMapper();

    @Override
    public boolean preHandle(@NonNull HttpServletRequest request,
                             @NonNull HttpServletResponse response,
                             @NonNull Object handler) throws Exception {

        // OPTIONS 预检请求直接放行（跨域）
        if ("OPTIONS".equalsIgnoreCase(request.getMethod())) {
            return true;
        }

        String authHeader = request.getHeader("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            writeUnauthorized(response, "未携带 Token，请先登录");
            return false;
        }

        String token = authHeader.substring(7);
        if (!jwtUtil.isValid(token)) {
            writeUnauthorized(response, "Token 已过期或非法，请重新登录");
            return false;
        }

        // 将用户名存入请求属性，供 Controller 使用
        request.setAttribute("username", jwtUtil.getUsername(token));
        return true;
    }

    private void writeUnauthorized(HttpServletResponse response, String msg) throws Exception {
        response.setStatus(401);
        response.setContentType("application/json;charset=UTF-8");
        Map<String, Object> body = new HashMap<>();
        body.put("code", 401);
        body.put("msg", msg);
        response.getWriter().write(objectMapper.writeValueAsString(body));
    }
}
