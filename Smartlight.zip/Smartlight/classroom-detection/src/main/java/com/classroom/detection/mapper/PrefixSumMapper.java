package com.classroom.detection.mapper;

import com.classroom.detection.entity.PrefixSum;
import org.apache.ibatis.annotations.Param;

public interface PrefixSumMapper {

    /**
     * 查询某教室某时间片的前缀和记录
     */
    PrefixSum getByTimeSlot(@Param("roomId") String roomId, @Param("timeSlot") long timeSlot);

    /**
     * 查询某教室 <= 指定时间片 中最大的前缀和值
     * 用于处理某分钟没有记录时向前取最近一条
     */
    Long getMaxPrefixSumBefore(@Param("roomId") String roomId, @Param("timeSlot") long timeSlot);

    /**
     * 插入前缀和记录
     */
    int insert(PrefixSum prefixSum);

    /**
     * 更新前缀和记录
     */
    int update(PrefixSum prefixSum);

    /**
     * 查询某教室最新的前缀和记录（用于计算新增量）
     */
    PrefixSum getLatest(@Param("roomId") String roomId);
}
