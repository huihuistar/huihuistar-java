package com.classroom.detection.controller;

import com.classroom.detection.dto.ReportRequest;
import com.classroom.detection.dto.ReportResponse;
import com.classroom.detection.dto.Result;
import com.classroom.detection.service.SensorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 硬件数据上报接口
 * 硬件同时上报：有没有人(status)、灯开没开(lightOn)、设备编号(deviceId)、教室(roomId)
 */
@RestController
@RequestMapping("/api/sensor")
public class SensorController {

    @Autowired
    private SensorService sensorService;

    /**
     * 硬件上报
     * POST /api/sensor/report
     * Body: { "deviceId": "IR-A101", "roomId": "A101", "status": 0, "lightOn": 1, "reportTime": 1716262500 }
     *   deviceId:  设备编号
     *   roomId:    教室 ID
     *   status:    0=无人 1=有人
     *   lightOn:   0=灯关 1=灯开（可选，硬件不报则取数据库现有值）
     *   reportTime: 上报时间戳秒（可选）
     */
    @PostMapping("/report")
    public Result<ReportResponse> report(@RequestBody ReportRequest request) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        if (request.getStatus() == null || (request.getStatus() != 0 && request.getStatus() != 1)) {
            return Result.fail("status 只能为 0 或 1");
        }
        if (request.getLightOn() != null && request.getLightOn() != 0 && request.getLightOn() != 1) {
            return Result.fail("lightOn 只能为 0 或 1");
        }
        ReportResponse response = sensorService.report(request);
        return Result.success(response);
    }
}
