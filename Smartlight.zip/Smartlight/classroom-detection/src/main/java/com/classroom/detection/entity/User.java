package com.classroom.detection.entity;

import lombok.Data;

/**
 * 用户表实体
 */
@Data
public class User {
    private Long id;
    private String username;
    private String password;
    private String role;       // ADMIN / USER
    private Long createTime;
}
