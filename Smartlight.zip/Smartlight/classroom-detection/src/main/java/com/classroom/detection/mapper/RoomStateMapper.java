package com.classroom.detection.mapper;

import com.classroom.detection.entity.RoomState;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface RoomStateMapper {

    RoomState getByRoomId(@Param("roomId") String roomId);

    int insert(RoomState state);

    int update(RoomState state);

    /**
     * 获取所有教室状态
     */
    List<RoomState> getAll();
}
