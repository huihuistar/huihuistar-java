package com.classroom.detection;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.classroom.detection.mapper")
public class ClassroomDetectionApplication {
    public static void main(String[] args) {
        SpringApplication.run(ClassroomDetectionApplication.class, args);
    }
}
