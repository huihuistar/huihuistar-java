package com.classroom.detection.controller;

import com.classroom.detection.dto.Result;
import com.classroom.detection.dto.SnoozeRequest;
import com.classroom.detection.service.ReminderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * 提醒冷却接口
 */
@RestController
@RequestMapping("/api/reminder")
public class ReminderController {

    @Autowired
    private ReminderService reminderService;

    /**
     * 用户设置再次提醒时间（弹窗确认后调用）
     * POST /api/reminder/snooze
     * Header: Authorization: Bearer <token>
     * Body: { "roomId": "A101", "intervalMinutes": 15 }
     * 响应: { "code": 200, "data": { "nextPopupTime": 1716262500000 } }
     */
    @PostMapping("/snooze")
    public Result<Map<String, Object>> snooze(@RequestBody SnoozeRequest request) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        long nextPopupTime = reminderService.snooze(request);
        Map<String, Object> data = new HashMap<>();
        data.put("nextPopupTime", nextPopupTime * 1000L); // 返回毫秒给前端
        data.put("intervalMinutes",
                request.getIntervalMinutes() != null ? request.getIntervalMinutes() : 10);
        return Result.success(data);
    }

    /**
     * 查询某教室下次弹窗时间（可选，供前端倒计时使用）
     * GET /api/reminder/next?roomId=A101
     */
    @GetMapping("/next")
    public Result<Map<String, Object>> getNextPopupTime(@RequestParam String roomId) {
        Long nextPopupTime = reminderService.getNextPopupTime(roomId);
        Map<String, Object> data = new HashMap<>();
        data.put("nextPopupTime", nextPopupTime); // 毫秒
        return Result.success(data);
    }
}
