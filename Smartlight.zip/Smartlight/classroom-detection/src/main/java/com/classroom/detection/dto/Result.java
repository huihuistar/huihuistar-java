package com.classroom.detection.dto;

import lombok.Data;

/**
 * 统一响应包装类
 */
@Data
public class Result<T> {
    private Integer code;
    private String msg;
    private T data;

    public static <T> Result<T> success(T data) {
        Result<T> r = new Result<>();
        r.code = 200;
        r.msg = "success";
        r.data = data;
        return r;
    }

    public static <T> Result<T> success() {
        return success(null);
    }

    public static <T> Result<T> fail(String msg) {
        Result<T> r = new Result<>();
        r.code = 500;
        r.msg = msg;
        return r;
    }

    public static <T> Result<T> unauthorized(String msg) {
        Result<T> r = new Result<>();
        r.code = 401;
        r.msg = msg;
        return r;
    }
}
