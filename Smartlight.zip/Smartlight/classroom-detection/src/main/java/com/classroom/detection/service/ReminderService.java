package com.classroom.detection.service;

import com.classroom.detection.dto.SnoozeRequest;
import com.classroom.detection.entity.Reminder;
import com.classroom.detection.mapper.ReminderMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 提醒冷却 Service
 * 记录用户设置的再次提醒间隔，更新下次弹窗时间
 */
@Service
public class ReminderService {

    @Autowired
    private ReminderMapper reminderMapper;

    /** 默认再次提醒间隔（分钟）*/
    private static final int DEFAULT_INTERVAL = 10;

    /**
     * 用户设置再次提醒时间
     *
     * @param request roomId + intervalMinutes
     * @return 下次允许弹窗的时间戳（秒）
     */
    public long snooze(SnoozeRequest request) {
        int interval = (request.getIntervalMinutes() != null && request.getIntervalMinutes() > 0)
                ? request.getIntervalMinutes()
                : DEFAULT_INTERVAL;

        long nowSec = System.currentTimeMillis() / 1000;
        long nextPopupTime = nowSec + (long) interval * 60;

        Reminder reminder = reminderMapper.getByRoomId(request.getRoomId());

        if (reminder == null) {
            // 首次插入
            reminder = new Reminder();
            reminder.setRoomId(request.getRoomId());
            reminder.setNextPopupTime(nextPopupTime);
            reminder.setIntervalMinutes(interval);
            reminder.setUpdateTime(nowSec);
            reminderMapper.insert(reminder);
        } else {
            // 更新已有记录
            reminder.setNextPopupTime(nextPopupTime);
            reminder.setIntervalMinutes(interval);
            reminder.setUpdateTime(nowSec);
            reminderMapper.update(reminder);
        }

        return nextPopupTime;
    }

    /**
     * 查询某教室的下次提醒时间（毫秒，供前端倒计时使用）
     */
    public Long getNextPopupTime(String roomId) {
        Reminder reminder = reminderMapper.getByRoomId(roomId);
        return (reminder != null) ? reminder.getNextPopupTime() * 1000 : null;
    }
}
