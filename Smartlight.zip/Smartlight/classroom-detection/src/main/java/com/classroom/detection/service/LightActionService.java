package com.classroom.detection.service;

import com.classroom.detection.entity.LightAction;
import com.classroom.detection.entity.RoomState;
import com.classroom.detection.entity.SensorRecord;
import com.classroom.detection.mapper.LightActionMapper;
import com.classroom.detection.mapper.SensorRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 关灯 / 延时 / 开关灯 操作 Service
 * 负责：记录操作日志 + 更新 tb_room_state 状态机
 *
 * 冷却期机制：手动操作后设置 nextCheckAt = now + COOLDOWN_SECONDS
 * 冷却期内 SensorService 不触发弹窗，防止手动操作后立即再次弹窗
 */
@Service
public class LightActionService {

    // 手动操作后的冷却期（秒）：冷却期内不触发弹窗
    // keepLightOn = 60s，postpone 用用户设定时间，toggle/autoOff 关灯后不需要冷却
    private static final int KEEP_LIGHT_COOLDOWN_SECONDS = 60;

    @Autowired
    private LightActionMapper lightActionMapper;

    @Autowired
    private RoomStateService roomStateService;

    @Autowired
    private SensorRecordMapper sensorRecordMapper;

    /**
     * 用户延时（弹窗中输入"等 X 分钟"）
     * 1. 记录 POSTPONE 日志
     * 2. 设置 nextCheckAt = now + X*60，清除 popup
     */
    @Transactional
    public RoomState postpone(String roomId, int minutes, String username) {
        long nowSec = System.currentTimeMillis() / 1000;
        long nextCheckAtSec = nowSec + (long) minutes * 60;

        // 1. 记录操作日志
        LightAction action = new LightAction();
        action.setRoomId(roomId);
        action.setActionType("POSTPONE");
        action.setIntervalMinutes(minutes);
        action.setOperator(username != null ? username : "unknown");
        action.setCreateTime(nowSec);
        lightActionMapper.insert(action);

        // 2. 更新教室状态：进入等待期
        RoomState state = roomStateService.getOrCreate(roomId);
        state.setPopupActive(0);
        state.setPopupStartedAt(0L);
        state.setNextCheckAt(nextCheckAtSec);
        state.setPostponeMinutes(minutes);
        state.setUpdateTime(nowSec);
        roomStateService.update(state);

        return state;
    }

    /**
     * 手动开关灯
     * - 关灯 → 清除弹窗/等待，设置 light_off，记录 MANUAL_OFF
     * - 开灯 → 重置所有状态，记录 MANUAL_ON，恢复监测
     */
    @Transactional
    public RoomState toggle(String roomId, String username) {
        long nowSec = System.currentTimeMillis() / 1000;
        RoomState state = roomStateService.getOrCreate(roomId);
        boolean wasOn = state.getLightOn() == 1;

        if (wasOn) {
            // 关灯
            state.setLightOn(0);
            state.setPopupActive(0);
            state.setPopupStartedAt(0L);
            state.setNextCheckAt(0L);
            state.setPostponeMinutes(0);

            // 写入无人传感器记录，让 occupied 同步更新
            SensorRecord sr = new SensorRecord();
            sr.setRoomId(roomId);
            sr.setDeviceId("manual");
            sr.setStatus(0);  // 0=无人
            sr.setCreateTime(nowSec);
            sensorRecordMapper.insert(sr);

            LightAction action = new LightAction();
            action.setRoomId(roomId);
            action.setActionType("MANUAL_OFF");
            action.setIntervalMinutes(0);
            action.setOperator(username != null ? username : "unknown");
            action.setCreateTime(nowSec);
            lightActionMapper.insert(action);
        } else {
            // 开灯 → 重置全部，设置冷却期（60秒内不触发弹窗）
            state.setLightOn(1);
            state.setPopupActive(0);
            state.setPopupStartedAt(0L);
            state.setNextCheckAt(nowSec + KEEP_LIGHT_COOLDOWN_SECONDS);
            state.setPostponeMinutes(0);

            // 手动开灯 = 有人进来，写入有人记录
            SensorRecord sr = new SensorRecord();
            sr.setRoomId(roomId);
            sr.setDeviceId("manual");
            sr.setStatus(1);  // 1=有人
            sr.setCreateTime(nowSec);
            sensorRecordMapper.insert(sr);

            LightAction action = new LightAction();
            action.setRoomId(roomId);
            action.setActionType("MANUAL_ON");
            action.setIntervalMinutes(0);
            action.setOperator(username != null ? username : "unknown");
            action.setCreateTime(nowSec);
            lightActionMapper.insert(action);
        }

        state.setUpdateTime(nowSec);
        roomStateService.update(state);
        return state;
    }

    /**
     * 超时自动关灯（弹窗 30s 无人应答）
     */
    @Transactional
    public RoomState autoOff(String roomId) {
        long nowSec = System.currentTimeMillis() / 1000;
        RoomState state = roomStateService.getOrCreate(roomId);

        // 记录操作
        LightAction action = new LightAction();
        action.setRoomId(roomId);
        action.setActionType("AUTO_OFF");
        action.setIntervalMinutes(0);
        action.setOperator("system");
        action.setCreateTime(nowSec);
        lightActionMapper.insert(action);

        // 关灯 + 清除弹窗
        state.setLightOn(0);
        state.setPopupActive(0);
        state.setPopupStartedAt(0L);
        state.setNextCheckAt(0L);
        state.setPostponeMinutes(0);

        // 写入无人传感器记录
        SensorRecord sr = new SensorRecord();
        sr.setRoomId(roomId);
        sr.setDeviceId("system");
        sr.setStatus(0);  // 0=无人
        sr.setCreateTime(nowSec);
        sensorRecordMapper.insert(sr);

        state.setUpdateTime(nowSec);
        roomStateService.update(state);

        return state;
    }

    /**
     * 保持照明：用户选择"不关灯"
     * 设置 60 秒冷却期（nextCheckAt），冷却期内不触发弹窗
     */
    @Transactional
    public RoomState keepLightOn(String roomId, String username) {
        long nowSec = System.currentTimeMillis() / 1000;
        RoomState state = roomStateService.getOrCreate(roomId);

        // 记录操作日志
        LightAction action = new LightAction();
        action.setRoomId(roomId);
        action.setActionType("KEEP_LIGHT_ON");
        action.setIntervalMinutes(0);
        action.setOperator(username != null ? username : "unknown");
        action.setCreateTime(nowSec);
        lightActionMapper.insert(action);

        // 写入"有人"传感器记录
        SensorRecord sr = new SensorRecord();
        sr.setRoomId(roomId);
        sr.setDeviceId("manual");
        sr.setStatus(1);
        sr.setCreateTime(nowSec);
        sensorRecordMapper.insert(sr);

        // 保持灯开启，清除弹窗，设置冷却期（60秒内不再触发弹窗）
        state.setLightOn(1);
        state.setPopupActive(0);
        state.setPopupStartedAt(0L);
        state.setNextCheckAt(nowSec + KEEP_LIGHT_COOLDOWN_SECONDS);
        state.setPostponeMinutes(0);
        state.setUpdateTime(nowSec);
        roomStateService.update(state);

        return state;
    }
}
