package com.classroom.detection.entity;

import lombok.Data;

/**
 * 教室状态表
 * 核心状态机：跟踪每间教室的灯开关 + 弹窗状态 + 下次检查时间
 */
@Data
public class RoomState {
    private String roomId;           // 教室 ID
    private Integer lightOn;         // 灯状态：0=关 1=开
    private Integer popupActive;     // 弹窗是否显示：0=无 1=显示中
    private Long popupStartedAt;     // 弹窗开始时间（秒），用于 30s 超时判断
    private Long nextCheckAt;        // 下次检查时间（秒），0=无等待
    private Integer postponeMinutes; // 用户设置的等待分钟数
    private Long updateTime;         // 最后更新时间
}
