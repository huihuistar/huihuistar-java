package com.classroom.detection.service;

import com.classroom.detection.dto.LoginRequest;
import com.classroom.detection.dto.LoginResponse;
import com.classroom.detection.entity.User;
import com.classroom.detection.mapper.UserMapper;
import com.classroom.detection.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 * 登录鉴权 Service
 */
@Service
public class AuthService {

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private JwtUtil jwtUtil;

    /**
     * 登录验证，成功返回 Token 信息
     */
    public LoginResponse login(LoginRequest request) {
        // 1. 查询用户
        User user = userMapper.findByUsername(request.getUsername());
        if (user == null) {
            throw new RuntimeException("用户名不存在");
        }

        // 2. 校验密码（此处为明文对比，生产环境应使用 BCrypt）
        if (!user.getPassword().equals(request.getPassword())) {
            throw new RuntimeException("密码错误");
        }

        // 3. 生成 Token
        String token = jwtUtil.generateToken(user.getUsername(), user.getRole());
        long expireTime = jwtUtil.getExpireTime(token);

        return new LoginResponse(token, user.getUsername(), user.getRole(), expireTime);
    }
}
