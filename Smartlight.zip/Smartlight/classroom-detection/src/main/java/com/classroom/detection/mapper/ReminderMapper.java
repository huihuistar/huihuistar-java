package com.classroom.detection.mapper;

import com.classroom.detection.entity.Reminder;
import org.apache.ibatis.annotations.Param;

public interface ReminderMapper {

    /**
     * 查询某教室的提醒冷却记录
     */
    Reminder getByRoomId(@Param("roomId") String roomId);

    /**
     * 插入提醒记录
     */
    int insert(Reminder reminder);

    /**
     * 更新提醒记录（下次弹窗时间 + 间隔）
     */
    int update(Reminder reminder);
}
