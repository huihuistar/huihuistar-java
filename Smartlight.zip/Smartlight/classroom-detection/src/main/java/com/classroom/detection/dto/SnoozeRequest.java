package com.classroom.detection.dto;

import lombok.Data;

/**
 * 用户设置再次提醒时间请求体
 */
@Data
public class SnoozeRequest {
    private String roomId;           // 教室 ID
    private Integer intervalMinutes; // 多少分钟后再次提醒，默认 10
}
