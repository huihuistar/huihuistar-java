package com.classroom.detection.controller;

import com.classroom.detection.dto.LoginRequest;
import com.classroom.detection.dto.LoginResponse;
import com.classroom.detection.dto.Result;
import com.classroom.detection.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * 登录鉴权接口
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    /**
     * 用户登录
     * POST /api/auth/login
     * Body: { "username": "admin", "password": "123456" }
     */
    @PostMapping("/login")
    public Result<LoginResponse> login(@RequestBody LoginRequest request) {
        try {
            LoginResponse response = authService.login(request);
            return Result.success(response);
        } catch (RuntimeException e) {
            return Result.fail(e.getMessage());
        }
    }

    /**
     * 登出（前端清除 Token 即可，后端无状态）
     * POST /api/auth/logout
     */
    @PostMapping("/logout")
    public Result<String> logout() {
        return Result.success("已登出");
    }
}
