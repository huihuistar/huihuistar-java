package com.classroom.detection.dto;

import lombok.Data;

/**
 * 关灯操作请求（保留兼容旧接口，新接口用 PostponeRequest / LightToggleRequest）
 */
@Data
public class LightActionRequest {
    private String roomId;
    private String actionType;       // POSTPONE / AUTO_OFF / MANUAL_OFF / MANUAL_ON
    private Integer intervalMinutes;  // POSTPONE 时填写
}
