package com.classroom.detection.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 上报接口响应体（新增灯状态、弹窗状态、下次检查时间等）
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class ReportResponse {
    /** 是否需要弹出关灯询问窗口 */
    private boolean needPopup;
    /** 灯是否开着 */
    private boolean lightOn;
    /** 教室是否有人（来自最新传感器数据） */
    private boolean occupied;
    /** 弹窗是否正在显示 */
    private boolean popupActive;
    /** 弹窗开始时间（毫秒，前端用于 30s 倒计时） */
    private Long popupStartedAt;
    /** 下次检查时间（毫秒，0=无等待） */
    private Long nextCheckAt;
    /** 用户设置的等待分钟数 */
    private Integer postponeMinutes;
    /** 提示消息 */
    private String message;

    /** 快捷构造：无需弹窗 */
    public static ReportResponse no(String msg, boolean lightOn, boolean occupied) {
        return new ReportResponse(false, lightOn, occupied, false, null, null, null, msg);
    }

    /** 快捷构造：需要弹窗 */
    public static ReportResponse popup(String msg, boolean lightOn, boolean occupied, long popupStartedAtSec) {
        return new ReportResponse(true, lightOn, occupied, true,
                popupStartedAtSec * 1000, null, null, msg);
    }

    /** 快捷构造：等待中 */
    public static ReportResponse waiting(String msg, boolean lightOn, boolean occupied, long nextCheckAtSec, int minutes) {
        return new ReportResponse(false, lightOn, occupied, false, null,
                nextCheckAtSec * 1000, minutes, msg);
    }
}
