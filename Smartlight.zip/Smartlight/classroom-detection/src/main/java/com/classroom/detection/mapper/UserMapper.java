package com.classroom.detection.mapper;

import com.classroom.detection.entity.User;
import org.apache.ibatis.annotations.Param;

public interface UserMapper {
    User findByUsername(@Param("username") String username);
}
