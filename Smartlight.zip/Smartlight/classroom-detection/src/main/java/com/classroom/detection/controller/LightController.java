package com.classroom.detection.controller;

import com.classroom.detection.dto.*;
import com.classroom.detection.entity.RoomState;
import com.classroom.detection.entity.SensorRecord;
import com.classroom.detection.mapper.SensorRecordMapper;
import com.classroom.detection.service.LightActionService;
import com.classroom.detection.service.RoomStateService;
import com.classroom.detection.service.SensorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * 关灯/延时/开关灯 接口
 *
 * 状态机说明：
 * 1. 无人 → 前端弹窗（30s 倒计时）
 * 2. 用户输入"等 X 分钟" → POST /api/light/postpone → 进入等待
 * 3. 等待到期 → 前端调 POST /api/light/check-status → 还无人 → 再弹窗（循环）
 * 4. 30s 无人应答 → POST /api/light/auto-off → 自动关灯
 * 5. 手动开关灯 → POST /api/light/toggle → 开灯重置循环
 */
@RestController
@RequestMapping("/api/light")
public class LightController {

    @Autowired
    private LightActionService lightActionService;

    @Autowired
    private SensorService sensorService;

    @Autowired
    private RoomStateService roomStateService;

    @Autowired
    private SensorRecordMapper sensorRecordMapper;

    /**
     * 用户延时：弹窗中输入"等 X 分钟"
     * POST /api/light/postpone
     * Body: { "roomId": "A101", "minutes": 20 }
     */
    @PostMapping("/postpone")
    public Result<Map<String, Object>> postpone(@RequestBody PostponeRequest request,
                                                 HttpServletRequest httpReq) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        int minutes = (request.getMinutes() != null && request.getMinutes() > 0)
                ? request.getMinutes() : 10;

        String username = (String) httpReq.getAttribute("username");
        RoomState state = lightActionService.postpone(request.getRoomId(), minutes, username);

        Map<String, Object> data = new HashMap<>();
        data.put("roomId", state.getRoomId());
        data.put("lightOn", state.getLightOn() == 1);
        data.put("postponeMinutes", state.getPostponeMinutes());
        data.put("nextCheckAt", state.getNextCheckAt() * 1000L); // 毫秒
        return Result.success(data);
    }

    /**
     * 等待到期 → 重新检测是否还需要弹窗
     * POST /api/light/check-status
     * Body: { "roomId": "A101" }
     * 返回: { needPopup, lightOn, ... }
     */
    @PostMapping("/check-status")
    public Result<ReportResponse> checkStatus(@RequestBody LightToggleRequest request) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        ReportResponse response = sensorService.checkStatus(request.getRoomId());
        return Result.success(response);
    }

    /**
     * 超时自动关灯（弹窗 30s 无人应答 → 前端调用）
     * POST /api/light/auto-off
     * Body: { "roomId": "A101" }
     */
    @PostMapping("/auto-off")
    public Result<Map<String, Object>> autoOff(@RequestBody LightToggleRequest request) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        RoomState state = lightActionService.autoOff(request.getRoomId());
        Map<String, Object> data = new HashMap<>();
        data.put("roomId", state.getRoomId());
        data.put("lightOn", false);
        data.put("occupied", false);
        data.put("message", "已自动关灯");
        return Result.success(data);
    }

    /**
     * 手动开关灯
     * POST /api/light/toggle
     * Body: { "roomId": "A101" }
     */
    @PostMapping("/toggle")
    public Result<Map<String, Object>> toggle(@RequestBody LightToggleRequest request,
                                               HttpServletRequest httpReq) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        String username = (String) httpReq.getAttribute("username");
        RoomState state = lightActionService.toggle(request.getRoomId(), username);
        Map<String, Object> data = new HashMap<>();
        boolean lightOn = state.getLightOn() == 1;
        data.put("roomId", state.getRoomId());
        data.put("lightOn", lightOn);
        // 灯关着 = 不可能有人
        if (!lightOn) {
            data.put("occupied", false);
        } else {
            SensorRecord latest = sensorRecordMapper.getLatestByRoomId(request.getRoomId());
            data.put("occupied", latest != null && latest.getStatus() == 1);
        }
        data.put("message", lightOn ? "已开灯，恢复监测" : "已关灯");
        return Result.success(data);
    }

    /**
     * 查询教室当前状态
     * GET /api/light/status?roomId=A101
     */
    @GetMapping("/status")
    public Result<RoomStateResponse> status(@RequestParam String roomId) {
        RoomState state = roomStateService.getByRoomId(roomId);
        if (state == null) {
            return Result.fail("教室不存在");
        }
        RoomStateResponse resp = new RoomStateResponse();
        resp.setRoomId(state.getRoomId());
        boolean lightOn = state.getLightOn() == 1;
        resp.setLightOn(lightOn);
        // 灯关着 = 不可能有人；灯开着才查传感器
        if (!lightOn) {
            resp.setOccupied(false);
        } else {
            SensorRecord latest = sensorRecordMapper.getLatestByRoomId(roomId);
            resp.setOccupied(latest != null && latest.getStatus() == 1);
        }
        resp.setPopupActive(state.getPopupActive() == 1);
        resp.setPopupStartedAt(state.getPopupStartedAt() * 1000L);
        resp.setNextCheckAt(state.getNextCheckAt() * 1000L);
        resp.setPostponeMinutes(state.getPostponeMinutes());
        resp.setNeedPopup(false);
        return Result.success(resp);
    }

    /**
     * 查询所有教室当前状态
     * GET /api/light/status-all
     */
    @GetMapping("/status-all")
    public Result<List<RoomStateResponse>> statusAll() {
        List<RoomState> states = roomStateService.getAll();
        List<RoomStateResponse> responses = states.stream().map(state -> {
            RoomStateResponse resp = new RoomStateResponse();
            resp.setRoomId(state.getRoomId());
            boolean lightOn = state.getLightOn() == 1;
            resp.setLightOn(lightOn);
            // 灯关着 = 不可能有人；灯开着才查传感器
            if (!lightOn) {
                resp.setOccupied(false);
            } else {
                SensorRecord latest = sensorRecordMapper.getLatestByRoomId(state.getRoomId());
                resp.setOccupied(latest != null && latest.getStatus() == 1);
            }
            resp.setPopupActive(state.getPopupActive() == 1);
            resp.setPopupStartedAt(state.getPopupStartedAt() * 1000L);
            resp.setNextCheckAt(state.getNextCheckAt() * 1000L);
            resp.setPostponeMinutes(state.getPostponeMinutes());
            resp.setNeedPopup(false);
            return resp;
        }).collect(Collectors.toList());
        return Result.success(responses);
    }

    /**
     * 新增教室（查无则建）
     * POST /api/light/room/create
     * Body: { "roomId": "C301" }
     */
    @PostMapping("/room/create")
    public Result<Map<String, Object>> createRoom(@RequestBody LightToggleRequest request) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        // 已存在则直接返回，不存在则自动 INSERT
        RoomState state = roomStateService.getOrCreate(request.getRoomId());
        Map<String, Object> data = new HashMap<>();
        data.put("roomId", state.getRoomId());
        data.put("lightOn", state.getLightOn() == 1);
        data.put("message", "教室已创建");
        return Result.success(data);
    }

    /**
     * 保持照明：用户选择"不关灯"，维持当前照度水平
     * POST /api/light/keep-light-on
     * Body: { "roomId": "A101" }
     */
    @PostMapping("/keep-light-on")
    public Result<Map<String, Object>> keepLightOn(@RequestBody LightToggleRequest request,
                                                   HttpServletRequest httpReq) {
        if (request.getRoomId() == null || request.getRoomId().isEmpty()) {
            return Result.fail("roomId 不能为空");
        }
        String username = (String) httpReq.getAttribute("username");
        RoomState state = lightActionService.keepLightOn(request.getRoomId(), username);
        Map<String, Object> data = new HashMap<>();
        data.put("roomId", state.getRoomId());
        data.put("lightOn", state.getLightOn() == 1);
        data.put("message", "已保持照明状态");
        return Result.success(data);
    }
}
