package com.classroom.detection.service;

import com.classroom.detection.dto.ReportRequest;
import com.classroom.detection.dto.ReportResponse;
import com.classroom.detection.entity.RoomState;
import com.classroom.detection.entity.SensorRecord;
import com.classroom.detection.mapper.SensorRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * 核心 Service — 状态机：
 * 只要灯开着就检测是否需要节能（不再限制白天/晚上）。
 * 1. 接收传感器上报，写入原始表
 * 2. 查过去 N 分钟是否全程无人（直接查原始表，可靠）
 * 3. 无人 → 激活弹窗（前端 30s 无人应答 → 自动关灯）
 * 4. 用户说"等 X 分钟" → 设置 nextCheckAt
 * 5. 时间到了 → 前端调 check-status → 还无人 → 再弹窗（循环）
 * 6. 有人手动开关灯 → 重置整个循环
 */
@Service
public class SensorService {

    @Autowired
    private SensorRecordMapper sensorRecordMapper;

    @Autowired
    private RoomStateService roomStateService;

    @Value("${detection.empty-seconds:1200}")
    private int emptySeconds;

    /**
     * 处理前端上报（核心入口）
     *
     * @return ReportResponse：包含 needPopup / lightOn / popupActive / 倒计时等
     */
    @Transactional
    public ReportResponse report(ReportRequest request) {
        long nowSec = System.currentTimeMillis() / 1000;

        // ===== 1. 存入原始数据 =====
        long reportTimeSec = (request.getReportTime() != null && request.getReportTime() > 0)
                ? request.getReportTime() : nowSec;
        SensorRecord record = new SensorRecord();
        record.setRoomId(request.getRoomId());
        record.setDeviceId(request.getDeviceId());
        record.setStatus(request.getStatus());
        record.setCreateTime(reportTimeSec);
        sensorRecordMapper.insert(record);

        // ===== 2. 获取教室状态 =====
        RoomState state = roomStateService.getOrCreate(request.getRoomId());

        // ===== 3. 硬件上报灯光状态 → 仅当后端灯是开着时才同步（防止覆盖前端关灯操作）=====
        // 如果后端已经是关灯状态，不允许硬件上报把它改回开灯
        if (request.getLightOn() != null) {
            // 只有硬件上报"开灯"且后端也是开灯时才同步，避免硬件旧状态覆盖前端操作
            if (request.getLightOn() == 1 && state.getLightOn() == 1) {
                // 状态一致，无需更新
            } else if (request.getLightOn() == 0 && state.getLightOn() == 1) {
                // 硬件说关灯，后端说开灯 → 以后端为准，不覆盖（硬件会在下次上报响应中同步）
            } else if (request.getLightOn() == 1 && state.getLightOn() == 0) {
                // 硬件说开灯，后端说关灯 → 以后端为准，不覆盖
            }
            // 不再用硬件上报的 lightOn 覆盖后端状态，后端状态以 toggle/autoOff 为准
        }

        // ===== 4. 灯已关 → 直接返回，不做检测 =====
        boolean lightOn = state.getLightOn() == 1;
        if (!lightOn) {
            boolean occupied = request.getStatus() == 1;
            return ReportResponse.no("灯已关闭", false, occupied);
        }

        // ===== 5. 弹窗正在显示中 → 不重复触发 =====
        if (state.getPopupActive() == 1) {
            return ReportResponse.no("弹窗显示中", true, request.getStatus() == 1);
        }

        // ===== 6. 等待期/冷却期内 → 跳过检测，不触发弹窗 =====
        if (state.getNextCheckAt() > 0 && nowSec < state.getNextCheckAt()) {
            return ReportResponse.waiting(
                    "等待中",
                    true,
                    request.getStatus() == 1,
                    state.getNextCheckAt(),
                    state.getPostponeMinutes()
            );
        }

        // ===== 7. 检查过去 N 秒是否全程无人 =====
        boolean isEmpty = isEmptyForSeconds(request.getRoomId(), nowSec, emptySeconds);
        System.out.println("[report] roomId=" + request.getRoomId() + " nowSec=" + nowSec + " isEmpty=" + isEmpty + " status=" + request.getStatus());

        if (!isEmpty) {
            // 有人 → 重置所有弹窗/等待状态
            if (state.getPopupActive() == 1 || state.getNextCheckAt() > 0) {
                state.setPopupActive(0);
                state.setPopupStartedAt(0L);
                state.setNextCheckAt(0L);
                state.setPostponeMinutes(0);
                state.setUpdateTime(nowSec);
                roomStateService.update(state);
            }
            return ReportResponse.no("检测到有人", true, request.getStatus() == 1);
        }

        // ===== 9. 全程无人 → 激活弹窗 =====
        state.setPopupActive(1);
        state.setPopupStartedAt(nowSec);
        state.setUpdateTime(nowSec);
        roomStateService.update(state);

        return ReportResponse.popup(
                "教室 " + request.getRoomId() + " 已 " + emptySeconds + " 秒无人",
                true,
                request.getStatus() == 1,
                nowSec
        );
    }

    /**
     * 检测状态：用户等待时间到了，重新检查是否还无人
     * 无人 → 继续弹窗；有人 → 重置
     */
    @Transactional
    public ReportResponse checkStatus(String roomId) {
        long nowSec = System.currentTimeMillis() / 1000;
        RoomState state = roomStateService.getOrCreate(roomId);

        if (state.getLightOn() == 0) {
            return ReportResponse.no("灯已关闭", false, false);
        }

        boolean isEmpty = isEmptyForSeconds(roomId, nowSec, emptySeconds);

        if (!isEmpty) {
            // 有人 → 重置，继续正常监测
            state.setPopupActive(0);
            state.setPopupStartedAt(0L);
            state.setNextCheckAt(0L);
            state.setPostponeMinutes(0);
            state.setUpdateTime(nowSec);
            roomStateService.update(state);
            return ReportResponse.no("等待期间有人进入，取消弹窗", true, true);
        }

        // 仍然无人 → 再次激活弹窗
        state.setPopupActive(1);
        state.setPopupStartedAt(nowSec);
        state.setNextCheckAt(0L);
        state.setPostponeMinutes(0);
        state.setUpdateTime(nowSec);
        roomStateService.update(state);

        return ReportResponse.popup("教室 " + roomId + " 仍然无人，请确认", true, false, nowSec);
    }

    // ----------------------------------------------------------------
    // 无人检测：直接查原始表（可靠）
    // ----------------------------------------------------------------

    public boolean isEmptyForSeconds(String roomId, long nowSec, int seconds) {
        long windowStart = nowSec - seconds;
        int count = sensorRecordMapper.countStatus1InWindow(roomId, windowStart, nowSec);
        System.out.println("[isEmptyForSeconds] roomId=" + roomId
                + " window=[" + windowStart + "," + nowSec + "] status1Count=" + count);
        return count == 0;
    }
}
