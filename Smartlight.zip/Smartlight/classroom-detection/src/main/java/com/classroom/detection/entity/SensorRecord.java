package com.classroom.detection.entity;

import lombok.Data;

/**
 * 红外原始数据记录表
 */
@Data
public class SensorRecord {
    private Long id;
    private String roomId;     // 教室 ID
    private String deviceId;   // 设备 ID
    private Integer status;    // 0=无人 1=有人
    private Long createTime;   // 上报时间戳（秒）
}
