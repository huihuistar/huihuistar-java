package com.classroom.detection.dto;

import lombok.Data;

/**
 * 硬件上报请求体
 * 硬件同时上报：有没有人、灯开没开、设备编号、教室
 */
@Data
public class ReportRequest {
    private String deviceId;    // 设备编号（如 IR-A101）
    private String roomId;      // 教室 ID（如 A101）
    private Integer status;     // 0=无人 1=有人
    private Integer lightOn;    // 0=灯关 1=灯开（硬件直接上报灯光状态）
    private Long reportTime;    // 上报时间戳（秒），为空则取服务器时间
}
