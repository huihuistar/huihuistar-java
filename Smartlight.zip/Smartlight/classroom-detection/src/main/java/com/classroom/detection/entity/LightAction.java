package com.classroom.detection.entity;

import lombok.Data;

/**
 * 关灯操作记录
 * actionType: POSTPONE=延时 / AUTO_OFF=超时自动关灯 / MANUAL_OFF=手动关灯 / MANUAL_ON=手动开灯
 */
@Data
public class LightAction {
    private Long id;
    private String roomId;
    private String actionType;       // POSTPONE / AUTO_OFF / MANUAL_OFF / MANUAL_ON
    private Integer intervalMinutes;  // POSTPONE 时为用户输入的分钟数
    private String operator;          // 操作人
    private Long createTime;          // 操作时间戳（秒）
}
