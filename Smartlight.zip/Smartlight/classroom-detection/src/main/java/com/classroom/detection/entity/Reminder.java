package com.classroom.detection.entity;

import lombok.Data;

/**
 * 提醒冷却记录表
 * 记录每个教室的下次弹窗时间，实现冷却期控制
 */
@Data
public class Reminder {
    private Long id;
    private String roomId;           // 教室 ID
    private Long nextPopupTime;      // 下次允许弹窗的时间戳（秒）
    private Integer intervalMinutes; // 用户设置的间隔分钟数（默认 10）
    private Long updateTime;         // 最后更新时间
}
