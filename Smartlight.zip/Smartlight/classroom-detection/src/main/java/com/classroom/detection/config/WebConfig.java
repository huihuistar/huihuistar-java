package com.classroom.detection.config;

import com.classroom.detection.interceptor.AuthInterceptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.lang.NonNull;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * Web 配置：拦截器注册 + 跨域
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    @Autowired
    @NonNull
    private AuthInterceptor authInterceptor;

    @Override
    public void addInterceptors(@NonNull InterceptorRegistry registry) {
        registry.addInterceptor(authInterceptor)
                // 拦截所有 /api/** 接口
                .addPathPatterns("/api/**")
                // 放行登录接口、传感器上报、灯控接口（硬件设备无需登录）
                .excludePathPatterns("/api/auth/login", "/api/sensor/**", "/api/light/**");
    }

    @Override
    public void addCorsMappings(@NonNull CorsRegistry registry) {
        // 开发阶段允许所有来源，生产环境请修改为具体域名
        registry.addMapping("/**")
                .allowedOriginPatterns("*")
                .allowedMethods("GET", "POST", "PUT", "DELETE", "OPTIONS")
                .allowedHeaders("*")
                .allowCredentials(true)
                .maxAge(3600);
    }
}
