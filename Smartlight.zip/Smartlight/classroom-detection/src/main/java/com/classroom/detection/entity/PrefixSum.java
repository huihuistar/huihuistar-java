package com.classroom.detection.entity;

import lombok.Data;

/**
 * 前缀和统计表（核心）
 * 每分钟一条记录，prefix_sum = 历史所有 status=1 的累计数量
 */
@Data
public class PrefixSum {
    private Long id;
    private String roomId;      // 教室 ID
    private Long timeSlot;      // 时间片（分钟级时间戳，即秒级时间戳 / 60 * 60）
    private Long prefixSum;     // 截至该时间片，累计 1 的总数量
}
