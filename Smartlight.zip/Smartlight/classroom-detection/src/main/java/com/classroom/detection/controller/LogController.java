package com.classroom.detection.controller;

import com.classroom.detection.dto.Result;
import com.classroom.detection.entity.LightAction;
import com.classroom.detection.entity.SensorRecord;
import com.classroom.detection.mapper.LightActionMapper;
import com.classroom.detection.mapper.SensorRecordMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/log")
public class LogController {

    @Autowired
    private LightActionMapper lightActionMapper;

    @Autowired
    private SensorRecordMapper sensorRecordMapper;

    @GetMapping("/list")
    public Result<Map<String, Object>> getActionList(
            @RequestParam(required = false) String roomId,
            @RequestParam(required = false) String actionType,
            @RequestParam(required = false) Long startTime,
            @RequestParam(required = false) Long endTime,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        
        Map<String, Object> data = new HashMap<>();
        try {
            List<LightAction> actions;
            Integer total;
            
            if (startTime != null || endTime != null) {
                actions = lightActionMapper.selectListByTimeRange(roomId, actionType, startTime, endTime, (pageNum - 1) * pageSize, pageSize);
                total = lightActionMapper.countListByTimeRange(roomId, actionType, startTime, endTime);
            } else {
                actions = lightActionMapper.selectList(roomId, actionType, (pageNum - 1) * pageSize, pageSize);
                total = lightActionMapper.countList(roomId, actionType);
            }
            
            data.put("list", actions);
            data.put("total", total);
            data.put("pageNum", pageNum);
            data.put("pageSize", pageSize);
            
            return Result.success(data);
        } catch (Exception e) {
            return Result.fail("查询失败: " + e.getMessage());
        }
    }

    @GetMapping("/statistics")
    public Result<Map<String, Object>> getStatistics() {
        Map<String, Object> data = new HashMap<>();
        try {
            Map<String, Integer> typeCount = new HashMap<>();
            typeCount.put("MANUAL_ON", lightActionMapper.countByType("MANUAL_ON"));
            typeCount.put("MANUAL_OFF", lightActionMapper.countByType("MANUAL_OFF"));
            typeCount.put("AUTO_OFF", lightActionMapper.countByType("AUTO_OFF"));
            typeCount.put("POSTPONE", lightActionMapper.countByType("POSTPONE"));
            
            Map<String, Integer> roomCount = new HashMap<>();
            String[] rooms = {"A101", "A102", "B201", "B202"};
            for (String room : rooms) {
                roomCount.put(room, lightActionMapper.countByRoom(room));
            }
            
            data.put("typeCount", typeCount);
            data.put("roomCount", roomCount);
            
            return Result.success(data);
        } catch (Exception e) {
            return Result.fail("统计失败: " + e.getMessage());
        }
    }

    @GetMapping("/trend")
    public Result<List<Map<String, Object>>> getTrend(
            @RequestParam(defaultValue = "24") Integer hours) {
        try {
            List<Map<String, Object>> trend = lightActionMapper.countTrendByHour(hours);
            return Result.success(trend);
        } catch (Exception e) {
            return Result.fail("查询趋势失败: " + e.getMessage());
        }
    }

    @GetMapping("/sensor")
    public Result<Map<String, Object>> getSensorRecords(
            @RequestParam(required = false) String roomId,
            @RequestParam(required = false) Long startTime,
            @RequestParam(required = false) Long endTime,
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "20") Integer pageSize) {
        
        Map<String, Object> data = new HashMap<>();
        try {
            List<SensorRecord> records;
            
            if (startTime != null || endTime != null) {
                records = sensorRecordMapper.selectByTimeRange(roomId, startTime, endTime);
            } else {
                records = sensorRecordMapper.selectByRoomId(roomId, (pageNum - 1) * pageSize, pageSize);
            }
            
            data.put("list", records);
            return Result.success(data);
        } catch (Exception e) {
            return Result.fail("查询传感器记录失败: " + e.getMessage());
        }
    }
}
