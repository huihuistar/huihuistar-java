<template>
  <div class="user-guide">
    <el-button type="primary" @click="open" class="guide-button">
      <el-icon><QuestionFilled /></el-icon>
      帮助
    </el-button>
    
    <el-dialog
      v-model="dialogVisible"
      title="系统使用指南"
      width="800px"
      :close-on-click-modal="false"
    >
      <el-tabs v-model="activeTab">
        <el-tab-pane label="快速开始" name="quickstart">
          <div class="guide-content">
            <el-timeline>
              <el-timeline-item
                v-for="(item, index) in quickStartSteps"
                :key="index"
                :timestamp="item.step"
                placement="top"
              >
                <h4>{{ item.title }}</h4>
                <p>{{ item.desc }}</p>
              </el-timeline-item>
            </el-timeline>
          </div>
        </el-tab-pane>
        
        <el-tab-pane label="功能说明" name="features">
          <div class="guide-content">
            <el-collapse v-model="activeFeatures">
              <el-collapse-item title="数据统计" name="dashboard">
                <p>查看系统整体运行状态，包括开灯/关灯教室数量、操作类型分布等数据。</p>
                <ul>
                  <li>统计卡片：实时显示开灯教室数、关灯教室数、延时等待次数、自动关灯次数</li>
                  <li>操作类型分布：展示手动开灯、手动关灯、自动关灯、延时等待的比例</li>
                  <li>教室操作排行：显示各教室的操作次数排行</li>
                  <li>最近操作记录：查看最新的5条操作记录</li>
                </ul>
              </el-collapse-item>
              <el-collapse-item title="教室管理" name="classrooms">
                <p>管理和控制所有教室的灯光状态。</p>
                <ul>
                  <li>教室状态卡片：显示教室ID、灯状态、弹窗状态、下次检查时间</li>
                  <li>手动开关灯：点击按钮即可开关对应教室的灯</li>
                  <li>刷新状态：点击刷新按钮获取教室最新状态</li>
                </ul>
              </el-collapse-item>
              <el-collapse-item title="硬件模拟" name="simulation">
                <p>模拟红外传感器上报数据，用于系统测试。</p>
                <ul>
                  <li>选择教室：选择要模拟传感器的教室</li>
                  <li>传感器状态：选择有人/无人状态</li>
                  <li>启动模拟：开始定时上报传感器数据</li>
                  <li>立即上报：手动触发一次数据上报</li>
                </ul>
              </el-collapse-item>
              <el-collapse-item title="延时等待" name="postpone">
                <p>当教室20分钟无人时，系统弹出窗口，可选择延时等待。</p>
                <ul>
                  <li>快速选项：5分钟、10分钟、20分钟、30分钟</li>
                  <li>自定义时间：输入任意分钟数</li>
                  <li>30秒倒计时：超时后自动关灯</li>
                  <li>立即关灯：直接执行关灯操作</li>
                </ul>
              </el-collapse-item>
              <el-collapse-item title="操作日志" name="logs">
                <p>查看系统的所有操作记录。</p>
                <ul>
                  <li>按教室筛选：只查看特定教室的操作</li>
                  <li>按类型筛选：只查看特定类型的操作</li>
                  <li>分页显示：支持翻页查看更多记录</li>
                  <li>操作详情：显示操作类型、操作人、时间等</li>
                </ul>
              </el-collapse-item>
            </el-collapse>
          </div>
        </el-tab-pane>
        
        <el-tab-pane label="常见问题" name="faq">
          <div class="guide-content">
            <el-collapse v-model="activeFaqs">
              <el-collapse-item title="如何修改后端服务地址？" name="backend">
                <p>打开 <code>vite.config.js</code> 文件，修改代理配置中的 <code>target</code> 为实际的后端服务地址。</p>
              </el-collapse-item>
              <el-collapse-item title="弹窗没有显示怎么办？" name="popup">
                <p>请检查以下几点：</p>
                <ul>
                  <li>确认传感器状态选择为"无人"</li>
                  <li>确认当前时间在8:00-22:00之间</li>
                  <li>可以将上报间隔调小（如15秒）快速测试</li>
                </ul>
              </el-collapse-item>
              <el-collapse-item title="如何重置系统？" name="reset">
                <p>在数据库中重新执行 <code>init.sql</code> 脚本即可重置所有数据。</p>
              </el-collapse-item>
              <el-collapse-item title="如何添加更多教室？" name="addroom">
                <p>需要同时修改以下几处：</p>
                <ul>
                  <li>后端数据库：向 <code>tb_room_state</code> 表插入新教室数据</li>
                  <li>前端代码：在 <code>ClassroomsPage.vue</code> 的 <code>rooms</code> 数组中添加新教室</li>
                </ul>
              </el-collapse-item>
            </el-collapse>
          </div>
        </el-tab-pane>
      </el-tabs>
      
      <template #footer>
        <el-button @click="dialogVisible = false">关闭</el-button>
        <el-button type="primary" @click="handleStartGuide" v-if="!tourActive">
          开始引导
        </el-button>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { ElMessage } from 'element-plus'
import { QuestionFilled } from '@element-plus/icons-vue'

const dialogVisible = ref(false)
const activeTab = ref('quickstart')
const activeFeatures = ref(['dashboard'])
const activeFaqs = ref(['backend'])
const tourActive = ref(false)

const quickStartSteps = reactive([
  {
    step: '第一步',
    title: '登录系统',
    desc: '使用默认账号 admin / admin123 登录系统'
  },
  {
    step: '第二步',
    title: '查看数据统计',
    desc: '在数据统计页面查看系统整体运行状态和最近操作'
  },
  {
    step: '第三步',
    title: '教室管理',
    desc: '进入教室管理页面，手动控制教室灯光开关'
  },
  {
    step: '第四步',
    title: '硬件模拟',
    desc: '启动硬件模拟，选择教室和状态，模拟传感器上报'
  },
  {
    step: '第五步',
    title: '查看日志',
    desc: '在操作日志页面查看所有操作记录和筛选功能'
  }
])

const open = () => {
  dialogVisible.value = true
}

const handleStartGuide = () => {
  ElMessage.info('功能引导功能开发中，敬请期待！')
}

defineExpose({
  open
})
</script>

<style scoped>
.user-guide {
  display: inline-block;
}

.guide-button {
  margin: 0;
}

.guide-content {
  padding: 10px 0;
}

.guide-content h4 {
  margin: 0 0 10px 0;
  color: #303133;
}

.guide-content p {
  margin: 0 0 15px 0;
  color: #606266;
  line-height: 1.6;
}

.guide-content ul {
  margin: 10px 0;
  padding-left: 20px;
  color: #606266;
}

.guide-content li {
  margin-bottom: 8px;
}

.guide-content code {
  background: #f5f7fa;
  padding: 2px 6px;
  border-radius: 4px;
  font-family: monospace;
  color: #409eff;
}
</style>
