<template>
  <el-dialog
    v-model="dialogVisible"
    title="教室无人提醒"
    width="550px"
    :close-on-click-modal="false"
    :close-on-press-escape="false"
    :show-close="false"
    @closed="handleClosed"
  >
    <div class="popup-content">
      <div class="alert-section">
        <el-alert
          :title="`教室 ${roomId} 已检测到无人`"
          type="warning"
          :closable="false"
          show-icon
          style="margin-bottom: 20px"
        />
        <p class="alert-desc">系统检测到该教室长时间无人，是否需要进行操作？</p>
      </div>
      
      <div class="countdown-section">
        <div class="countdown-display">
          <div class="countdown-circle" :class="countdownLevel">
            <span class="countdown-time">{{ formatCountdown(countdown) }}</span>
            <span class="countdown-label">自动关灯倒计时</span>
          </div>
        </div>
        <el-progress 
          :percentage="countdownPercentage" 
          :color="countdownColor"
          :stroke-width="8"
          style="margin-top: 20px"
        />
      </div>

      <div class="delay-section">
        <p class="section-title">选择延迟等待时间：</p>
        <el-radio-group v-model="selectedMinutes">
          <el-radio :value="5">5分钟</el-radio>
          <el-radio :value="10">10分钟</el-radio>
          <el-radio :value="20">20分钟</el-radio>
          <el-radio :value="30">30分钟</el-radio>
        </el-radio-group>
        <div class="custom-input" v-if="showCustomInput">
          <el-input-number
            v-model="customMinutes"
            :min="1"
            :max="120"
            placeholder="自定义分钟数"
            style="width: 150px"
          />
          <span style="margin-left: 10px">分钟</span>
        </div>
        <el-checkbox v-model="showCustomInput" style="margin-top: 10px">自定义时间</el-checkbox>
      </div>
    </div>

    <template #footer>
      <div class="dialog-footer">
        <el-button 
          @click="handleKeepLightOn" 
          type="success" 
          :loading="actionLoading"
          :disabled="actionLoading"
        >
          <el-icon><Sunny /></el-icon>
          不关灯
        </el-button>
        <el-button 
          @click="handleDelay" 
          type="primary" 
          :loading="actionLoading"
          :disabled="actionLoading"
        >
          <el-icon><Clock /></el-icon>
          延迟等待
        </el-button>
        <el-button 
          @click="handleTurnOffLight" 
          type="danger" 
          :loading="actionLoading"
          :disabled="actionLoading"
        >
          <el-icon><Moon /></el-icon>
          关灯
        </el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup>
import { ref, computed, watch, onUnmounted } from 'vue'
import { ElMessage, ElNotification } from 'element-plus'
import { Sunny, Moon, Clock } from '@element-plus/icons-vue'
import { lightApi } from '@/api'

const props = defineProps({
  visible: {
    type: Boolean,
    default: false
  },
  roomId: {
    type: String,
    default: ''
  }
})

const emit = defineEmits(['update:visible', 'close', 'keep-light-on', 'delay', 'turn-off'])

const dialogVisible = ref(false)
const countdown = ref(30)
const selectedMinutes = ref(10)
const customMinutes = ref(10)
const showCustomInput = ref(false)
const actionLoading = ref(false)
let countdownTimer = null

const countdownPercentage = computed(() => Math.round((countdown.value / 30) * 100))

const countdownColor = computed(() => {
  if (countdown.value > 20) return '#67c23a'
  if (countdown.value > 10) return '#e6a23c'
  return '#f56c6c'
})

const countdownLevel = computed(() => {
  if (countdown.value > 20) return 'level-safe'
  if (countdown.value > 10) return 'level-warning'
  return 'level-danger'
})

const formatCountdown = (seconds) => {
  const mins = Math.floor(seconds / 60)
  const secs = seconds % 60
  if (mins > 0) return `${mins}:${secs.toString().padStart(2, '0')}`
  return `${secs}秒`
}

const startCountdown = () => {
  stopCountdown()
  countdown.value = 30
  countdownTimer = setInterval(() => {
    countdown.value--
    if (countdown.value <= 0) handleTimeout()
  }, 1000)
}

const stopCountdown = () => {
  if (countdownTimer) {
    clearInterval(countdownTimer)
    countdownTimer = null
  }
}

// 统一关闭弹窗的方法，只在这里操作 dialogVisible
const closeDialog = () => {
  stopCountdown()
  actionLoading.value = false
  dialogVisible.value = false
  emit('update:visible', false)
}

const handleTimeout = async () => {
  stopCountdown()
  actionLoading.value = true
  try {
    await lightApi.autoOff({ roomId: props.roomId })
    ElMessage.success(`${props.roomId} 已自动关灯`)
    ElNotification.warning({
      title: '自动关灯',
      message: `教室 ${props.roomId} 因超时自动关灯`,
      duration: 5000
    })
    emit('close')
  } catch (error) {
    console.error('自动关灯失败:', error)
    ElMessage.error('自动关灯失败')
    startCountdown()
    actionLoading.value = false
    return
  }
  closeDialog()
}

const handleKeepLightOn = async () => {
  if (actionLoading.value) return
  actionLoading.value = true
  stopCountdown()
  try {
    await lightApi.keepLightOn({ roomId: props.roomId })
    ElMessage.success(`${props.roomId} 将保持照明状态`)
    emit('keep-light-on', props.roomId)
  } catch (error) {
    console.error('保持照明失败:', error)
    ElMessage.error('保持照明失败，请重试')
    startCountdown()
    actionLoading.value = false
    return
  }
  closeDialog()
}

const handleDelay = async () => {
  if (actionLoading.value) return
  actionLoading.value = true
  stopCountdown()
  try {
    const minutes = showCustomInput.value ? customMinutes.value : selectedMinutes.value
    await lightApi.postpone({ roomId: props.roomId, minutes })
    ElMessage.success(`已设置 ${minutes} 分钟延时等待`)
    emit('delay', { roomId: props.roomId, minutes })
  } catch (error) {
    console.error('延时等待失败:', error)
    ElMessage.error('延时等待失败，请重试')
    startCountdown()
    actionLoading.value = false
    return
  }
  closeDialog()
}

const handleTurnOffLight = async () => {
  if (actionLoading.value) return
  actionLoading.value = true
  stopCountdown()
  try {
    await lightApi.autoOff({ roomId: props.roomId })
    ElMessage.success(`${props.roomId} 已关灯`)
    emit('turn-off', props.roomId)
  } catch (error) {
    console.error('手动关灯失败:', error)
    ElMessage.error('手动关灯失败，请重试')
    startCountdown()
    actionLoading.value = false
    return
  }
  closeDialog()
}

// 只监听 props.visible 来控制弹窗开关，不再双向绑定 dialogVisible
watch(() => props.visible, (val) => {
  if (val) {
    dialogVisible.value = true
    startCountdown()
  } else {
    closeDialog()
  }
}, { immediate: false })

// el-dialog 自身关闭时（理论上不会触发，因为禁用了点击遮罩和 ESC）
const handleClosed = () => {
  stopCountdown()
}

onUnmounted(() => {
  stopCountdown()
})
</script>

<style scoped>
.popup-content {
  padding: 10px 0;
}

.alert-section {
  margin-bottom: 25px;
}

.alert-desc {
  color: #606266;
  font-size: 14px;
  margin: 0;
  padding-left: 50px;
}

.countdown-section {
  text-align: center;
  margin-bottom: 25px;
}

.countdown-display {
  display: flex;
  justify-content: center;
}

.countdown-circle {
  width: 120px;
  height: 120px;
  border-radius: 50%;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: white;
  transition: all 0.3s ease;
}

.countdown-circle.level-safe {
  background: linear-gradient(135deg, #67c23a, #85ce61);
  box-shadow: 0 4px 15px rgba(103, 194, 58, 0.4);
}

.countdown-circle.level-warning {
  background: linear-gradient(135deg, #e6a23c, #f0c78a);
  box-shadow: 0 4px 15px rgba(230, 162, 60, 0.4);
  animation: pulse-warning 1.5s infinite;
}

.countdown-circle.level-danger {
  background: linear-gradient(135deg, #f56c6c, #f78989);
  box-shadow: 0 4px 15px rgba(245, 108, 108, 0.4);
  animation: pulse-danger 0.8s infinite;
}

@keyframes pulse-warning {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.03); }
}

@keyframes pulse-danger {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.05); }
}

.countdown-time {
  font-size: 36px;
  font-weight: bold;
  line-height: 1;
}

.countdown-label {
  font-size: 12px;
  margin-top: 5px;
  opacity: 0.9;
}

.delay-section {
  margin-bottom: 10px;
}

.section-title {
  font-weight: 500;
  margin-bottom: 15px;
  font-size: 14px;
  color: #303133;
}

.custom-input {
  margin-top: 15px;
  display: flex;
  align-items: center;
}

.dialog-footer {
  display: flex;
  justify-content: center;
  gap: 15px;
}

.dialog-footer .el-button {
  min-width: 120px;
}

@media (max-width: 576px) {
  .dialog-footer {
    flex-direction: column;
  }
  
  .dialog-footer .el-button {
    width: 100%;
  }
}
</style>