<template>
  <div class="classrooms-container">
    <!-- 顶部操作栏 -->
    <div class="page-header">
      <div class="header-left">
        <h2>教室管理</h2>
        <span class="update-time">最后更新: {{ lastUpdateTime }}</span>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="refreshAll" :loading="loading">
            <el-icon><Refresh /></el-icon>
            刷新全部
          </el-button>
          <el-button @click="handleBatchOn">
            <el-icon><Sunny /></el-icon>
            全部开灯
          </el-button>
          <el-button type="danger" @click="handleBatchOff">
            <el-icon><Moon /></el-icon>
            全部关灯
          </el-button>
          <el-button type="success" @click="showAddRoomDialog">
            <el-icon><Plus /></el-icon>
            新增教室
          </el-button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-bar">
      <el-card class="stat-mini" shadow="hover">
        <div class="stat-mini-content">
          <div class="stat-mini-icon" style="background: #e6f7e6; color: #67c23a">
            <el-icon><Sunny /></el-icon>
          </div>
          <div class="stat-mini-info">
            <span class="stat-mini-label">开灯教室</span>
            <span class="stat-mini-value" style="color: #67c23a">{{ lightOnCount }}</span>
          </div>
        </div>
      </el-card>
      <el-card class="stat-mini" shadow="hover">
        <div class="stat-mini-content">
          <div class="stat-mini-icon" style="background: #f4f4f5; color: #909399">
            <el-icon><Moon /></el-icon>
          </div>
          <div class="stat-mini-info">
            <span class="stat-mini-label">关灯教室</span>
            <span class="stat-mini-value" style="color: #909399">{{ lightOffCount }}</span>
          </div>
        </div>
      </el-card>
      <el-card class="stat-mini" shadow="hover">
        <div class="stat-mini-content">
          <div class="stat-mini-icon" style="background: #ecf5ff; color: #409eff">
            <el-icon><VideoPlay /></el-icon>
          </div>
          <div class="stat-mini-info">
            <span class="stat-mini-label">模拟中</span>
            <span class="stat-mini-value" style="color: #409eff">{{ simulationCount }}</span>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 教室网格 -->
    <div class="classrooms-grid">
      <div class="room-card" v-for="room in rooms" :key="room.id">
        <el-card 
          :shadow="room.lightOn ? 'hover' : 'never'" 
          class="room-card-inner"
          :class="{ 'popup-active': room.popupActive }"
        >
          <div class="room-header">
            <div class="room-title">
              <h3>{{ room.id }}</h3>
              <el-tag :type="room.lightOn ? 'success' : 'info'" effect="dark" size="small">
                {{ room.lightOn ? '灯开' : '灯关' }}
              </el-tag>
            </div>
            <el-dropdown trigger="click">
              <el-button circle>
                <el-icon><MoreFilled /></el-icon>
              </el-button>
              <template #dropdown>
                <el-dropdown-menu>
                  <el-dropdown-item @click="showRoomDetail(room)">
                    <el-icon><Document /></el-icon>
                    查看详情
                  </el-dropdown-item>
                  <el-dropdown-item @click="viewRoomHistory(room)">
                    <el-icon><Timer /></el-icon>
                    历史记录
                  </el-dropdown-item>
                  <el-dropdown-item @click="startRoomSimulation(room)">
                    <el-icon><Monitor /></el-icon>
                    启动模拟
                  </el-dropdown-item>
                </el-dropdown-menu>
              </template>
            </el-dropdown>
          </div>
          
          <div class="room-status">
            <div class="status-item">
              <div class="status-icon" :style="room.occupied
                ? { background: '#e6f7e6', color: '#67c23a' }
                : { background: '#f4f4f5', color: '#909399' }">
                <el-icon><User /></el-icon>
              </div>
              <div class="status-text">
                <div class="status-label">人员状态</div>
                <div class="status-value">{{ room.occupied ? '有人' : '无人' }}</div>
              </div>
            </div>
            <div class="status-item">
              <div class="status-icon" :class="{ active: room.popupActive }">
                <el-icon><Bell /></el-icon>
              </div>
              <div class="status-text">
                <div class="status-label">弹窗状态</div>
                <div class="status-value">{{ room.popupActive ? '显示中' : '无弹窗' }}</div>
              </div>
            </div>
            <div class="status-item" v-if="room.nextCheckAt">
              <div class="status-icon">
                <el-icon><Clock /></el-icon>
              </div>
              <div class="status-text">
                <div class="status-label">下次检查</div>
                <div class="status-value">{{ formatTime(room.nextCheckAt) }}</div>
              </div>
            </div>
            <div class="status-item" v-if="room.postponeMinutes">
              <div class="status-icon">
                <el-icon><Timer /></el-icon>
              </div>
              <div class="status-text">
                <div class="status-label">延时设置</div>
                <div class="status-value">{{ room.postponeMinutes }} 分钟</div>
              </div>
            </div>
            <div class="status-item">
              <div class="status-icon">
                <el-icon><View /></el-icon>
              </div>
              <div class="status-text">
                <div class="status-label">最后更新</div>
                <div class="status-value">{{ room.lastUpdate || '-' }}</div>
              </div>
            </div>
          </div>
          
          <div class="room-actions">
            <el-button
              :type="room.lightOn ? 'danger' : 'primary'"
              @click="handleToggle(room.id)"
              class="toggle-btn"
            >
              <el-icon>
                <component :is="room.lightOn ? 'SwitchButton' : 'Switch'" />
              </el-icon>
              {{ room.lightOn ? '关灯' : '开灯' }}
            </el-button>
            <el-button @click="loadRoomStatus(room.id)">
              <el-icon><Refresh /></el-icon>
            </el-button>
          </div>
        </el-card>
      </div>
    </div>

    <!-- 硬件模拟卡片 -->
    <el-card class="simulation-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <div class="header-title">
            <el-icon><Monitor /></el-icon>
            硬件模拟
          </div>
          <el-tag type="success" size="small">运行中 {{ simulationCount }}</el-tag>
        </div>
      </template>
      <div class="simulation-content">
        <!-- 添加新模拟 -->
        <div class="sim-add-row">
          <el-select v-model="newSimRoomId" placeholder="选择教室" size="small" style="width:140px">
            <el-option v-for="room in availableRooms" :key="room.id" :label="room.id" :value="room.id" />
          </el-select>
          <el-select v-model="newSimInterval" placeholder="间隔" size="small" style="width:100px">
            <el-option label="15秒" :value="15" />
            <el-option label="30秒" :value="30" />
            <el-option label="1分钟" :value="60" />
            <el-option label="5分钟" :value="300" />
            <el-option label="10分钟" :value="600" />
          </el-select>
          <el-button type="primary" size="small" @click="addSimulation" :disabled="!newSimRoomId">
            <el-icon><VideoPlay /></el-icon>
            启动
          </el-button>
        </div>

        <!-- 运行中的模拟列表 -->
        <div v-if="runningSims.length === 0" class="sim-empty">暂无运行中的模拟，选择教室后点击启动</div>
        <div v-for="sim in runningSims" :key="sim.roomId" class="sim-item">
          <div class="sim-item-top">
            <div class="sim-item-header">
              <span class="sim-room">{{ sim.roomId }}</span>
              <el-tag :type="sim.status === 1 ? 'success' : 'info'" size="small">
                {{ sim.status === 1 ? '有人' : '无人' }}
              </el-tag>
              <el-tag type="warning" size="small">间隔 {{ intervalLabelMap[sim.interval] || sim.interval + '秒' }}</el-tag>
            </div>
            <div class="sim-item-info">
              <span>上报 {{ sim.reportCount }} 次</span>
              <span v-if="sim.nextReportTime">下次 {{ sim.nextReportTime }}</span>
              <span v-if="sim.remainingSeconds > 0">倒计时 {{ sim.remainingSeconds }}s</span>
            </div>
          </div>
          <div class="sim-item-actions">
            <el-button size="small" @click="toggleSimStatus(sim.roomId)">
              {{ sim.status === 1 ? '切无人' : '切有人' }}
            </el-button>
            <el-button size="small" type="primary" @click="reportForRoom(sim.roomId)">
              立即上报
            </el-button>
            <el-button size="small" type="danger" @click="stopSimulation(sim.roomId)">
              停止
            </el-button>
          </div>
        </div>
      </div>
    </el-card>

    <!-- 教室详情对话框 -->
    <el-dialog v-model="detailVisible" title="教室详情" width="600px">
      <div v-if="currentRoom" class="room-detail">
        <el-descriptions :column="2" border>
          <el-descriptions-item label="教室ID">
            {{ currentRoom.id }}
          </el-descriptions-item>
          <el-descriptions-item label="灯状态">
            <el-tag :type="currentRoom.lightOn ? 'success' : 'info'">
              {{ currentRoom.lightOn ? '开灯' : '关灯' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="弹窗状态">
            <el-tag :type="currentRoom.popupActive ? 'warning' : 'info'">
              {{ currentRoom.popupActive ? '显示中' : '无' }}
            </el-tag>
          </el-descriptions-item>
          <el-descriptions-item label="下次检查">
            {{ currentRoom.nextCheckAt ? formatTime(currentRoom.nextCheckAt) : '-' }}
          </el-descriptions-item>
          <el-descriptions-item label="延时时间">
            {{ currentRoom.postponeMinutes ? currentRoom.postponeMinutes + ' 分钟' : '-' }}
          </el-descriptions-item>
          <el-descriptions-item label="最后更新">
            {{ currentRoom.lastUpdate || '-' }}
          </el-descriptions-item>
        </el-descriptions>
        <div class="detail-actions" style="margin-top: 20px">
          <el-button type="primary" @click="handleToggle(currentRoom.id)">
            {{ currentRoom.lightOn ? '关灯' : '开灯' }}
          </el-button>
          <el-button @click="loadRoomStatus(currentRoom.id)">刷新状态</el-button>
        </div>
      </div>
    </el-dialog>

    <!-- 历史记录对话框 -->
    <el-dialog v-model="historyVisible" title="教室历史记录" width="800px">
      <div v-if="currentRoom" class="room-history">
        <el-tabs v-model="activeHistoryTab">
          <el-tab-pane label="操作记录" name="actions">
            <el-table :data="roomHistory.actions" style="width: 100%" stripe>
              <el-table-column prop="actionType" label="操作类型" width="140">
                <template #default="scope">
                  <el-tag :type="getActionTypeTag(scope.row.actionType)">
                    {{ getActionTypeLabel(scope.row.actionType) }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="operator" label="操作人" width="120" />
              <el-table-column prop="createTime" label="操作时间">
                <template #default="scope">
                  {{ formatTime(scope.row.createTime) }}
                </template>
              </el-table-column>
              <el-table-column prop="intervalMinutes" label="延时分钟" width="120">
                <template #default="scope">
                  {{ scope.row.intervalMinutes > 0 ? scope.row.intervalMinutes + ' 分钟' : '-' }}
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
          <el-tab-pane label="传感器记录" name="sensor">
            <el-table :data="roomHistory.sensor" style="width: 100%" stripe>
              <el-table-column prop="deviceId" label="设备ID" width="140" />
              <el-table-column prop="status" label="状态" width="120">
                <template #default="scope">
                  <el-tag :type="scope.row.status === 1 ? 'success' : 'info'">
                    {{ scope.row.status === 1 ? '有人' : '无人' }}
                  </el-tag>
                </template>
              </el-table-column>
              <el-table-column prop="createTime" label="上报时间">
                <template #default="scope">
                  {{ formatTime(scope.row.createTime) }}
                </template>
              </el-table-column>
            </el-table>
          </el-tab-pane>
        </el-tabs>
      </div>
    </el-dialog>

    <!-- 新增教室对话框 -->
    <el-dialog v-model="addRoomVisible" title="新增教室" width="500px">
      <el-form :model="addRoomForm" :rules="addRoomRules" ref="addRoomFormRef" label-width="100px">
        <el-form-item label="教室ID" prop="roomId">
          <el-input 
            v-model="addRoomForm.roomId" 
            placeholder="请输入教室ID，如A101"
            maxlength="10"
          />
        </el-form-item>
        <el-form-item label="教室名称" prop="roomName">
          <el-input 
            v-model="addRoomForm.roomName" 
            placeholder="请输入教室名称"
            maxlength="50"
          />
        </el-form-item>
        <el-form-item label="容量(人)" prop="capacity">
          <el-input 
            v-model.number="addRoomForm.capacity" 
            type="number"
            placeholder="请输入教室容量"
            min="1"
            max="500"
          />
        </el-form-item>
        <el-form-item label="设备配置">
          <el-checkbox-group v-model="addRoomForm.devices">
            <el-checkbox label="红外传感器" value="infrared" />
            <el-checkbox label="灯光控制" value="light" />
            <el-checkbox label="延时弹窗" value="popup" />
          </el-checkbox-group>
        </el-form-item>
        <el-form-item label="备注">
          <el-input 
            v-model="addRoomForm.remark" 
            type="textarea"
            placeholder="请输入备注信息"
            :rows="3"
            maxlength="200"
          />
        </el-form-item>
      </el-form>
      <template #footer>
        <el-button @click="addRoomVisible = false">取消</el-button>
        <el-button type="primary" @click="handleAddRoom" :loading="addingRoom">
          确认添加
        </el-button>
      </template>
    </el-dialog>

    <!-- 无人弹窗 -->
    <PostponePopup
      v-model:visible="popupVisible"
      :room-id="popupRoomId"
      @close="handlePopupTurnOff"
      @keep-light-on="handlePopupKeepLight"
      @delay="handlePopupDelay"
      @turn-off="handlePopupTurnOff"
    />
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, onUnmounted } from 'vue'
import { ElMessage, ElNotification, ElMessageBox } from 'element-plus'
import {
  Bell, Clock, Timer, Refresh, Monitor, VideoPlay, VideoPause, Position,
  Sunny, Moon, MoreFilled, Document, View, Switch, SwitchButton, Plus, User
} from '@element-plus/icons-vue'
import { sensorApi, lightApi, logApi } from '@/api'
import PostponePopup from '@/components/PostponePopup.vue'

const rooms = ref([])

// ==================== 弹窗状态 ====================
const popupVisible = ref(false)
const popupRoomId = ref('')

// ==================== 多教室模拟：key = roomId ====================
const simulations = reactive({})

function ensureSim(roomId) {
  if (!simulations[roomId]) {
    simulations[roomId] = {
      roomId,
      status: 1,
      running: false,
      interval: 600,
      reportCount: 0,
      remainingSeconds: 0,
      nextReportTime: '',
      timers: { report: null, nextReport: null, countdown: null }
    }
  }
  return simulations[roomId]
}

function clearSimTimers(sim) {
  if (sim.timers.report) { clearInterval(sim.timers.report); sim.timers.report = null }
  if (sim.timers.nextReport) { clearInterval(sim.timers.nextReport); sim.timers.nextReport = null }
  if (sim.timers.countdown) { clearInterval(sim.timers.countdown); sim.timers.countdown = null }
}

// 新增模拟的表单 ref
const newSimRoomId = ref('')
const newSimInterval = ref(600)

// 未被模拟的教室列表
const availableRooms = computed(() => rooms.value.filter(r => !simulations[r.id]?.running))
// 运行中的模拟列表
const runningSims = computed(() => Object.values(simulations).filter(s => s.running))

const intervalLabelMap = { 15: '15秒', 30: '30秒', 60: '1分钟', 300: '5分钟', 600: '10分钟' }

const lastUpdateTime = ref('-')
const loading = ref(false)
let pollTimer = null

// 对话框状态
const detailVisible = ref(false)
const historyVisible = ref(false)
const addRoomVisible = ref(false)
const currentRoom = ref(null)
const activeHistoryTab = ref('actions')
const roomHistory = reactive({
  actions: [],
  sensor: []
})

// 新增教室表单
const addRoomForm = reactive({
  roomId: '',
  roomName: '',
  capacity: 30,
  devices: ['infrared', 'light', 'popup'],
  remark: ''
})

const addRoomRules = {
  roomId: [
    { required: true, message: '请输入教室ID', trigger: 'blur' },
    { pattern: /^[A-Za-z0-9]{2,10}$/, message: '教室ID格式错误，只能包含字母和数字，长度2-10', trigger: 'blur' }
  ],
  roomName: [
    { required: true, message: '请输入教室名称', trigger: 'blur' },
    { min: 2, max: 50, message: '教室名称长度2-50个字符', trigger: 'blur' }
  ],
  capacity: [
    { required: true, message: '请输入教室容量', trigger: 'blur' },
    { type: 'number', min: 1, max: 500, message: '容量范围1-500', trigger: 'blur' }
  ]
}

const addRoomFormRef = ref(null)
const addingRoom = ref(false)

// ==================== 计算属性 ====================
const lightOnCount = computed(() => rooms.value.filter(r => r.lightOn).length)
const lightOffCount = computed(() => rooms.value.length - lightOnCount.value)
const simulationCount = computed(() => runningSims.value.length)

// 工具函数
const getActionTypeLabel = (type) => {
  const labels = {
    'MANUAL_ON': '手动开灯',
    'MANUAL_OFF': '手动关灯',
    'AUTO_OFF': '自动关灯',
    'POSTPONE': '延时等待'
  }
  return labels[type] || type
}

const getActionTypeTag = (type) => {
  const tags = {
    'MANUAL_ON': 'success',
    'MANUAL_OFF': 'danger',
    'AUTO_OFF': 'warning',
    'POSTPONE': 'info'
  }
  return tags[type] || ''
}

const formatTime = (timestamp) => {
  if (!timestamp) return '-'
  const date = new Date(timestamp)
  return date.toLocaleString('zh-CN')
}

const formatTimeShort = (date) => {
  return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
}

// ==================== 数据加载 ====================
const loadRoomStatus = async (roomId) => {
  try {
    const res = await lightApi.getStatus(roomId)
    const room = rooms.value.find(r => r.id === roomId)
    if (room) {
      room.lightOn = res.data.lightOn
      room.popupActive = res.data.popupActive
      room.nextCheckAt = res.data.nextCheckAt
      room.postponeMinutes = res.data.postponeMinutes
      room.occupied = res.data.occupied ?? room.occupied
      room.lastUpdate = formatTimeShort(new Date())
    }
    ElMessage.success(`${roomId} 状态已刷新`)
  } catch (error) {
    console.error(`加载教室 ${roomId} 状态失败:`, error)
    ElMessage.error(`加载教室 ${roomId} 状态失败`)
  }
}

let pollFailCount = 0
// 记录每个教室弹窗的冷却截止时间（毫秒时间戳），冷却期内不重复弹窗
const popupCooldownUntil = {}

const loadAllRoomsStatus = async () => {
  try {
    const res = await lightApi.getAllStatus()
    if (res.data && Array.isArray(res.data) && res.data.length > 0) {
      rooms.value = res.data.map(item => ({
        id: item.roomId,
        lightOn: item.lightOn,
        occupied: item.occupied,
        popupActive: item.popupActive,
        nextCheckAt: item.nextCheckAt,
        postponeMinutes: item.postponeMinutes,
        lastUpdate: formatTimeShort(new Date())
      }))
      console.log('[poll] 后端教室状态:', rooms.value.map(r => `${r.id}: lightOn=${r.lightOn} occupied=${r.occupied}`).join(', '))
      lastUpdateTime.value = new Date().toLocaleString('zh-CN')
      pollFailCount = 0

      // 检测后端 popupActive，触发弹窗（处理真实硬件上报场景）
      // 冷却期内不重复弹
      const now = Date.now()
      for (const room of rooms.value) {
        const cooldown = popupCooldownUntil[room.id] || 0
        const inCooldown = now <= cooldown
        console.log(`[poll] ${room.id}: popupActive=${room.popupActive} lightOn=${room.lightOn} popupVisible=${popupVisible.value} inCooldown=${inCooldown} cooldownRemain=${Math.round((cooldown-now)/1000)}s`)
        if (room.popupActive && room.lightOn && !popupVisible.value && !inCooldown) {
          console.log('[poll] 触发弹窗，roomId=', room.id)
          popupCooldownUntil[room.id] = now + 90 * 1000
          popupRoomId.value = room.id
          popupVisible.value = true
          break
        }
      }

      return
    }
    if (rooms.value.length === 0) {
      console.warn('后端无教室数据，请先创建教室')
    }
  } catch (error) {
    pollFailCount++
    console.error('加载教室列表失败 (第' + pollFailCount + '次):', error)
    if (pollFailCount === 1) {
      ElMessage.warning('无法连接后端，显示的是缓存数据')
    }
  }
}

const refreshAll = async () => {
  loading.value = true
  try {
    await loadAllRoomsStatus()
    ElMessage.success('刷新成功')
  } catch (error) {
    ElMessage.error('刷新失败')
  } finally {
    loading.value = false
  }
}

// 操作处理
const handleToggle = async (roomId) => {
  try {
    const res = await lightApi.toggle({ roomId })
    const room = rooms.value.find(r => r.id === roomId)
    if (room) {
      room.lightOn = res.data.lightOn
      // occupied 从数据库传感器记录取，不本地猜
      room.occupied = res.data.occupied ?? room.occupied
      room.popupActive = false
      room.nextCheckAt = null
      room.postponeMinutes = 0
      room.lastUpdate = formatTimeShort(new Date())
    }
    ElMessage.success(res.data.message)

    // 如果是关灯，通知 Dashboard 关闭弹窗
    if (!res.data.lightOn) {
      window.dispatchEvent(new CustomEvent('manual-light-off', { detail: { roomId } }))
    }

    // 如果在详情对话框中，也更新
    if (currentRoom.value?.id === roomId) {
      currentRoom.value = { ...room }
    }
  } catch (error) {
    console.error('开关灯失败:', error)
    ElMessage.error('开关灯失败')
  }
}

const handleBatchOn = async () => {
  try {
    await ElMessageBox.confirm('确定要打开所有教室的灯吗？', '确认', {
      type: 'warning'
    })
    
    const promises = rooms.value.filter(r => !r.lightOn).map(room => 
      lightApi.toggle({ roomId: room.id })
    )
    
    if (promises.length > 0) {
      await Promise.all(promises)
    }
    
    // 从后端拉取最新状态（含 occupied），不本地猜
    await loadAllRoomsStatus()
    ElMessage.success('已全部开灯')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('批量开灯失败:', error)
      ElMessage.error('批量开灯失败')
    }
  }
}

const handleBatchOff = async () => {
  try {
    await ElMessageBox.confirm('确定要关闭所有教室的灯吗？', '确认', {
      type: 'warning'
    })
    
    const promises = rooms.value.filter(r => r.lightOn).map(room => 
      lightApi.toggle({ roomId: room.id })
    )
    
    if (promises.length === 0) {
      ElMessage.info('所有教室灯已关闭')
      return
    }
    
    await Promise.all(promises)
    // 从后端拉取最新状态（含 occupied），不本地猜
    await loadAllRoomsStatus()
    ElMessage.success('已全部关灯')
  } catch (error) {
    if (error !== 'cancel') {
      console.error('批量关灯失败:', error)
      ElMessage.error('批量关灯失败')
    }
  }
}

// ==================== 硬件模拟（多教室） ====================
const handleReport = async (roomId) => {
  const sim = simulations[roomId]
  if (!sim) return

  try {
    const res = await sensorApi.report({
      deviceId: `IR-${roomId}`,
      roomId,
      status: sim.status
    })

    const room = rooms.value.find(r => r.id === roomId)
    if (room) {
      // 不覆盖 lightOn：模拟上报只反映传感器数据，灯光状态以 statusAll 轮询为准
      // 否则 autoOff 关灯后模拟上报可能读到旧快照，把灯"开"回来
      room.occupied = res.data.occupied
      room.popupActive = res.data.popupActive
      room.nextCheckAt = res.data.nextCheckAt
      room.postponeMinutes = res.data.postponeMinutes
      room.lastUpdate = formatTimeShort(new Date())
    }

    handleUnoccupiedNotification(res.data, roomId, sim.status)
    sim.reportCount++
  } catch (error) {
    console.error(`上报 ${roomId} 失败:`, error)
    ElMessage.error('传感器数据上报失败')
  }
}

const handleUnoccupiedNotification = (data, roomId, sensorStatus) => {
  notifyDashboard(roomId, sensorStatus)
  if (sensorStatus === 0) {
    ElNotification.info({
      title: '传感器状态更新',
      message: `教室 ${roomId} 检测到无人状态`,
      duration: 5000,
      position: 'top-right',
      icon: 'Bell'
    })
  }
  if (data.needPopup) {
    const now = Date.now()
    const cooldown = popupCooldownUntil[roomId] || 0
    if (now > cooldown) {
      popupCooldownUntil[roomId] = now + 90 * 1000
      popupRoomId.value = roomId
      popupVisible.value = true
      ElNotification.warning({
        title: '教室无人提醒',
        message: `${roomId} 已检测到无人，是否需要关灯？`,
        duration: 30000,
        position: 'top-right',
        showClose: true
      })
    }
  }
}

const notifyDashboard = (roomId, status) => {
  window.dispatchEvent(new CustomEvent('sensor-update', {
    detail: { roomId, status }
  }))
}

const handlePopupTurnOff = () => {
  const roomId = popupRoomId.value
  console.log('[handlePopupTurnOff] 弹窗关闭, roomId=', roomId)
  // 设置冷却期，防止轮询重复弹
  popupCooldownUntil[roomId] = Date.now() + 90 * 1000
  popupVisible.value = false
  const room = rooms.value.find(r => r.id === roomId)
  if (room) {
    room.lightOn = false
    room.occupied = false
    room.popupActive = false
    room.lastUpdate = formatTimeShort(new Date())
  }
}

// 不关灯：后端已处理，设置冷却期防止轮询重复弹
const handlePopupKeepLight = (roomId) => {
  const id = roomId || popupRoomId.value
  console.log('[handlePopupKeepLight] 保持照明, roomId=', id)
  popupCooldownUntil[id] = Date.now() + 90 * 1000
  popupVisible.value = false
  const room = rooms.value.find(r => r.id === id)
  if (room) {
    room.popupActive = false
    room.lastUpdate = formatTimeShort(new Date())
  }
}

// 延迟等待：后端已处理，设置冷却期防止轮询重复弹
const handlePopupDelay = ({ roomId } = {}) => {
  const id = roomId || popupRoomId.value
  console.log('[handlePopupDelay] 延迟等待, roomId=', id)
  popupCooldownUntil[id] = Date.now() + 90 * 1000
  popupVisible.value = false
  const room = rooms.value.find(r => r.id === id)
  if (room) {
    room.popupActive = false
    room.lastUpdate = formatTimeShort(new Date())
  }
}

// 从硬件模拟卡片的「启动」按钮
const addSimulation = () => {
  if (!newSimRoomId.value) {
    ElMessage.warning('请选择教室')
    return
  }
  startSimulation(newSimRoomId.value, newSimInterval.value, 1)
  newSimRoomId.value = ''
}

// 从房间下拉菜单启动
const startRoomSimulation = (room) => {
  startSimulation(room.id, 10, 1)  // 10秒上报一次，快速测试
}

// 切换有人/无人
const toggleSimStatus = async (roomId) => {
  const sim = simulations[roomId]
  if (sim) {
    sim.status = sim.status === 1 ? 0 : 1
    const room = rooms.value.find(r => r.id === roomId)
    if (room) {
      room.occupied = sim.status === 1
    }
    // 立即上报，让数据库同步，防止轮询覆盖
    await handleReport(roomId)
  }
}

// 立即上报
const reportForRoom = (roomId) => {
  handleReport(roomId)
}

const startSimulation = (roomId, interval = 600, status = 1) => {
  if (!roomId) return

  const sim = ensureSim(roomId)

  // 如果已在运行，先清旧定时器再重启
  if (sim.running) {
    clearSimTimers(sim)
  }

  sim.status = status
  sim.interval = interval
  sim.running = true
  sim.reportCount = 0
  sim.remainingSeconds = interval

  // 立刻上报一次
  handleReport(roomId)

  // 定时上报
  sim.timers.report = setInterval(() => handleReport(roomId), interval * 1000)

  // 每秒更新下次上报时间
  sim.timers.nextReport = setInterval(() => {
    const next = new Date(Date.now() + interval * 1000)
    sim.nextReportTime = next.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
  }, 1000)

  // 倒计时
  sim.timers.countdown = setInterval(() => {
    if (sim.remainingSeconds > 0) {
      sim.remainingSeconds--
    } else {
      sim.remainingSeconds = interval
    }
  }, 1000)

  ElMessage.success(`${roomId} 硬件模拟已启动`)
}

const stopSimulation = (roomId) => {
  const sim = simulations[roomId]
  if (!sim) return

  sim.running = false
  sim.status = 0
  sim.nextReportTime = ''
  sim.remainingSeconds = 0
  clearSimTimers(sim)
  ElMessage.info(`${roomId} 硬件模拟已停止`)
}

// 新增教室
const showAddRoomDialog = () => {
  addRoomForm.roomId = ''
  addRoomForm.roomName = ''
  addRoomForm.capacity = 30
  addRoomForm.devices = ['infrared', 'light', 'popup']
  addRoomForm.remark = ''
  addRoomVisible.value = true
}

const handleAddRoom = async () => {
  if (!addRoomFormRef.value) return
  
  try {
    const valid = await addRoomFormRef.value.validate()
    if (!valid) return
    
    addingRoom.value = true
    
    if (rooms.value.some(r => r.id === addRoomForm.roomId)) {
      ElMessage.error(`教室ID ${addRoomForm.roomId} 已存在`)
      addingRoom.value = false
      return
    }

    // 调用后端持久化新教室（getOrCreate：不存在则 INSERT）
    await lightApi.createRoom({ roomId: addRoomForm.roomId })

    // 成功后刷新列表（从后端重新拉）
    await loadAllRoomsStatus()
    
    addRoomVisible.value = false
    addingRoom.value = false
    ElMessage.success(`教室 ${addRoomForm.roomId} 添加成功`)
  } catch (error) {
    console.error('添加教室失败:', error)
    addingRoom.value = false
    ElMessage.error('添加教室失败')
  }
}

// 详情和历史记录
const showRoomDetail = (room) => {
  currentRoom.value = { ...room }
  detailVisible.value = true
}

const viewRoomHistory = async (room) => {
  currentRoom.value = { ...room }
  historyVisible.value = true
  activeHistoryTab.value = 'actions'
  
  // 加载操作记录
  try {
    const [actionsRes, sensorRes] = await Promise.all([
      logApi.getList({ roomId: room.id, pageNum: 1, pageSize: 20 }),
      logApi.getSensorRecords({ roomId: room.id, pageNum: 1, pageSize: 20 })
    ])
    roomHistory.actions = actionsRes.data.list || []
    roomHistory.sensor = sensorRes.data.list || []
  } catch (error) {
    console.error('加载历史记录失败:', error)
    ElMessage.error('加载历史记录失败')
  }
}

// 自动轮询：每10秒同步后端状态（含自动关灯结果）
const startPolling = () => {
  stopPolling()
  pollTimer = setInterval(() => {
    loadAllRoomsStatus()
  }, 10000)
}
const stopPolling = () => {
  if (pollTimer) {
    clearInterval(pollTimer)
    pollTimer = null
  }
}

onMounted(() => {
  loadAllRoomsStatus()
  startPolling()
})

onUnmounted(() => {
  Object.keys(simulations).forEach(roomId => stopSimulation(roomId))
  stopPolling()
})
</script>

<style scoped>
.classrooms-container {
  padding: 20px;
}

.page-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 16px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-left h2 {
  margin: 0;
  color: #303133;
}

.update-time {
  color: #909399;
  font-size: 14px;
}

.header-right {
  display: flex;
  gap: 12px;
}

.stats-bar {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 20px;
  margin-bottom: 20px;
}

.stat-mini {
  border-radius: 8px;
}

.stat-mini-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-mini-icon {
  width: 48px;
  height: 48px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
}

.stat-mini-info {
  flex: 1;
}

.stat-mini-label {
  color: #606266;
  font-size: 14px;
  display: block;
}

.stat-mini-value {
  font-size: 28px;
  font-weight: bold;
  line-height: 1.2;
}

.classrooms-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
  gap: 20px;
  margin-bottom: 20px;
}

.room-card {
  border-radius: 8px;
}

.room-card-inner {
  height: 100%;
}

.room-card-inner.popup-active {
  border: 2px solid #e6a23c;
}

.room-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 20px;
}

.room-title {
  display: flex;
  align-items: center;
  gap: 12px;
}

.room-title h3 {
  margin: 0;
  color: #303133;
  font-size: 20px;
}

.room-status {
  margin-bottom: 20px;
}

.status-item {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 12px;
}

.status-icon {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: #f5f7fa;
  color: #909399;
  font-size: 18px;
}

.status-icon.active {
  background: #fdf6ec;
  color: #e6a23c;
}

.status-text {
  flex: 1;
}

.status-label {
  color: #909399;
  font-size: 12px;
  margin-bottom: 2px;
}

.status-value {
  color: #303133;
  font-size: 14px;
}

.room-actions {
  display: flex;
  gap: 10px;
}

.toggle-btn {
  flex: 1;
}

.simulation-card {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 600;
}

.header-title {
  display: flex;
  align-items: center;
  gap: 8px;
}

.header-tags {
  display: flex;
  gap: 8px;
}

.simulation-content {
  padding: 10px 0;
}

.select-current {
  margin-left: 8px;
  font-size: 13px;
  color: #409eff;
  font-weight: 500;
}
.select-current.none {
  color: #c0c4cc;
}

.simulation-buttons {
  display: flex;
  gap: 12px;
  margin-bottom: 20px;
}

.simulation-info {
  padding-top: 20px;
  border-top: 1px solid #f0f0f0;
}

.sim-add-row {
  display: flex;
  gap: 10px;
  align-items: center;
  margin-bottom: 16px;
  padding-bottom: 16px;
  border-bottom: 1px solid #f0f0f0;
}

.sim-empty {
  color: #c0c4cc;
  text-align: center;
  padding: 24px 0;
  font-size: 14px;
}

.sim-item {
  padding: 12px;
  margin-bottom: 10px;
  border: 1px solid #ebeef5;
  border-radius: 8px;
  background: #fafafa;
}

.sim-item:last-child {
  margin-bottom: 0;
}

.sim-item-top {
  margin-bottom: 10px;
}

.sim-item-header {
  display: flex;
  align-items: center;
  gap: 8px;
  margin-bottom: 6px;
}

.sim-room {
  font-weight: 600;
  font-size: 15px;
  color: #303133;
}

.sim-item-info {
  display: flex;
  gap: 16px;
  font-size: 13px;
  color: #909399;
}

.sim-item-actions {
  display: flex;
  gap: 8px;
}

.detail-actions {
  display: flex;
  gap: 12px;
}

@media (max-width: 992px) {
  .stats-bar {
    grid-template-columns: 1fr;
  }
  
  .classrooms-grid {
    grid-template-columns: 1fr;
  }
}
</style>
