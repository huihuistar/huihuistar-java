<template>
  <div class="dashboard-container">
    <!-- 顶部操作栏 -->
    <div class="dashboard-header">
      <div class="header-left">
        <h2>数据概览</h2>
        <span class="update-time">最后更新: {{ lastUpdateTime }}</span>
      </div>
      <div class="header-right">
        <el-button type="primary" @click="refreshAll" :loading="loading">
          <el-icon><Refresh /></el-icon>
          刷新数据
        </el-button>
        <el-select v-model="timeRange" @change="handleTimeRangeChange" style="width: 150px">
          <el-option label="最近1小时" :value="1" />
          <el-option label="最近6小时" :value="6" />
          <el-option label="最近24小时" :value="24" />
          <el-option label="最近7天" :value="168" />
        </el-select>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-cards">
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon light-on">
            <el-icon><Sunny /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.lightOnCount }}</div>
            <div class="stat-label">开灯教室数</div>
            <div class="stat-trend" v-if="stats.lightOnCount > 0">
              <el-tag type="success" size="small">当前</el-tag>
            </div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon light-off">
            <el-icon><Moon /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.lightOffCount }}</div>
            <div class="stat-label">关灯教室数</div>
            <div class="stat-trend" v-if="stats.lightOffCount > 0">
              <el-tag type="info" size="small">当前</el-tag>
            </div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon postpone">
            <el-icon><Clock /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.totalPostpone }}</div>
            <div class="stat-label">延时等待次数</div>
            <div class="stat-trend">
              <el-tag type="primary" size="small">{{ timeRange }}小时</el-tag>
            </div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon auto-off">
            <el-icon><Warning /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.totalAutoOff }}</div>
            <div class="stat-label">自动关灯次数</div>
            <div class="stat-trend">
              <el-tag type="warning" size="small">{{ timeRange }}小时</el-tag>
            </div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon energy">
            <el-icon><Lightning /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ energySaving }}</div>
            <div class="stat-label">预计节能(度)</div>
            <div class="stat-trend">
              <el-tag type="success" size="small">累计</el-tag>
            </div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon efficiency">
            <el-icon><TrendCharts /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ efficiencyRate }}%</div>
            <div class="stat-label">节能效率</div>
            <div class="stat-trend">
              <el-tag type="success" size="small">实时</el-tag>
            </div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 第一行图表 -->
    <div class="charts-row">
      <!-- 操作类型分布 -->
      <el-card class="chart-card" shadow="hover">
        <template #header>
          <div class="card-header">
            <span><el-icon><DataLine /></el-icon> 操作类型分布</span>
          </div>
        </template>
        <div class="chart-container">
          <div v-if="typeChartData.length" class="type-chart">
            <div v-for="item in typeChartData" :key="item.type" class="chart-item">
              <div class="chart-item-header">
                <span class="chart-label">
                  <el-icon :color="item.color"><component :is="getTypeIcon(item.type)" /></el-icon>
                  {{ item.label }}
                </span>
                <span class="chart-count">{{ item.count }} 次</span>
              </div>
              <el-progress 
                :percentage="item.percentage" 
                :color="item.color"
                :stroke-width="12"
                :show-text="false"
              />
              <span class="chart-percentage">{{ item.percentage }}%</span>
            </div>
          </div>
          <el-empty v-else description="暂无数据" />
        </div>
      </el-card>

      <!-- 教室操作排行 -->
      <el-card class="chart-card" shadow="hover">
        <template #header>
          <div class="card-header">
            <span><el-icon><Trophy /></el-icon> 教室操作排行</span>
          </div>
        </template>
        <div class="chart-container">
          <div v-if="roomChartData.length" class="room-chart">
            <div v-for="item in roomChartData" :key="item.room" class="rank-item">
              <div class="rank-number" :style="{ backgroundColor: item.color }">
                {{ item.rank }}
              </div>
              <div class="rank-info">
                <span class="rank-room">{{ item.room }}</span>
                <span class="rank-count">{{ item.count }} 次操作</span>
              </div>
            </div>
          </div>
          <el-empty v-else description="暂无数据" />
        </div>
      </el-card>
    </div>

    <!-- 第二行图表 -->
    <div class="charts-row">
      <!-- 趋势图 -->
      <el-card class="chart-card chart-card-large" shadow="hover">
        <template #header>
          <div class="card-header">
            <span><el-icon><TrendCharts /></el-icon> 操作趋势</span>
            <el-radio-group v-model="trendType" size="small" @change="loadTrendData">
              <el-radio-button value="all">全部</el-radio-button>
              <el-radio-button value="MANUAL_ON">开灯</el-radio-button>
              <el-radio-button value="MANUAL_OFF">关灯</el-radio-button>
              <el-radio-button value="AUTO_OFF">自动关灯</el-radio-button>
            </el-radio-group>
          </div>
        </template>
        <div class="chart-container">
          <div v-if="trendData.length" class="trend-chart">
            <div v-for="(item, index) in trendData" :key="index" class="trend-item">
              <div class="trend-time">{{ item.hour }}</div>
              <div class="trend-bars">
                <div 
                  v-for="(value, type) in item.data" 
                  :key="type"
                  class="trend-bar"
                  :style="{ 
                    width: (value / maxTrendValue * 100) + '%',
                    backgroundColor: getTypeColor(type)
                  }"
                  :title="getActionTypeLabel(type) + ': ' + value + '次'"
                ></div>
              </div>
              <div class="trend-total">{{ item.total }} 次</div>
            </div>
          </div>
          <el-empty v-else description="暂无趋势数据" />
        </div>
      </el-card>
    </div>

    <!-- 实时通知区域 -->
    <el-card class="notification-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <span><el-icon><Bell /></el-icon> 实时通知</span>
          <el-tag type="info" size="small">{{ notifications.length }} 条</el-tag>
        </div>
      </template>
      <div class="notification-container">
        <div v-if="notifications.length" class="notification-list">
          <div v-for="(item, index) in notifications" :key="index" class="notification-item" :class="item.type">
            <div class="notification-icon">
              <el-icon><component :is="item.icon" /></el-icon>
            </div>
            <div class="notification-content">
              <div class="notification-title">{{ item.title }}</div>
              <div class="notification-desc">{{ item.desc }}</div>
              <div class="notification-time">{{ item.time }}</div>
            </div>
          </div>
        </div>
        <el-empty v-else description="暂无通知" :image-size="60" />
      </div>
    </el-card>

    <!-- 最近操作记录 -->
    <el-card class="recent-actions-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <span><el-icon><List /></el-icon> 最近操作记录</span>
          <el-button type="primary" link @click="goToLogs">查看全部</el-button>
        </div>
      </template>
      <el-table :data="recentActions" style="width: 100%" stripe>
        <el-table-column prop="roomId" label="教室" width="100">
          <template #default="scope">
            <el-tag type="info">{{ scope.row.roomId }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="actionType" label="操作类型" width="140">
          <template #default="scope">
            <el-tag :type="getActionTypeTag(scope.row.actionType)">
              {{ getActionTypeLabel(scope.row.actionType) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="operator" label="操作人" width="120" />
        <el-table-column prop="createTime" label="操作时间">
          <template #default="scope">
            {{ formatTime(scope.row.createTime) }}
          </template>
        </el-table-column>
        <el-table-column prop="intervalMinutes" label="延时分钟" width="120">
          <template #default="scope">
            {{ scope.row.intervalMinutes > 0 ? scope.row.intervalMinutes + ' 分钟' : '-' }}
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, onMounted, onUnmounted, computed } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { 
  Sunny, Moon, Clock, Warning, Lightning, 
  TrendCharts, DataLine, Trophy, Bell, List,
  Refresh, Switch, SwitchButton, VideoPause
} from '@element-plus/icons-vue'
import { logApi, lightApi } from '@/api'

const router = useRouter()
const stats = reactive({
  lightOnCount: 0,
  lightOffCount: 0,
  totalPostpone: 0,
  totalAutoOff: 0
})
const typeChartData = ref([])
const roomChartData = ref([])
const recentActions = ref([])
const trendData = ref([])
const notifications = ref([])
const timeRange = ref(24)
const trendType = ref('all')
const lastUpdateTime = ref('-')
const loading = ref(false)

const roomIds = ['A101', 'A102', 'B201', 'B202']

// 计算属性
const maxTrendValue = computed(() => {
  if (!trendData.value.length) return 1
  return Math.max(...trendData.value.map(item => item.total))
})

const energySaving = computed(() => {
  // 模拟节能计算
  return (stats.totalAutoOff * 0.5).toFixed(1)
})

const efficiencyRate = computed(() => {
  const total = stats.totalPostpone + stats.totalAutoOff
  if (total === 0) return 0
  return Math.round((stats.totalAutoOff / total) * 100)
})

// 工具函数
const getActionTypeLabel = (type) => {
  const labels = {
    'MANUAL_ON': '手动开灯',
    'MANUAL_OFF': '手动关灯',
    'AUTO_OFF': '自动关灯',
    'POSTPONE': '延时等待'
  }
  return labels[type] || type
}

const getActionTypeTag = (type) => {
  const tags = {
    'MANUAL_ON': 'success',
    'MANUAL_OFF': 'danger',
    'AUTO_OFF': 'warning',
    'POSTPONE': 'info'
  }
  return tags[type] || ''
}

const getTypeColor = (type) => {
  const colors = {
    'MANUAL_ON': '#67c23a',
    'MANUAL_OFF': '#f56c6c',
    'AUTO_OFF': '#e6a23c',
    'POSTPONE': '#409eff'
  }
  return colors[type] || '#909399'
}

const getTypeIcon = (type) => {
  const icons = {
    'MANUAL_ON': Switch,
    'MANUAL_OFF': SwitchButton,
    'AUTO_OFF': VideoPause,
    'POSTPONE': Clock
  }
  return icons[type] || List
}

const formatTime = (timestamp) => {
  if (!timestamp) return '-'
  const date = new Date(timestamp * 1000)
  return date.toLocaleString('zh-CN')
}

const formatTimeShort = (date) => {
  return date.toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' })
}

// 添加传感器通知
const addNotification = (roomId, status) => {
  const statusText = status === 0 ? '无人' : '有人'
  const notification = {
    id: Date.now(),
    type: status === 0 ? 'warning' : 'success',
    icon: status === 0 ? Warning : Bell,
    title: `${roomId} 传感器状态更新`,
    desc: `教室 ${roomId} 检测到${statusText}状态`,
    time: formatTimeShort(new Date())
  }
  
  notifications.value.unshift(notification)
  
  if (notifications.value.length > 20) {
    notifications.value.pop()
  }
  
  ElNotification({
    title: notification.title,
    message: notification.desc,
    type: status === 0 ? 'warning' : 'success',
    duration: 5000,
    position: 'top-right'
  })
}

// 数据加载函数
const loadStatistics = async () => {
  try {
    const res = await logApi.getStatistics()
    const { typeCount, roomCount } = res.data
    
    stats.totalPostpone = typeCount.POSTPONE || 0
    stats.totalAutoOff = typeCount.AUTO_OFF || 0
    
    typeChartData.value = [
      { type: 'MANUAL_ON', label: '手动开灯', count: typeCount.MANUAL_ON || 0, color: '#67c23a', percentage: 0 },
      { type: 'MANUAL_OFF', label: '手动关灯', count: typeCount.MANUAL_OFF || 0, color: '#f56c6c', percentage: 0 },
      { type: 'AUTO_OFF', label: '自动关灯', count: typeCount.AUTO_OFF || 0, color: '#e6a23c', percentage: 0 },
      { type: 'POSTPONE', label: '延时等待', count: typeCount.POSTPONE || 0, color: '#409eff', percentage: 0 }
    ]
    
    const total = typeChartData.value.reduce((sum, item) => sum + item.count, 0)
    if (total > 0) {
      typeChartData.value.forEach(item => {
        item.percentage = Math.round((item.count / total) * 100)
      })
    }
    
    const roomData = Object.entries(roomCount || {}).map(([room, count]) => ({
      room,
      count
    })).sort((a, b) => b.count - a.count)
    
    const colors = ['#409eff', '#67c23a', '#e6a23c', '#f56c6c']
    roomChartData.value = roomData.map((item, index) => ({
      ...item,
      rank: index + 1,
      color: colors[index % colors.length]
    }))
  } catch (error) {
    console.error('加载统计数据失败:', error)
  }
}

const loadRoomStatus = async () => {
  try {
    const res = await lightApi.getAllStatus()
    const states = res.data || []
    stats.lightOnCount = states.filter(s => s.lightOn).length
    stats.lightOffCount = states.filter(s => !s.lightOn).length
  } catch (error) {
    console.error('加载教室状态失败:', error)
  }
}

const loadRecentActions = async () => {
  try {
    const res = await logApi.getList({ pageNum: 1, pageSize: 5 })
    recentActions.value = res.data.list || []
  } catch (error) {
    console.error('加载最近操作失败:', error)
  }
}

const loadTrendData = async () => {
  try {
    const res = await logApi.getTrend(timeRange.value)
    const rawTrend = res.data || []
    
    // 重组数据
    const grouped = {}
    rawTrend.forEach(item => {
      if (!grouped[item.hour]) {
        grouped[item.hour] = {
          hour: item.hour,
          data: { MANUAL_ON: 0, MANUAL_OFF: 0, AUTO_OFF: 0, POSTPONE: 0 },
          total: 0
        }
      }
      grouped[item.hour].data[item.type] = item.count
      grouped[item.hour].total += item.count
    })
    
    trendData.value = Object.values(grouped).reverse().slice(0, 12) // 取最近12小时
    
    // 添加模拟通知
    addMockNotifications()
  } catch (error) {
    console.error('加载趋势数据失败:', error)
  }
}

const addMockNotifications = () => {
  const types = ['info', 'success', 'warning']
  const icons = [Bell, Sunny, Warning]
  const titles = [
    'A101教室检测到无人',
    '系统自动关灯成功',
    'B202教室有人开灯',
    '新的操作记录已添加'
  ]
  const descs = [
    '将在30秒后自动关灯',
    '已为您节约0.5度电',
    '用户手动开灯，已记录',
    '点击查看操作日志'
  ]
  
  // 随机添加一些通知
  for (let i = 0; i < 3; i++) {
    const index = Math.floor(Math.random() * 4)
    notifications.value.unshift({
      type: types[index % 3],
      icon: icons[index % 3],
      title: titles[index],
      desc: descs[index],
      time: formatTimeShort(new Date())
    })
  }
  
  // 限制通知数量
  if (notifications.value.length > 10) {
    notifications.value = notifications.value.slice(0, 10)
  }
}

const refreshAll = async () => {
  loading.value = true
  try {
    await Promise.all([
      loadStatistics(),
      loadRoomStatus(),
      loadRecentActions(),
      loadTrendData()
    ])
    lastUpdateTime.value = new Date().toLocaleString('zh-CN')
  } catch (error) {
    console.error('刷新数据失败:', error)
  } finally {
    loading.value = false
  }
}

const handleTimeRangeChange = () => {
  refreshAll()
}

const goToLogs = () => {
  router.push('/logs')
}

// 生命周期
let refreshTimer = null
let notificationTimer = null

const handleSensorUpdate = (event) => {
  const { roomId, status } = event.detail
  addNotification(roomId, status)
}

onMounted(() => {
  refreshAll()
  refreshTimer = setInterval(refreshAll, 30000)
  
  // 模拟实时通知
  notificationTimer = setInterval(() => {
    if (Math.random() > 0.7) {
      addMockNotifications()
    }
  }, 60000)
  
  // 监听传感器更新事件
  window.addEventListener('sensor-update', handleSensorUpdate)
})

onUnmounted(() => {
  if (refreshTimer) clearInterval(refreshTimer)
  if (notificationTimer) clearInterval(notificationTimer)
  window.removeEventListener('sensor-update', handleSensorUpdate)
})
</script>

<style scoped>
.dashboard-container {
  padding: 20px;
}

.dashboard-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
  flex-wrap: wrap;
  gap: 16px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 16px;
}

.header-left h2 {
  margin: 0;
  color: #303133;
}

.update-time {
  color: #909399;
  font-size: 14px;
}

.header-right {
  display: flex;
  gap: 12px;
}

.stats-cards {
  display: grid;
  grid-template-columns: repeat(6, 1fr);
  gap: 20px;
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 8px;
  transition: transform 0.2s;
}

.stat-card:hover {
  transform: translateY(-4px);
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
}

.stat-icon.light-on {
  background: linear-gradient(135deg, #67c23a, #85ce61);
  color: white;
}

.stat-icon.light-off {
  background: linear-gradient(135deg, #909399, #b1b3b8);
  color: white;
}

.stat-icon.postpone {
  background: linear-gradient(135deg, #409eff, #79bbff);
  color: white;
}

.stat-icon.auto-off {
  background: linear-gradient(135deg, #e6a23c, #f0c78a);
  color: white;
}

.stat-icon.energy {
  background: linear-gradient(135deg, #10b981, #34d399);
  color: white;
}

.stat-icon.efficiency {
  background: linear-gradient(135deg, #8b5cf6, #a78bfa);
  color: white;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 28px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 13px;
  color: #909399;
  margin: 4px 0;
}

.stat-trend {
  font-size: 12px;
}

.charts-row {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 20px;
  margin-bottom: 20px;
}

.chart-card {
  border-radius: 8px;
}

.chart-card-large {
  grid-column: span 2;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 600;
}

.card-header .el-icon {
  margin-right: 6px;
}

.chart-container {
  min-height: 220px;
}

.type-chart {
  display: flex;
  flex-direction: column;
  gap: 18px;
}

.chart-item {
  position: relative;
}

.chart-item-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.chart-label {
  font-weight: 500;
  color: #303133;
  display: flex;
  align-items: center;
  gap: 6px;
}

.chart-count {
  color: #606266;
  font-weight: 500;
}

.chart-percentage {
  position: absolute;
  right: 0;
  bottom: 0;
  color: #909399;
  font-size: 12px;
}

.room-chart {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.rank-item {
  display: flex;
  align-items: center;
  gap: 16px;
}

.rank-number {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  font-weight: bold;
}

.rank-info {
  flex: 1;
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.rank-room {
  font-weight: 500;
  color: #303133;
}

.rank-count {
  color: #909399;
}

.trend-chart {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.trend-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.trend-time {
  width: 100px;
  color: #606266;
  font-size: 13px;
  flex-shrink: 0;
}

.trend-bars {
  flex: 1;
  display: flex;
  gap: 4px;
  height: 24px;
}

.trend-bar {
  border-radius: 4px;
  min-width: 2px;
  transition: width 0.3s;
}

.trend-total {
  width: 60px;
  text-align: right;
  color: #909399;
  font-size: 13px;
  flex-shrink: 0;
}

.notification-card {
  border-radius: 8px;
  margin-bottom: 20px;
}

.notification-container {
  max-height: 300px;
  overflow-y: auto;
}

.notification-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.notification-item {
  display: flex;
  gap: 12px;
  padding: 12px;
  border-radius: 8px;
  background: #f5f7fa;
  transition: background 0.2s;
}

.notification-item:hover {
  background: #ecf5ff;
}

.notification-item.info {
  border-left: 3px solid #409eff;
}

.notification-item.success {
  border-left: 3px solid #67c23a;
}

.notification-item.warning {
  border-left: 3px solid #e6a23c;
}

.notification-icon {
  width: 40px;
  height: 40px;
  border-radius: 8px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  flex-shrink: 0;
}

.notification-item.info .notification-icon {
  background: #ecf5ff;
  color: #409eff;
}

.notification-item.success .notification-icon {
  background: #f0f9eb;
  color: #67c23a;
}

.notification-item.warning .notification-icon {
  background: #fdf6ec;
  color: #e6a23c;
}

.notification-content {
  flex: 1;
}

.notification-title {
  font-weight: 500;
  color: #303133;
  margin-bottom: 4px;
}

.notification-desc {
  font-size: 13px;
  color: #606266;
  margin-bottom: 4px;
}

.notification-time {
  font-size: 12px;
  color: #909399;
}

.recent-actions-card {
  border-radius: 8px;
}

@media (max-width: 1400px) {
  .stats-cards {
    grid-template-columns: repeat(3, 1fr);
  }
}

@media (max-width: 992px) {
  .stats-cards {
    grid-template-columns: repeat(2, 1fr);
  }
  
  .charts-row {
    grid-template-columns: 1fr;
  }
  
  .chart-card-large {
    grid-column: span 1;
  }
  
  .dashboard-header {
    flex-direction: column;
    align-items: flex-start;
  }
}

@media (max-width: 576px) {
  .stats-cards {
    grid-template-columns: 1fr;
  }
}
</style>
