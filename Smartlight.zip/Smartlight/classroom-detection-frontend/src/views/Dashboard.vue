<template>
  <div class="layout-container">
    <div class="sidebar">
      <div class="sidebar-header">
        <h3>智能灯光系统</h3>
      </div>
      <el-menu
        :default-active="activeMenu"
        router
        class="sidebar-menu"
        @select="handleMenuSelect"
      >
        <el-menu-item index="/dashboard">
          <el-icon><Odometer /></el-icon>
          <span>数据统计</span>
        </el-menu-item>
        <el-menu-item index="/classrooms">
          <el-icon><OfficeBuilding /></el-icon>
          <span>教室管理</span>
        </el-menu-item>
        <el-menu-item index="/logs">
          <el-icon><Document /></el-icon>
          <span>操作日志</span>
        </el-menu-item>
      </el-menu>
    </div>
    <div class="main-content">
      <div class="header">
        <div class="header-left">
          <h2 class="page-title">{{ currentPageTitle }}</h2>
        </div>
        <div class="header-right">
          <UserGuide ref="userGuideRef" />
          <div class="user-info">
            <el-avatar :size="32" icon="UserFilled" />
            <span class="username">{{ username }}</span>
          </div>
          <el-button type="danger" text @click="handleLogout">
            <el-icon><SwitchButton /></el-icon>
            退出
          </el-button>
        </div>
      </div>
      <div class="content-body">
        <router-view />
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRouter, useRoute } from 'vue-router'
import { ElMessage } from 'element-plus'
import { Odometer, OfficeBuilding, Document, UserFilled, SwitchButton } from '@element-plus/icons-vue'
import UserGuide from '@/components/UserGuide.vue'

const router = useRouter()
const route = useRoute()
const username = ref(localStorage.getItem('username') || '')
const userGuideRef = ref(null)

const activeMenu = computed(() => route.path)

const currentPageTitle = computed(() => {
  const titles = {
    '/dashboard': '数据统计',
    '/classrooms': '教室管理',
    '/logs': '操作日志'
  }
  return titles[route.path] || '数据统计'
})

const handleMenuSelect = (index) => {
  router.push(index)
}

const handleLogout = () => {
  localStorage.removeItem('token')
  localStorage.removeItem('username')
  localStorage.removeItem('role')
  ElMessage.success('已退出登录')
  router.push('/login')
}

onMounted(() => {})
onUnmounted(() => {})
</script>

<style scoped>
.layout-container {
  display: flex;
  height: 100vh;
  background: #f5f7fa;
}

.sidebar {
  width: 240px;
  background: #ffffff;
  display: flex;
  flex-direction: column;
}

.sidebar-header {
  height: 64px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-bottom: 1px solid #ffffff;

}

.sidebar-header h3 {
  color: white;
  margin: 0;
  font-size: 18px;
  color: #303133;
}

.sidebar-menu {
  flex: 1;
  border: none;
  background: white;
}

.sidebar-menu:not(.el-menu--collapse) {
  width: 240px;
}

.main-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.header {
  height: 64px;
  background: white;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0 24px;
  box-shadow: 0 1px 4px rgba(0, 0, 0, 0.08);
}

.header-left .page-title {
  margin: 0;
  font-size: 20px;
  color: #303133;
}

.header-right {
  display: flex;
  align-items: center;
  gap: 20px;
}

.user-info {
  display: flex;
  align-items: center;
  gap: 10px;
}

.username {
  color: #303133;
  font-size: 14px;
}

.content-body {
  flex: 1;
  overflow-y: auto;
}
</style>
