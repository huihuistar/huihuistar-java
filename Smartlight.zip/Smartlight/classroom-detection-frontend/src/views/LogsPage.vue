<template>
  <div class="logs-container">
    <!-- 顶部统计卡片 -->
    <div class="stats-cards">
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon" style="background: linear-gradient(135deg, #67c23a, #85ce61); color: white;">
            <el-icon><Switch /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.manualOn }}</div>
            <div class="stat-label">手动开灯</div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon" style="background: linear-gradient(135deg, #f56c6c, #f78989); color: white;">
            <el-icon><SwitchButton /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.manualOff }}</div>
            <div class="stat-label">手动关灯</div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon" style="background: linear-gradient(135deg, #e6a23c, #f0c78a); color: white;">
            <el-icon><VideoPause /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.autoOff }}</div>
            <div class="stat-label">自动关灯</div>
          </div>
        </div>
      </el-card>
      <el-card class="stat-card" shadow="hover">
        <div class="stat-content">
          <div class="stat-icon" style="background: linear-gradient(135deg, #409eff, #79bbff); color: white;">
            <el-icon><Clock /></el-icon>
          </div>
          <div class="stat-info">
            <div class="stat-value">{{ stats.postpone }}</div>
            <div class="stat-label">延时等待</div>
          </div>
        </div>
      </el-card>
    </div>

    <!-- 筛选区域 -->
    <el-card class="filter-card" shadow="hover">
      <div class="filter-form">
        <el-form :inline="true" :model="filterForm">
          <el-form-item label="教室">
            <el-select v-model="logRoomId" placeholder="选择教室" clearable>
              <el-option 
                v-for="room in rooms" 
                :key="room" 
                :label="room" 
                :value="room" 
              />
            </el-select>
            <span class="select-current" v-if="logRoomId">当前：{{ logRoomId }}</span>
          </el-form-item>
          <el-form-item label="操作类型">
            <el-select v-model="logActionType" placeholder="选择类型" clearable>
              <el-option label="手动开灯" value="MANUAL_ON" />
              <el-option label="手动关灯" value="MANUAL_OFF" />
              <el-option label="自动关灯" value="AUTO_OFF" />
              <el-option label="延时等待" value="POSTPONE" />
            </el-select>
            <span class="select-current" v-if="logActionType">当前：{{ getActionTypeLabel(logActionType) }}</span>
          </el-form-item>
          <el-form-item label="时间范围">
            <el-date-picker
              v-model="dateRange"
              type="datetimerange"
              range-separator="至"
              start-placeholder="开始时间"
              end-placeholder="结束时间"
              :shortcuts="dateShortcuts"
            />
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="handleSearch" :loading="loading">
              <el-icon><Search /></el-icon>
              查询
            </el-button>
            <el-button @click="handleReset">
              <el-icon><RefreshLeft /></el-icon>
              重置
            </el-button>
            <el-button type="success" @click="handleExport" :disabled="!logs.length">
              <el-icon><Download /></el-icon>
              导出
            </el-button>
          </el-form-item>
        </el-form>
      </div>
    </el-card>

    <!-- 趋势图表 -->
    <el-card class="chart-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <span><el-icon><TrendCharts /></el-icon> 操作趋势</span>
          <el-radio-group v-model="trendHours" size="small" @change="loadTrendData">
            <el-radio-button :value="6">近6小时</el-radio-button>
            <el-radio-button :value="24">近24小时</el-radio-button>
            <el-radio-button :value="168">近7天</el-radio-button>
          </el-radio-group>
        </div>
      </template>
      <div class="chart-container">
        <div v-if="trendData.length" class="trend-chart">
          <div v-for="(item, index) in trendData" :key="index" class="trend-item">
            <div class="trend-time">{{ item.hour }}</div>
            <div class="trend-bars">
              <div 
                v-for="(value, type) in item.data" 
                :key="type"
                class="trend-bar"
                :style="{ 
                  width: (value / maxTrendValue * 100) + '%',
                  backgroundColor: getTypeColor(type)
                }"
                :title="getActionTypeLabel(type) + ': ' + value + '次'"
              ></div>
            </div>
            <div class="trend-total">{{ item.total }} 次</div>
          </div>
        </div>
        <el-empty v-else description="暂无趋势数据" />
      </div>
    </el-card>

    <!-- 操作记录表格 -->
    <el-card class="table-card" shadow="hover">
      <template #header>
        <div class="card-header">
          <span><el-icon><List /></el-icon> 操作记录</span>
          <div class="header-actions">
            <span class="total-info">共 {{ total }} 条记录</span>
            <el-button type="primary" link @click="loadLogs">
              <el-icon><Refresh /></el-icon>
              刷新
            </el-button>
          </div>
        </div>
      </template>
      <el-table 
        :data="logs" 
        style="width: 100%" 
        v-loading="loading"
        stripe
        :default-sort="{ prop: 'createTime', order: 'descending' }"
      >
        <el-table-column prop="id" label="ID" width="80" sortable />
        <el-table-column prop="roomId" label="教室" width="100">
          <template #default="scope">
            <el-tag type="info">{{ scope.row.roomId }}</el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="actionType" label="操作类型" width="140">
          <template #default="scope">
            <el-tag :type="getActionTypeTag(scope.row.actionType)">
              {{ getActionTypeLabel(scope.row.actionType) }}
            </el-tag>
          </template>
        </el-table-column>
        <el-table-column prop="intervalMinutes" label="延时分钟" width="120">
          <template #default="scope">
            {{ scope.row.intervalMinutes > 0 ? scope.row.intervalMinutes + ' 分钟' : '-' }}
          </template>
        </el-table-column>
        <el-table-column prop="operator" label="操作人" width="120" />
        <el-table-column prop="createTime" label="操作时间" sortable>
          <template #default="scope">
            {{ formatTime(scope.row.createTime) }}
          </template>
        </el-table-column>
      </el-table>
      <div class="pagination">
        <el-pagination
          v-model:current-page="filterForm.pageNum"
          v-model:page-size="filterForm.pageSize"
          :total="total"
          :page-sizes="[10, 20, 50, 100]"
          layout="total, sizes, prev, pager, next, jumper"
          @size-change="handleSizeChange"
          @current-change="handlePageChange"
        />
      </div>
    </el-card>
  </div>
</template>

<script setup>
import { ref, reactive, watch, onMounted, computed } from 'vue'
import { ElMessage } from 'element-plus'
import { 
  Refresh, Search, RefreshLeft, Download, 
  TrendCharts, List, Switch, SwitchButton, 
  Clock, VideoPause 
} from '@element-plus/icons-vue'
import { logApi, lightApi } from '@/api'

const logs = ref([])
const total = ref(0)
const loading = ref(false)
const trendData = ref([])
const trendHours = ref(24)
const rooms = ref([])

// 独立 ref 给 el-select 用，避免 reactive 对象属性在组件 v-model 中渲染异常
const logRoomId = ref('')
const logActionType = ref('')

const filterForm = reactive({
  roomId: '',
  actionType: '',
  pageNum: 1,
  pageSize: 20
})

// 双向同步：独立 ref ↔ filterForm（filterForm 必须在 watch 之前定义）
watch(logRoomId, (val) => { if (filterForm.roomId !== val) filterForm.roomId = val })
watch(() => filterForm.roomId, (val) => { if (logRoomId.value !== val) logRoomId.value = val })
watch(logActionType, (val) => { if (filterForm.actionType !== val) filterForm.actionType = val })
watch(() => filterForm.actionType, (val) => { if (logActionType.value !== val) logActionType.value = val })

const stats = reactive({
  manualOn: 0,
  manualOff: 0,
  autoOff: 0,
  postpone: 0,
  keepLightOn: 0
})

const dateRange = ref(null)

const dateShortcuts = [
  {
    text: '今天',
    value: () => {
      const start = new Date()
      start.setHours(0, 0, 0, 0)
      const end = new Date()
      end.setHours(23, 59, 59, 999)
      return [start, end]
    }
  },
  {
    text: '昨天',
    value: () => {
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24)
      start.setHours(0, 0, 0, 0)
      const end = new Date()
      end.setTime(end.getTime() - 3600 * 1000 * 24)
      end.setHours(23, 59, 59, 999)
      return [start, end]
    }
  },
  {
    text: '最近7天',
    value: () => {
      const end = new Date()
      end.setHours(23, 59, 59, 999)
      const start = new Date()
      start.setTime(start.getTime() - 3600 * 1000 * 24 * 7)
      start.setHours(0, 0, 0, 0)
      return [start, end]
    }
  }
]

const maxTrendValue = computed(() => {
  if (!trendData.value.length) return 1
  return Math.max(...trendData.value.map(item => item.total))
})

const getActionTypeLabel = (type) => {
  const labels = {
    'MANUAL_ON': '手动开灯',
    'MANUAL_OFF': '手动关灯',
    'AUTO_OFF': '自动关灯',
    'POSTPONE': '延时等待',
    'KEEP_LIGHT_ON': '保持照明'
  }
  return labels[type] || type
}

const getActionTypeTag = (type) => {
  const tags = {
    'MANUAL_ON': 'success',
    'MANUAL_OFF': 'danger',
    'AUTO_OFF': 'warning',
    'POSTPONE': 'info',
    'KEEP_LIGHT_ON': 'primary'
  }
  return tags[type] || ''
}

const getTypeColor = (type) => {
  const colors = {
    'MANUAL_ON': '#67c23a',
    'MANUAL_OFF': '#f56c6c',
    'AUTO_OFF': '#e6a23c',
    'POSTPONE': '#409eff',
    'KEEP_LIGHT_ON': '#9b59b6'
  }
  return colors[type] || '#909399'
}

const formatTime = (timestamp) => {
  if (!timestamp) return '-'
  const date = new Date(timestamp * 1000)
  return date.toLocaleString('zh-CN')
}

const loadLogs = async () => {
  loading.value = true
  try {
    const params = { ...filterForm }
    if (dateRange.value && dateRange.value.length === 2) {
      const start = dateRange.value[0]
      const end = dateRange.value[1]
      params.startTime = (start instanceof Date ? start.getTime() : start) / 1000
      params.endTime = (end instanceof Date ? end.getTime() : end) / 1000
    }
    const res = await logApi.getList(params)
    logs.value = res.data.list || []
    total.value = res.data.total || 0
  } catch (error) {
    console.error('加载日志失败:', error)
    ElMessage.error('加载日志失败')
  } finally {
    loading.value = false
  }
}

const loadStatistics = async () => {
  try {
    const res = await logApi.getStatistics()
    const { typeCount } = res.data
    stats.manualOn = typeCount.MANUAL_ON || 0
    stats.manualOff = typeCount.MANUAL_OFF || 0
    stats.autoOff = typeCount.AUTO_OFF || 0
    stats.postpone = typeCount.POSTPONE || 0
    stats.keepLightOn = typeCount.KEEP_LIGHT_ON || 0
  } catch (error) {
    console.error('加载统计数据失败:', error)
  }
}

const loadTrendData = async () => {
  try {
    const res = await logApi.getTrend(trendHours.value)
    const rawTrend = res.data || []
    
    const grouped = {}
    rawTrend.forEach(item => {
      if (!grouped[item.hour]) {
        grouped[item.hour] = {
          hour: item.hour,
          data: { MANUAL_ON: 0, MANUAL_OFF: 0, AUTO_OFF: 0, POSTPONE: 0, KEEP_LIGHT_ON: 0 },
          total: 0
        }
      }
      grouped[item.hour].data[item.type] = item.count
      grouped[item.hour].total += item.count
    })
    
    trendData.value = Object.values(grouped).reverse().slice(0, 12)
  } catch (error) {
    console.error('加载趋势数据失败:', error)
  }
}

const handleSearch = () => {
  filterForm.pageNum = 1
  loadLogs()
}

// 翻页：保留当前页码，直接加载
const handlePageChange = () => {
  loadLogs()
}

// 改变每页条数：重置到第1页
const handleSizeChange = () => {
  filterForm.pageNum = 1
  loadLogs()
}

const handleReset = () => {
  filterForm.roomId = ''
  filterForm.actionType = ''
  logRoomId.value = ''
  logActionType.value = ''
  filterForm.pageNum = 1
  dateRange.value = null
  handleSearch()
}

const handleExport = () => {
  if (!logs.value.length) {
    ElMessage.warning('没有可导出的数据')
    return
  }
  
  try {
    const headers = ['ID', '教室', '操作类型', '延时分钟', '操作人', '操作时间']
    const csvContent = [
      headers.join(','),
      ...logs.value.map(item => [
        item.id,
        item.roomId,
        getActionTypeLabel(item.actionType),
        item.intervalMinutes > 0 ? item.intervalMinutes + ' 分钟' : '-',
        item.operator,
        formatTime(item.createTime)
      ].join(','))
    ].join('\n')
    
    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const link = document.createElement('a')
    link.href = url
    link.download = `教室操作记录_${new Date().toLocaleDateString()}.csv`
    link.click()
    URL.revokeObjectURL(url)
    
    ElMessage.success('导出成功')
  } catch (error) {
    console.error('导出失败:', error)
    ElMessage.error('导出失败')
  }
}

const loadRooms = async () => {
  try {
    const res = await lightApi.getAllStatus()
    if (res.data && Array.isArray(res.data) && res.data.length > 0) {
      rooms.value = res.data.map(item => item.roomId)
      return
    }
  } catch (error) {
    console.error('加载教室列表失败:', error)
  }
  // API 失败或无数据时，用默认列表兜底
  rooms.value = ['A101', 'A102', 'B201', 'B202']
}

onMounted(() => {
  loadRooms()
  loadLogs()
  loadStatistics()
  loadTrendData()
})
</script>

<style scoped>
.logs-container {
  padding: 20px;
}

.stats-cards {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 20px;
  margin-bottom: 20px;
}

.stat-card {
  border-radius: 8px;
}

.stat-content {
  display: flex;
  align-items: center;
  gap: 16px;
}

.stat-icon {
  width: 56px;
  height: 56px;
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 28px;
}

.stat-info {
  flex: 1;
}

.stat-value {
  font-size: 28px;
  font-weight: bold;
  color: #303133;
  line-height: 1.2;
}

.stat-label {
  font-size: 14px;
  color: #909399;
}

.filter-card {
  margin-bottom: 20px;
  border-radius: 8px;
}

.select-current {
  margin-left: 8px;
  font-size: 13px;
  color: #409eff;
  font-weight: 500;
}

.chart-card {
  margin-bottom: 20px;
  border-radius: 8px;
}

.table-card {
  border-radius: 8px;
}

.card-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  font-weight: 600;
}

.card-header .el-icon {
  margin-right: 6px;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 16px;
}

.total-info {
  color: #909399;
  font-size: 14px;
}

.pagination {
  margin-top: 20px;
  display: flex;
  justify-content: flex-end;
}

.chart-container {
  min-height: 200px;
}

.trend-chart {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.trend-item {
  display: flex;
  align-items: center;
  gap: 12px;
}

.trend-time {
  width: 120px;
  color: #606266;
  font-size: 13px;
  flex-shrink: 0;
}

.trend-bars {
  flex: 1;
  display: flex;
  gap: 4px;
  height: 24px;
}

.trend-bar {
  border-radius: 4px;
  min-width: 2px;
  transition: width 0.3s;
}

.trend-total {
  width: 60px;
  text-align: right;
  color: #909399;
  font-size: 13px;
  flex-shrink: 0;
}

@media (max-width: 1200px) {
  .stats-cards {
    grid-template-columns: repeat(2, 1fr);
  }
}

@media (max-width: 768px) {
  .stats-cards {
    grid-template-columns: 1fr;
  }
}
</style>
