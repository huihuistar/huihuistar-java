import { createRouter, createWebHistory } from 'vue-router'
import Login from '@/views/Login.vue'
import Dashboard from '@/views/Dashboard.vue'
import DashboardPage from '@/views/DashboardPage.vue'
import ClassroomsPage from '@/views/ClassroomsPage.vue'
import LogsPage from '@/views/LogsPage.vue'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/',
    name: 'Layout',
    component: Dashboard,
    meta: { requiresAuth: true },
    redirect: '/dashboard',
    children: [
      {
        path: 'dashboard',
        name: 'DashboardPage',
        component: DashboardPage,
        meta: { requiresAuth: true }
      },
      {
        path: 'classrooms',
        name: 'ClassroomsPage',
        component: ClassroomsPage,
        meta: { requiresAuth: true }
      },
      {
        path: 'logs',
        name: 'LogsPage',
        component: LogsPage,
        meta: { requiresAuth: true }
      }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token')
  
  if (to.meta.requiresAuth && !token) {
    next('/login')
  } else if (to.path === '/login' && token) {
    next('/')
  } else {
    next()
  }
})

export default router
