import request from '@/utils/request'

export const authApi = {
    login(data) {
        return request({
            url: '/auth/login',
            method: 'post',
            data
        })
    },
    logout() {
        return request({
            url: '/auth/logout',
            method: 'post'
        })
    }
}

export const sensorApi = {
    report(data) {
        return request({
            url: '/sensor/report',
            method: 'post',
            data
        })
    }
}

export const lightApi = {
    postpone(data) {
        return request({
            url: '/light/postpone',
            method: 'post',
            data
        })
    },
    checkStatus(data) {
        return request({
            url: '/light/check-status',
            method: 'post',
            data
        })
    },
    autoOff(data) {
        return request({
            url: '/light/auto-off',
            method: 'post',
            data
        })
    },
    toggle(data) {
        return request({
            url: '/light/toggle',
            method: 'post',
            data
        })
    },
    getStatus(roomId) {
        return request({
            url: '/light/status',
            method: 'get',
            params: { roomId }
        })
    },
    getAllStatus() {
        return request({
            url: '/light/status-all',
            method: 'get'
        })
    },
    keepLightOn(data) {
        return request({
            url: '/light/keep-light-on',
            method: 'post',
            data
        })
    },
    createRoom(data) {
        return request({
            url: '/light/room/create',
            method: 'post',
            data
        })
    }
}

export const reminderApi = {
    snooze(data) {
        return request({
            url: '/reminder/snooze',
            method: 'post',
            data
        })
    },
    getNextPopupTime(roomId) {
        return request({
            url: '/reminder/next',
            method: 'get',
            params: { roomId }
        })
    }
}

export const logApi = {
    getList(params) {
        return request({
            url: '/log/list',
            method: 'get',
            params
        })
    },
    getStatistics() {
        return request({
            url: '/log/statistics',
            method: 'get'
        })
    },
    getTrend(hours) {
        return request({
            url: '/log/trend',
            method: 'get',
            params: { hours }
        })
    },
    getSensorRecords(params) {
        return request({
            url: '/log/sensor',
            method: 'get',
            params
        })
    }
}
