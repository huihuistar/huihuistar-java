# 教室智能感应节能管理系统 - 前端

基于 Vue3 + Vite + Element Plus 开发的教室智能感应节能管理系统前端。

## 技术栈

- Vue 3 (Composition API + `<script setup>`)
- Vite
- Vue Router
- Element Plus
- Axios

## 项目结构

```
classroom-detection-frontend/
├── index.html                  # HTML入口文件
├── package.json              # 依赖配置
├── vite.config.js          # Vite构建配置
├── .gitignore              # Git忽略规则
├── README.md               # 项目说明
├── 前端操作文档.md            # 详细使用文档
└── src/
    ├── main.js             # 应用入口
    ├── App.vue             # 根组件
    ├── api/
    │   └── index.js        # API接口封装
    ├── utils/
    │   └── request.js    # HTTP请求工具
    ├── router/
    │   └── index.js        # 路由配置
    ├── views/
    │   ├── Login.vue      # 登录页面
    │   ├── Dashboard.vue     # 主布局
    │   ├── DashboardPage.vue  # 数据统计页面
    │   ├── ClassroomsPage.vue # 教室管理页面
    │   └── LogsPage.vue      # 操作日志页面
    └── components/
        ├── PostponePopup.vue # 延时等待弹窗
        └── UserGuide.vue  # 用户帮助组件
```

## 安装依赖

```bash
npm install
```

## 开发运行

```bash
npm run dev
```

默认访问地址：http://localhost:3000

## 生产构建

```bash
npm run build
```

## 默认账号

- 用户名：admin
- 密码：admin123

## 功能说明

### 1. 登录页面
- 用户身份验证
- JWT Token 管理

### 2. 数据统计页面 (增强版)
- 顶部操作栏：刷新数据、时间范围选择
- 统计卡片：开灯教室数、关灯教室数、延时等待次数、自动关灯次数、预计节能、节能效率
- 操作类型分布：展示手动开灯、手动关灯、自动关灯、延时等待的比例
- 教室操作排行：显示各教室的操作次数排行
- 操作趋势图：可视化展示近6/24/168小时的操作趋势
- 实时通知：显示系统状态变化通知
- 最近操作记录：查看最新的5条操作记录
- 自动刷新：每30秒自动更新数据

### 3. 教室管理页面 (增强版)
- 顶部统计：开灯教室、关灯教室、模拟中数量
- 教室状态卡片：显示教室ID、灯状态、弹窗状态、下次检查时间、最后更新时间
- 批量操作：支持批量开灯/关灯
- 查看详情：查看教室详细信息
- 查看历史：查看教室操作和传感器记录
- **新增教室**：支持添加新教室，包含教室名称、容量、设备配置等字段
- 手动开关灯：点击按钮即可开关对应教室的灯
- 刷新状态：点击刷新按钮获取教室最新状态
- 硬件模拟：模拟红外传感器上报数据
  - 选择教室：选择要模拟传感器的教室
  - 传感器状态：选择有人/无人状态
  - 上报间隔：可选择15秒/30秒/1分钟/5分钟/10分钟
  - 启动模拟：开始定时上报传感器数据
  - 停止模拟：停止定时上报
  - 立即上报：手动触发一次数据上报
  - 统计信息：显示下次上报时间和已上报次数
  - **可视化倒计时**：显示下次上报的剩余时间，支持颜色变化提醒

### 4. 操作日志页面 (增强版)
- 操作统计卡片：手动开灯、手动关灯、自动关灯、延时等待次数统计
- 多条件筛选：按教室、操作类型、时间范围（支持快捷时间）
- 操作趋势图：可视化展示近6/24/168小时的操作趋势
- 操作记录列表：显示所有操作记录
- 数据导出：支持导出为CSV文件
- 分页显示：支持翻页查看更多记录
- 数据排序：支持按ID和操作时间排序
- 刷新数据：点击刷新按钮获取最新数据

### 5. 教室无人通知弹窗
- **三种操作按钮**：
  - 不关灯：维持当前照明状态，继续监测占用状态
  - 延迟等待：设置延时时间，暂停自动照明控制序列
  - 关灯：立即执行手动关灯操作
- 30秒倒计时：超时后自动关灯，颜色随时间变化提醒
- 快速选项：5分钟、10分钟、20分钟、30分钟
- 自定义时间：输入1-120分钟任意分钟数
- 加载状态：所有按钮在通信期间显示加载状态
- 错误处理：操作失败显示提示并恢复倒计时
- 所有操作记录到系统日志供审计

### 6. 用户帮助
- 快速开始指南
- 详细功能说明
- 常见问题解答

## 后端接口

### 认证接口
- POST `/api/auth/login` - 用户登录
- POST `/api/auth/logout` - 用户登出

### 传感器接口
- POST `/api/sensor/report` - 上报传感器数据

### 灯光控制接口
- POST `/api/light/toggle` - 手动开关灯
- POST `/api/light/postpone` - 延时等待
- POST `/api/light/check-status` - 检查状态
- POST `/api/light/auto-off` - 自动关灯
- GET `/api/light/status` - 获取教室状态
- GET `/api/light/status-all` - 获取所有教室状态 (新增)

### 日志接口 (增强)
- GET `/api/log/list` - 获取操作记录列表（支持时间范围筛选）
- GET `/api/log/statistics` - 获取统计数据
- GET `/api/log/trend` - 获取操作趋势数据 (新增)
- GET `/api/log/sensor` - 获取传感器记录 (新增)

## 配置说明

### 后端地址配置

如果后端服务不在 `localhost:8080`，需要修改代理配置：

1. 打开 `vite.config.js`
2. 修改 `proxy.target` 为实际的后端地址
3. 重启前端服务

```javascript
proxy: {
  '/api': {
    target: 'http://localhost:8080',  // 修改这里
    changeOrigin: true
  }
}
```

### 硬件模拟配置

修改硬件模拟的上报间隔：

1. 打开 `src/views/ClassroomsPage.vue`
2. 使用页面上的下拉框选择上报间隔即可

### 教室配置

教室列表在 `src/views/ClassroomsPage.vue` 中定义：

```javascript
const rooms = ref([
  { id: 'A101', lightOn: true, popupActive: false, nextCheckAt: null, postponeMinutes: 0, lastUpdate: null },
  { id: 'A102', lightOn: true, popupActive: false, nextCheckAt: null, postponeMinutes: 0, lastUpdate: null },
  { id: 'B201', lightOn: true, popupActive: false, nextCheckAt: null, postponeMinutes: 0, lastUpdate: null },
  { id: 'B202', lightOn: true, popupActive: false, nextCheckAt: null, postponeMinutes: 0, lastUpdate: null }
])
```

如需添加更多教室，在数组中添加新对象即可。

## 响应式设计

系统支持多种屏幕尺寸：
- 大屏幕：完整功能展示
- 中等屏幕：自动调整布局
- 小屏幕：垂直排列组件

## 注意事项

- 后端服务需在 http://localhost:8080 运行
- 如需修改后端地址，可调整 vite.config.js 中的代理配置
- 硬件模拟的上报间隔可在页面上选择，测试时可调整为15秒便于测试
- 弹窗只在8:00-22:00期间显示
- 导出功能会添加UTF-8编码的CSV文件，可用Excel打开
- 数据统计页面有实时通知功能，每30秒自动刷新
