/**
 * 智能教室灯光控制 - ESP32 主程序
 *
 * 引脚定义：
 *   PIR 传感器  → GPIO 4
 *   LED 灯      → GPIO 3
 *   按钮        → GPIO 7
 *   BH1750 SDA  → GPIO 8
 *   BH1750 SCL  → GPIO 9
 *
 * 工作流程：
 *   1. 每隔 REPORT_INTERVAL_MS 向后端上报一次 PIR + 灯状态
 *   2. 后端返回 needPopup=true 时，ESP32 进入"等待关灯"状态，开始本地倒计时
 *   3. 倒计时结束前：
 *      - 按钮按下 → 调用 /api/light/toggle 手动切换灯状态，退出等待
 *      - 倒计时归零 → 调用 /api/light/auto-off 自动关灯
 *   4. 关灯后用光感验证：lux < LUX_OFF_THRESHOLD → 关灯成功；否则重试一次
 *   5. 后端 lightOn 字段始终以后端状态为准，ESP32 同步执行
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include <Wire.h>
#include <BH1750.h>

// ─────────────────────────────────────────────
//  配置区（按实际情况修改）
// ─────────────────────────────────────────────
const char* WIFI_SSID     = "北风吹走了小猪的烦恼";
const char* WIFI_PASSWORD = "zjj12345";

const char* SERVER_HOST   = "172.20.10.9";
const int   SERVER_PORT   = 8080;

const char* ROOM_ID       = "A101";   // 本设备对应的教室 ID
const char* DEVICE_ID     = "IR-A101"; // 设备编号

// 上报间隔（毫秒）
const unsigned long REPORT_INTERVAL_MS = 5000;

// 弹窗等待超时（毫秒）：后端弹窗 30s 无人应答则自动关灯
const unsigned long POPUP_TIMEOUT_MS = 30000;

// 光感阈值：低于此值认为灯已关（单位 lux）
const float LUX_OFF_THRESHOLD = 10.0;

// ─────────────────────────────────────────────
//  引脚定义
// ─────────────────────────────────────────────
#define PIN_PIR    4
#define PIN_LED    3
#define PIN_BUTTON 7
#define PIN_SDA    8
#define PIN_SCL    9

// ─────────────────────────────────────────────
//  全局状态
// ─────────────────────────────────────────────
BH1750 lightMeter;

bool     ledState        = false;   // 当前 LED 实际状态
bool     lastButtonState = HIGH;    // 上一次按钮读值（INPUT_PULLUP，松开=HIGH）
bool     inPopupWait     = false;   // 是否处于弹窗等待倒计时中
unsigned long popupStartMs = 0;     // 弹窗开始的本地时间戳

unsigned long lastReportMs = 0;     // 上次上报时间

// ─────────────────────────────────────────────
//  工具函数
// ─────────────────────────────────────────────

/** 控制 LED 并打印日志 */
void setLed(bool on) {
  ledState = on;
  digitalWrite(PIN_LED, on ? HIGH : LOW);
  Serial.println(on ? "[LED] 开灯" : "[LED] 关灯");
}

/** 用光感验证关灯是否成功，最多重试一次 */
void verifyLightOff() {
  delay(500); // 等灯稳定
  float lux = lightMeter.readLightLevel();
  Serial.print("[光感验证] lux = ");
  Serial.println(lux);
  if (lux < LUX_OFF_THRESHOLD) {
    Serial.println("[光感验证] 关灯成功 ✓");
  } else {
    Serial.println("[光感验证] 关灯未成功，重试关灯...");
    setLed(false);
    delay(500);
    lux = lightMeter.readLightLevel();
    Serial.print("[光感验证] 重试后 lux = ");
    Serial.println(lux);
    if (lux < LUX_OFF_THRESHOLD) {
      Serial.println("[光感验证] 重试关灯成功 ✓");
    } else {
      Serial.println("[光感验证] ⚠ 关灯仍未成功，可能硬件问题");
    }
  }
}

// ─────────────────────────────────────────────
//  HTTP 请求封装
// ─────────────────────────────────────────────

/**
 * 发送 POST 请求，body 为 JSON 字符串
 * 返回响应 body 字符串，失败返回空字符串
 */
String httpPost(const char* path, const String& body) {
  if (WiFi.status() != WL_CONNECTED) {
    Serial.println("[HTTP] WiFi 未连接，跳过请求");
    return "";
  }

  HTTPClient http;
  String url = String("http://") + SERVER_HOST + ":" + SERVER_PORT + path;
  http.begin(url);
  http.addHeader("Content-Type", "application/json");
  http.setTimeout(5000); // 5s 超时

  int code = http.POST(body);
  String resp = "";
  if (code > 0) {
    resp = http.getString();
    Serial.print("[HTTP] POST ");
    Serial.print(path);
    Serial.print(" → ");
    Serial.println(code);
  } else {
    Serial.print("[HTTP] 请求失败: ");
    Serial.println(http.errorToString(code));
  }
  http.end();
  return resp;
}

// ─────────────────────────────────────────────
//  核心业务：上报传感器数据
// ─────────────────────────────────────────────

/**
 * 上报一次传感器数据，解析后端响应并执行对应动作
 */
void reportSensor() {
  int pirValue = digitalRead(PIN_PIR);
  int statusVal = (pirValue == HIGH) ? 1 : 0; // 1=有人 0=无人

  // 构造 JSON（不传 reportTime，后端自动用服务器时间）
  StaticJsonDocument<256> doc;
  doc["deviceId"] = DEVICE_ID;
  doc["roomId"]   = ROOM_ID;
  doc["status"]   = statusVal;
  doc["lightOn"]  = ledState ? 1 : 0;

  String body;
  serializeJson(doc, body);

  Serial.print("[上报] PIR=");
  Serial.print(statusVal);
  Serial.print(" lightOn=");
  Serial.println(ledState ? 1 : 0);

  String resp = httpPost("/api/sensor/report", body);
  if (resp.isEmpty()) return;

  // 解析响应
  StaticJsonDocument<512> respDoc;
  DeserializationError err = deserializeJson(respDoc, resp);
  if (err) {
    Serial.print("[解析] JSON 解析失败: ");
    Serial.println(err.c_str());
    return;
  }

  // 后端统一返回格式: { "code": 200, "data": { ... } }
  if (respDoc["code"] != 200) {
    Serial.print("[响应] 后端返回错误: ");
    Serial.println(resp);
    return;
  }

  JsonObject data = respDoc["data"];

  // 1. 同步灯状态（以后端为准）
  bool backendLightOn = data["lightOn"].as<bool>();
  if (backendLightOn != ledState) {
    Serial.print("[同步] 后端灯状态与本地不一致，同步为: ");
    Serial.println(backendLightOn ? "开" : "关");
    setLed(backendLightOn);
    // 同步关灯不做光感验证，光感验证只用于自动关灯
  }

  // 2. 处理弹窗指令
  bool needPopup = data["needPopup"].as<bool>();
  if (needPopup && !inPopupWait) {
    Serial.println("[弹窗] 后端触发关灯询问，开始 30s 倒计时...");
    inPopupWait  = true;
    popupStartMs = millis();
  }

  // 3. 后端主动取消弹窗（有人进来了 / 前端已处理）
  if (inPopupWait && !data["popupActive"].as<bool>()) {
    Serial.println("[弹窗] 后端取消弹窗，退出等待");
    inPopupWait = false;
  }
}

// ─────────────────────────────────────────────
//  核心业务：自动关灯（弹窗超时）
// ─────────────────────────────────────────────

void doAutoOff() {
  Serial.println("[自动关灯] 30s 超时，调用 /api/light/auto-off");

  StaticJsonDocument<128> doc;
  doc["roomId"] = ROOM_ID;
  String body;
  serializeJson(doc, body);

  String resp = httpPost("/api/light/auto-off", body);
  if (!resp.isEmpty()) {
    Serial.println("[自动关灯] 后端已确认");
  }

  setLed(false);
  verifyLightOff();  // 只有自动关灯才做光感验证
  inPopupWait = false;
}

// ─────────────────────────────────────────────
//  核心业务：按钮手动切换灯
// ─────────────────────────────────────────────

void doToggle() {
  // 如果正在弹窗倒计时中，按钮按下的意图是关灯，用 auto-off 语义更明确
  if (inPopupWait) {
    Serial.println("[按钮] 弹窗等待中按按钮 → 视为关灯，调用 /api/light/auto-off");
    doAutoOff();
    return;
  }

  Serial.println("[按钮] 手动切换灯，调用 /api/light/toggle");

  StaticJsonDocument<128> doc;
  doc["roomId"] = ROOM_ID;
  String body;
  serializeJson(doc, body);

  String resp = httpPost("/api/light/toggle", body);
  if (resp.isEmpty()) {
    // 网络失败时本地也切换，保证物理响应
    setLed(!ledState);
    return;
  }

  // 解析后端返回的最终灯状态
  StaticJsonDocument<256> respDoc;
  DeserializationError err = deserializeJson(respDoc, resp);
  if (!err && respDoc["code"] == 200) {
    bool newLightOn = respDoc["data"]["lightOn"].as<bool>();
    setLed(newLightOn);
    // 手动切换不做光感验证，光感验证只用于自动关灯
    Serial.print("[按钮] 切换后灯状态: ");
    Serial.println(newLightOn ? "开" : "关");
  } else {
    // 解析失败，本地切换兜底
    setLed(!ledState);
  }
}

// ─────────────────────────────────────────────
//  setup / loop
// ─────────────────────────────────────────────

void setup() {
  Serial.begin(115200);
  delay(500);
  Serial.println("\n===== 智能教室灯光控制启动 =====");

  // 引脚初始化
  pinMode(PIN_PIR,    INPUT);
  pinMode(PIN_LED,    OUTPUT);
  pinMode(PIN_BUTTON, INPUT_PULLUP);
  digitalWrite(PIN_LED, LOW);

  // BH1750 初始化
  Wire.begin(PIN_SDA, PIN_SCL);
  if (lightMeter.begin(BH1750::CONTINUOUS_HIGH_RES_MODE)) {
    Serial.println("[BH1750] 初始化成功");
  } else {
    Serial.println("[BH1750] 初始化失败，光感验证将不可用");
  }

  // WiFi 连接
  Serial.print("[WiFi] 连接中: ");
  Serial.println(WIFI_SSID);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  int retry = 0;
  while (WiFi.status() != WL_CONNECTED && retry < 30) {
    delay(500);
    Serial.print(".");
    retry++;
  }
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println();
    Serial.print("[WiFi] 已连接，IP: ");
    Serial.println(WiFi.localIP());
  } else {
    Serial.println("\n[WiFi] 连接失败，将在离线模式下运行");
  }

  Serial.println("===== 初始化完成 =====\n");
}

void loop() {
  unsigned long now = millis();

  // ── 1. 按钮检测（边沿触发，消抖） ──────────────────
  bool nowButton = digitalRead(PIN_BUTTON);
  if (lastButtonState == HIGH && nowButton == LOW) {
    delay(20); // 消抖
    if (digitalRead(PIN_BUTTON) == LOW) {
      doToggle();
    }
  }
  lastButtonState = nowButton;

  // ── 2. 弹窗倒计时检测 ──────────────────────────────
  if (inPopupWait) {
    unsigned long elapsed = now - popupStartMs;
    // 超时 → 自动关灯
    if (elapsed >= POPUP_TIMEOUT_MS) {
      doAutoOff();
    }
  }

  // ── 3. 定时上报传感器数据 ───────────────────────────
  if (now - lastReportMs >= REPORT_INTERVAL_MS) {
    lastReportMs = now;
    reportSensor();
  }
}
