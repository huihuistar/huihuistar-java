package com.example.backend.entity;

import lombok.Data;
import javax.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * 商品实体类 - 对应MySQL的product表
 * 
 * 字段说明：
 * - id: 商品ID，主键自增
 * - name: 商品名称
 * - description: 商品描述
 * - price: 价格
 * - stock: 库存数量
 * - category: 分类
 * - brand: 品牌
 * - status: 状态（1-上架，0-下架）
 * - createdAt: 创建时间
 * - updatedAt: 更新时间
 */
@Data
@Entity
@Table(name = "product")
public class Product {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "name", nullable = false, length = 200)
    private String name;
    
    @Column(name = "description", columnDefinition = "TEXT")
    private String description;
    
    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;
    
    @Column(name = "stock", nullable = false)
    private Integer stock;
    
    @Column(name = "category", length = 50)
    private String category;
    
    @Column(name = "brand", length = 50)
    private String brand;
    
    @Column(name = "status", nullable = false)
    private Integer status = 1;
    
    @Column(name = "created_at")
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
