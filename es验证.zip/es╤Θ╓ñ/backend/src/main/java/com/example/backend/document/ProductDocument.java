package com.example.backend.document;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.annotations.Field;
import org.springframework.data.elasticsearch.annotations.FieldType;

import java.math.BigDecimal;

/**
 * 商品ES文档 - 存储在Elasticsearch中
 * 
 * 这是ETL处理后的数据结构，包含：
 * - 原始字段（从MySQL同步）
 * - ETL补全字段（priceRange, stockStatus, hotScore等）
 * 
 * 使用IK分词器：
 * - ik_max_word: 细粒度分词，用于存储时建立更多索引
 * - ik_smart: 智能分词，用于搜索时提高精确度
 */
@Data
@Document(indexName = "products")
public class ProductDocument {
    
    @Id
    private Long id;
    
    // 商品名称 - 使用IK分词器
    @Field(type = FieldType.Text, analyzer = "ik_max_word", searchAnalyzer = "ik_smart")
    private String name;
    
    // 商品描述 - 使用IK分词器
    @Field(type = FieldType.Text, analyzer = "ik_max_word", searchAnalyzer = "ik_smart")
    private String description;
    
    // 价格 - 使用scaled_float精确存储
    @Field(type = FieldType.Scaled_Float, scalingFactor = 100)
    private BigDecimal price;
    
    // 库存
    @Field(type = FieldType.Integer)
    private Integer stock;
    
    // 分类 - keyword用于精确过滤
    @Field(type = FieldType.Keyword)
    private String category;
    
    // 品牌
    @Field(type = FieldType.Keyword)
    private String brand;
    
    // 状态
    @Field(type = FieldType.Integer)
    private Integer status;
    
    // ========== ETL补全字段 ==========
    
    // 价格区间 - ETL根据price计算
    @Field(type = FieldType.Keyword)
    private String priceRange;
    
    // 库存状态 - ETL根据stock计算
    @Field(type = FieldType.Keyword)
    private String stockStatus;
    
    // 热度评分 - ETL计算（价格*权重 + 库存*权重）
    @Field(type = FieldType.Double)
    private Double hotScore;
    
    // 状态文本
    @Field(type = FieldType.Keyword)
    private String statusText;
}
