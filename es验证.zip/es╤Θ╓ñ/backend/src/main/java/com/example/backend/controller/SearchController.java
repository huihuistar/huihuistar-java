package com.example.backend.controller;

import com.example.backend.document.ProductDocument;
import com.example.backend.service.SearchService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 搜索Controller
 * 
 * 提供搜索API：
 * GET /api/search?keyword=xxx     - 全文搜索商品
 * GET /api/search/all             - 查询ES中所有商品
 * GET /api/search/count           - 查询ES文档数量
 * 
 * 搜索使用IK分词器，支持中文分词
 */
@RestController
@RequestMapping("/api/search")
@RequiredArgsConstructor
@CrossOrigin(origins = "*")
public class SearchController {
    
    private final SearchService searchService;
    
    /**
     * 全文搜索商品
     * 使用IK分词器对keyword进行分词后搜索
     * 
     * 示例：
     * /api/search?keyword=苹果手机
     * 会分词为：苹果、手机、苹果手机，然后搜索
     */
    @GetMapping
    public ResponseEntity<List<ProductDocument>> search(@RequestParam String keyword) {
        List<ProductDocument> results = searchService.search(keyword);
        return ResponseEntity.ok(results);
    }
    
    /**
     * 查询ES中所有商品
     */
    @GetMapping("/all")
    public ResponseEntity<Iterable<ProductDocument>> getAll() {
        return ResponseEntity.ok(searchService.findAll());
    }
    
    /**
     * 查询ES文档数量
     * 用于验证数据同步是否正常
     */
    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> count() {
        long count = searchService.count();
        Map<String, Long> result = new HashMap<>();
        result.put("count", count);
        return ResponseEntity.ok(result);
    }
    
    /**
     * 根据ID查询ES中的商品
     */
    @GetMapping("/{id}")
    public ResponseEntity<ProductDocument> getById(@PathVariable Long id) {
        return searchService.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }
}
