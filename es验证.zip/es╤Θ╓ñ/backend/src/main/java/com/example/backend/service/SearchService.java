package com.example.backend.service;

import com.example.backend.document.ProductDocument;
import com.example.backend.repository.ProductSearchRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.data.elasticsearch.core.SearchHits;
import org.springframework.data.elasticsearch.core.query.Criteria;
import org.springframework.data.elasticsearch.core.query.CriteriaQuery;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * 搜索服务层
 * 
 * 封装ES搜索逻辑：
 * - 全文搜索（使用IK分词）
 * - 多字段搜索
 * - 查询所有/根据ID查询
 */
@Service
@RequiredArgsConstructor
public class SearchService {
    
    private final ProductSearchRepository productSearchRepository;
    private final ElasticsearchOperations elasticsearchOperations;
    
    /**
     * 全文搜索
     * 在name和description字段中搜索
     * 使用IK分词器自动分词
     */
    public List<ProductDocument> search(String keyword) {
        // 使用CriteriaQuery构建多字段搜索
        Criteria criteria = new Criteria("name").contains(keyword)
                .or(new Criteria("description").contains(keyword));
        
        CriteriaQuery query = new CriteriaQuery(criteria);
        SearchHits<ProductDocument> searchHits = elasticsearchOperations.search(query, ProductDocument.class);
        
        return searchHits.getSearchHits().stream()
                .map(hit -> hit.getContent())
                .collect(Collectors.toList());
    }
    
    /**
     * 查询所有
     */
    public Iterable<ProductDocument> findAll() {
        return productSearchRepository.findAll();
    }
    
    /**
     * 根据ID查询
     */
    public Optional<ProductDocument> findById(Long id) {
        return productSearchRepository.findById(id);
    }
    
    /**
     * 统计数量
     */
    public long count() {
        return productSearchRepository.count();
    }
    
    /**
     * 保存到ES（供canal-client调用）
     */
    public void saveToES(ProductDocument document) {
        productSearchRepository.save(document);
    }
    
    /**
     * 从ES删除（供canal-client调用）
     */
    public void deleteFromES(Long id) {
        productSearchRepository.deleteById(id);
    }
}
