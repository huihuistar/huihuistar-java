package com.example.backend.service;

import com.example.backend.entity.Product;
import com.example.backend.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/**
 * 商品服务层
 * 
 * 处理商品业务逻辑：
 * - 保存商品到MySQL
 * - 查询商品列表
 * - 更新和删除商品
 * 
 * 注意：这里只操作MySQL，ES的同步由canal-client模块处理
 */
@Service
@RequiredArgsConstructor
public class ProductService {
    
    private final ProductRepository productRepository;
    
    /**
     * 保存商品
     * 新增或更新都会触发MySQL的binlog变化
     */
    @Transactional
    public Product save(Product product) {
        return productRepository.save(product);
    }
    
    /**
     * 查询所有商品
     */
    public List<Product> findAll() {
        return productRepository.findAll();
    }
    
    /**
     * 根据ID查询
     */
    public Optional<Product> findById(Long id) {
        return productRepository.findById(id);
    }
    
    /**
     * 删除商品
     * 删除也会触发binlog变化
     */
    @Transactional
    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }
}
