package com.example.backend.repository;

import com.example.backend.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * 商品数据访问层
 * 
 * 继承JpaRepository，自动获得CRUD方法：
 * - save() - 保存/更新
 * - findById() - 根据ID查询
 * - findAll() - 查询所有
 * - deleteById() - 根据ID删除
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
}
