package com.example.backend.repository;

import com.example.backend.document.ProductDocument;
import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * 商品ES搜索Repository
 * 
 * 继承ElasticsearchRepository，自动获得搜索方法
 * Spring Data ES会根据方法名自动生成查询
 */
@Repository
public interface ProductSearchRepository extends ElasticsearchRepository<ProductDocument, Long> {
    
    /**
     * 根据名称搜索（使用IK分词）
     */
    List<ProductDocument> findByNameContaining(String name);
    
    /**
     * 根据分类搜索
     */
    List<ProductDocument> findByCategory(String category);
    
    /**
     * 根据品牌搜索
     */
    List<ProductDocument> findByBrand(String brand);
}
