package com.example.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 后端API服务启动类
 * 
 * 功能：
 * 1. 提供商品增删改查REST API
 * 2. 提供商品搜索接口（基于Elasticsearch）
 * 3. 接收前端请求操作MySQL
 */
@SpringBootApplication
public class BackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
        System.out.println("========================================");
        System.out.println("后端API服务已启动");
        System.out.println("访问地址: http://localhost:8080");
        System.out.println("========================================");
    }
}
