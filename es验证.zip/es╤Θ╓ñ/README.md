# 数据管道项目说明

## 项目架构

```
前端 (Vue, 3000端口)
    ↓  HTTP 请求
后端 (Spring Boot, 8080端口)  ←——→  MySQL (3306端口)
                                        ↓  binlog
                                   Canal Server (11111端口)
                                        ↓  消息推送
                                   RabbitMQ (5672端口)
                                        ↓  消息消费
                              canal-client (Spring Boot, 8081端口)
                                        ↓  写入
                              Elasticsearch (9200端口)
                                        ↑  查询
后端 (Spring Boot, 8080端口) ————————————
```

---

## 一、数据写入链路（新增商品 → MySQL → ES）

### 完整调用链

```
POST /api/products
    → ProductController.createProduct()
    → ProductService.save()
    → ProductRepository.save()          ← JPA 写入 MySQL
         ↓ MySQL 生成 binlog
    Canal Server 监听 binlog
         ↓ 推送消息到 RabbitMQ
    canal.exchange (fanout) → canal.queue
         ↓
    CanalMessageConsumer.handleCanalMessage()
    → CanalMessageConsumer.handleInsert()
    → ProductETLService.processInsert()
        → ProductETLService.transform()   ← ETL 数据转换
    → ElasticsearchService.indexDocument()  ← 写入 ES
```

---

### 详细步骤说明

#### 第 1 步：前端发起请求
前端调用后端接口，发送 HTTP POST 请求：
```
POST http://localhost:8080/api/products
Content-Type: application/json

{
  "name": "苹果手机15",
  "description": "苹果最新款手机",
  "price": 7999.00,
  "stock": 100,
  "category": "手机",
  "brand": "苹果",
  "status": 1
}
```

---

#### 第 2 步：ProductController 接收请求
**文件**：`backend/src/main/java/com/example/backend/controller/ProductController.java`

```java
@PostMapping
public ResponseEntity<Product> createProduct(@RequestBody Product product) {
    Product saved = productService.save(product);  // 调用 Service 层
    return ResponseEntity.ok(saved);
}
```
- 接收前端 JSON 数据，转为 `Product` 对象
- 调用 `ProductService.save(product)` 交给 Service 层处理

---

#### 第 3 步：ProductService 处理业务逻辑
**文件**：`backend/src/main/java/com/example/backend/service/ProductService.java`

```java
@Transactional
public Product save(Product product) {
    return productRepository.save(product);  // 调用 Repository 写入 MySQL
}
```
- 开启数据库事务
- 调用 `ProductRepository.save(product)` 写入 MySQL

---

#### 第 4 步：ProductRepository 写入 MySQL
**文件**：`backend/src/main/java/com/example/backend/repository/ProductRepository.java`

```java
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
}
```
- 继承 JpaRepository，自动实现 save() 方法
- JPA 底层生成 `INSERT INTO product (...)` SQL 语句
- 数据成功写入 `demo_db.product` 表
- **MySQL 自动生成 binlog（二进制日志）记录此次变更**

---

#### 第 5 步：Canal Server 捕获 binlog
**Canal 配置**：`D:\elasticsearch\canal\canal.deployer-1.1.8.tar\canal.deployer-1.1.8\conf\`

- Canal 作为 MySQL 的"假从库"，实时监听 `demo_db.product` 表的 binlog
- 捕获到 INSERT 操作后，将数据封装为 FlatMessage JSON 格式
- 消息示例：
```json
{
  "data": [{"id": "1", "name": "苹果手机15", "price": "7999.00", "stock": "100", ...}],
  "database": "demo_db",
  "table": "product",
  "type": "INSERT",
  "ts": 1776077244000
}
```

---

#### 第 6 步：Canal 推送消息到 RabbitMQ
- Canal 将消息发送到 `canal.exchange`（fanout 类型交换机）
- `canal.exchange` 广播到绑定的 `canal.queue` 队列

---

#### 第 7 步：CanalMessageConsumer 消费消息
**文件**：`canal-client/src/main/java/com/example/canal/mq/CanalMessageConsumer.java`

```java
@RabbitListener(queues = "canal.queue", containerFactory = "rabbitListenerContainerFactory")
public void handleCanalMessage(String message) {
    JSONObject jsonMessage = JSON.parseObject(message);
    String database = jsonMessage.getString("database");  // "demo_db"
    String table = jsonMessage.getString("table");        // "product"
    String type = jsonMessage.getString("type");          // "INSERT"

    // 过滤：只处理 demo_db.product 表
    if (!"demo_db".equals(database) || !"product".equals(table)) {
        return;  // 跳过其他表的变更
    }

    switch (type.toUpperCase()) {
        case "INSERT": handleInsert(jsonMessage); break;
        case "UPDATE": handleUpdate(jsonMessage); break;
        case "DELETE": handleDelete(jsonMessage); break;
    }
}

private void handleInsert(JSONObject jsonMessage) {
    jsonMessage.getJSONArray("data").forEach(item -> {
        Map<String, Object> data = ((JSONObject) item).getInnerMap();
        productETLService.processInsert(data);  // 交给 ETL 处理
    });
}
```
- 从 `canal.queue` 取出消息
- 解析 JSON，判断是哪个库/表/操作类型
- 只处理 `demo_db.product` 表，其余一律跳过
- 根据操作类型分发给对应的处理方法

---

#### 第 8 步：ProductETLService 进行 ETL 转换
**文件**：`canal-client/src/main/java/com/example/canal/etl/ProductETLService.java`

```java
public void processInsert(Map<String, Object> data) {
    Map<String, Object> transformedData = transform(data);  // ETL 转换
    Long id = Long.valueOf(data.get("id").toString());
    elasticsearchService.indexDocument("products", id, transformedData);  // 写入 ES
}

private Map<String, Object> transform(Map<String, Object> source) {
    Map<String, Object> result = new HashMap<>(source);

    BigDecimal price = new BigDecimal(source.get("price").toString());
    Integer stock = Integer.valueOf(source.get("stock").toString());

    // 补全字段 1：价格区间
    result.put("priceRange", calculatePriceRange(price));
    // 7999 → "1000+"

    // 补全字段 2：库存状态
    result.put("stockStatus", calculateStockStatus(stock));
    // 100 → "in_stock"

    // 补全字段 3：热度评分
    result.put("hotScore", calculateHotScore(price, stock));
    // 7999 * 0.01 + 100 * 0.1 = 89.99

    // 补全字段 4：状态文本
    result.put("statusText", status == 1 ? "上架" : "下架");
    // 1 → "上架"

    // 数据清洗：price 从 String 转为 Double
    result.put("price", price.doubleValue());

    return result;
}
```
- **Extract**：从 Canal 消息中提取 MySQL 原始数据
- **Transform**：数据清洗 + 补全 4 个额外字段
- **Load**：调用 ElasticsearchService 写入 ES

---

#### 第 9 步：ElasticsearchService 写入 ES
**文件**：`canal-client/src/main/java/com/example/canal/es/ElasticsearchService.java`

```java
public void indexDocument(String indexName, Long id, Map<String, Object> data) {
    IndexRequest request = new IndexRequest(indexName)  // 索引名：products
            .id(id.toString())                          // 文档 ID：商品 ID
            .source(data);                              // 文档内容：转换后的数据
    restHighLevelClient.index(request, RequestOptions.DEFAULT);
}
```
- 使用 `RestHighLevelClient` 向 ES 发送 IndexRequest
- 文档写入 `products` 索引
- ES 对 `name`、`description` 字段用 IK 分词器建立倒排索引

---

### 写入后 ES 文档内容示例

```json
{
  "id": "1",
  "name": "苹果手机15",
  "description": "苹果最新款手机",
  "price": 7999.0,
  "stock": 100,
  "category": "手机",
  "brand": "苹果",
  "status": 1,
  "priceRange": "1000+",
  "stockStatus": "in_stock",
  "hotScore": 89.99,
  "statusText": "上架"
}
```

---

## 二、数据查询链路（前端搜索 → ES → 返回结果）

### 完整调用链

```
GET /api/search?keyword=苹果手机
    → SearchController.search()
    → SearchService.search()
    → ElasticsearchOperations.search()   ← 查询 ES
    → 返回 List<ProductDocument>
    → 返回给前端 JSON 数组
```

---

### 详细步骤说明

#### 第 1 步：前端发起搜索请求
```
GET http://localhost:8080/api/search?keyword=苹果手机
```

---

#### 第 2 步：SearchController 接收请求
**文件**：`backend/src/main/java/com/example/backend/controller/SearchController.java`

```java
@GetMapping
public ResponseEntity<List<ProductDocument>> search(@RequestParam String keyword) {
    List<ProductDocument> results = searchService.search(keyword);
    return ResponseEntity.ok(results);
}
```
- 接收 `keyword` 参数
- 调用 `SearchService.search(keyword)`

---

#### 第 3 步：SearchService 构建 ES 查询
**文件**：`backend/src/main/java/com/example/backend/service/SearchService.java`

```java
public List<ProductDocument> search(String keyword) {
    // 构建多字段搜索条件：在 name 和 description 中搜索
    Criteria criteria = new Criteria("name").contains(keyword)
            .or(new Criteria("description").contains(keyword));

    CriteriaQuery query = new CriteriaQuery(criteria);

    // 执行查询
    SearchHits<ProductDocument> searchHits =
            elasticsearchOperations.search(query, ProductDocument.class);

    // 提取结果
    return searchHits.getSearchHits().stream()
            .map(hit -> hit.getContent())
            .collect(Collectors.toList());
}
```
- `keyword = "苹果手机"` 经 IK 分词器分词为：`苹果`、`手机`、`苹果手机`
- 在 ES 的 `products` 索引中搜索 `name` 和 `description` 字段
- 返回匹配的商品列表

---

#### 第 4 步：返回搜索结果
- ES 返回匹配的 `ProductDocument` 列表
- SearchController 封装为 JSON 响应返回给前端
- 前端展示搜索结果

---

### 其他搜索接口

| 接口 | 说明 |
|------|------|
| `GET /api/search?keyword=苹果` | 全文搜索，IK分词 |
| `GET /api/search/all` | 查询 ES 中所有商品 |
| `GET /api/search/count` | 查询 ES 文档总数 |
| `GET /api/search/{id}` | 按 ID 查询 ES 中的商品 |

---

## 三、数据更新/删除链路

### 更新商品

```
PUT /api/products/{id}
    → ProductController.updateProduct()
    → ProductService.save()
    → ProductRepository.save()          ← JPA 更新 MySQL（生成 UPDATE binlog）
    → Canal 捕获 binlog（type=UPDATE）
    → CanalMessageConsumer.handleUpdate()
    → ProductETLService.processUpdate()
    → ElasticsearchService.indexDocument()   ← ES 覆盖更新文档
```

### 删除商品

```
DELETE /api/products/{id}
    → ProductController.deleteProduct()
    → ProductService.deleteById()
    → ProductRepository.deleteById()    ← JPA 删除 MySQL（生成 DELETE binlog）
    → Canal 捕获 binlog（type=DELETE）
    → CanalMessageConsumer.handleDelete()
    → ProductETLService.processDelete()
    → ElasticsearchService.deleteDocument()  ← ES 删除对应文档
```

---

## 四、启动顺序

```
1. Elasticsearch        → D:\elasticsearch\bin\elasticsearch.bat
2. RabbitMQ             → 作为 Windows 服务运行（确保 http://localhost:15672 可访问）
3. Canal Server         → D:\elasticsearch\canal\start.bat
4. canal-client         → IDEA 中运行 CanalClientApplication
5. Backend              → IDEA 中运行 BackendApplication
6. Frontend             → cd D:\data-pipeline-demo\frontend && npm run serve
```

> **注意**：RabbitMQ 中 `canal.exchange`（fanout 类型）必须绑定到 `canal.queue`（routing key 留空），否则消息无法投递。

---

## 五、各模块端口汇总

| 服务 | 端口 | 说明 |
|------|------|------|
| Frontend | 3000 | Vue 前端页面 |
| Backend | 8080 | REST API 接口 |
| canal-client | 8081 | Canal 消息消费 + ES 写入 |
| MySQL | 3306 | 主数据库 |
| Canal Server | 11111 | binlog 监听 |
| RabbitMQ | 5672 | 消息队列 AMQP |
| RabbitMQ 管理界面 | 15672 | guest/guest |
| Elasticsearch | 9200 | 搜索引擎 |
