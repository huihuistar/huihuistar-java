@echo off
chcp 65001 >nul
title 停止中间件服务
cls

echo ========================================
echo    停止中间件服务
echo ========================================
echo.
echo  [1] Elasticsearch
echo  [2] RabbitMQ
echo  [3] Canal Server
echo  [4] 停止全部中间件
echo  [0] 退出
echo.
echo ========================================
echo.

set /p choice=请输入选项: 

echo.

if "%choice%"=="0" goto exit_menu
if "%choice%"=="1" goto stop_es
if "%choice%"=="2" goto stop_rabbitmq
if "%choice%"=="3" goto stop_canal
if "%choice%"=="4" goto stop_all

echo 无效的选项
timeout /t 2 >nul
goto exit_menu

:stop_all
echo [1/3] 停止 Canal Server...
cd /d D:\elasticsearch\canal\canal.deployer-1.1.8.tar\canal.deployer-1.1.8
call bin\stop.bat >nul 2>&1
echo     √ Canal Server 已停止
echo.

echo [2/3] 停止 RabbitMQ...
echo     √ RabbitMQ 作为Windows服务，请手动停止
echo     命令: net stop RabbitMQ
echo.

echo [3/3] 停止 Elasticsearch...
taskkill /F /IM elasticsearch.exe >nul 2>&1
echo     √ Elasticsearch 已停止
echo.

echo ========================================
echo 中间件已停止！
echo ========================================
echo.
goto end_menu

:stop_es
echo 停止 Elasticsearch...
taskkill /F /IM elasticsearch.exe >nul 2>&1
echo √ Elasticsearch 已停止
goto end_menu

:stop_rabbitmq
echo 停止 RabbitMQ...
echo √ RabbitMQ 作为Windows服务，请手动停止
echo   命令: net stop RabbitMQ
goto end_menu

:stop_canal
echo 停止 Canal Server...
cd /d D:\elasticsearch\canal\canal.deployer-1.1.8.tar\canal.deployer-1.1.8
call bin\stop.bat
echo √ Canal Server 已停止
goto end_menu

:exit_menu
echo 退出...
exit /b 0

:end_menu
echo.
pause
