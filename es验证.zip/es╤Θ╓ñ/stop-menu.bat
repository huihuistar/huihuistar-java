@echo off
chcp 65001 >nul
title 数据管道停止菜单
cls

echo ========================================
echo    数据管道停止菜单
echo ========================================
echo.
echo 请选择要停止的服务（输入数字，多个用空格分隔）：
echo.
echo  [1] Elasticsearch
echo  [2] RabbitMQ
echo  [3] Canal Server
echo  [4] canal-client (IDEA中停止)
echo  [5] Backend (IDEA中停止)
echo  [6] Frontend
echo  [7] 停止全部
echo  [0] 退出
echo.
echo ========================================
echo.

set /p choice="请输入选项: "

if "%choice%"=="0" goto exit
if "%choice%"=="7" goto stop_all

for %%i in (%choice%) do (
    if "%%i"=="1" call :stop_es
    if "%%i"=="2" call :stop_rabbitmq
    if "%%i"=="3" call :stop_canal
    if "%%i"=="4" call :stop_canal_client
    if "%%i"=="5" call :stop_backend
    if "%%i"=="6" call :stop_frontend
)

goto end

:stop_all
call :stop_frontend
call :stop_backend
call :stop_canal_client
call :stop_canal
call :stop_es
echo.
echo RabbitMQ 请手动停止服务
goto end

:stop_es
echo.
echo [1] 停止 Elasticsearch...
taskkill /F /IM elasticsearch.exe 2>nul
taskkill /F /IM java.exe /FI "WINDOWTITLE eq Elasticsearch*" 2>nul
echo     Elasticsearch 已停止
goto :eof

:stop_rabbitmq
echo.
echo [2] RabbitMQ 停止
echo     请在Windows服务中停止 RabbitMQ 服务
echo     或者运行: net stop RabbitMQ
pause
goto :eof

:stop_canal
echo.
echo [3] 停止 Canal Server...
call "D:\elasticsearch\canal\stop.bat"
goto :eof

:stop_canal_client
echo.
echo [4] 请在 IDEA 中停止 canal-client
echo     点击红色停止按钮
goto :eof

:stop_backend
echo.
echo [5] 请在 IDEA 中停止 Backend
echo     点击红色停止按钮
goto :eof

:stop_frontend
echo.
echo [6] 停止 Frontend...
taskkill /F /IM node.exe /FI "WINDOWTITLE eq Frontend*" 2>nul
taskkill /F /IM cmd.exe /FI "WINDOWTITLE eq Frontend*" 2>nul
echo     Frontend 已停止
goto :eof

:exit
echo 退出...
exit /b 0

:end
echo.
echo ========================================
echo 停止命令已执行完毕
echo ========================================
pause
