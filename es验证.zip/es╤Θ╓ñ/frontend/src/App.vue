<template>
  <div class="app">
    <header class="header">
      <h1>🔄 数据管道演示</h1>
      <p>MySQL → Canal → ETL → Elasticsearch</p>
    </header>
    
    <div class="container">
      <!-- 左侧：添加商品 -->
      <div class="panel">
        <h2>➕ 添加商品</h2>
        <p class="desc">添加商品到MySQL，观察自动同步到ES</p>
        
        <form @submit.prevent="addProduct">
          <div class="form-group">
            <label>商品名称</label>
            <input v-model="product.name" placeholder="如：苹果手机 iPhone 15" required>
          </div>
          
          <div class="form-group">
            <label>商品描述</label>
            <textarea v-model="product.description" placeholder="商品详细描述..." rows="3"></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label>价格（元）</label>
              <input v-model.number="product.price" type="number" placeholder="5999" required>
            </div>
            <div class="form-group">
              <label>库存</label>
              <input v-model.number="product.stock" type="number" placeholder="100" required>
            </div>
          </div>
          
          <div class="form-row">
            <div class="form-group">
              <label>分类</label>
              <select v-model="product.category">
                <option value="手机">手机</option>
                <option value="电脑">电脑</option>
                <option value="家电">家电</option>
                <option value="服装">服装</option>
                <option value="食品">食品</option>
              </select>
            </div>
            <div class="form-group">
              <label>品牌</label>
              <input v-model="product.brand" placeholder="如：Apple">
            </div>
          </div>
          
          <button type="submit" :disabled="loading">
            {{ loading ? '添加中...' : '添加商品' }}
          </button>
        </form>
        
        <div v-if="message" :class="['message', messageType]">
          {{ message }}
        </div>
        
        <div class="stats">
          <div class="stat-item">
            <span class="stat-label">MySQL商品数：</span>
            <span class="stat-value">{{ mysqlCount }}</span>
          </div>
          <div class="stat-item">
            <span class="stat-label">ES文档数：</span>
            <span class="stat-value">{{ esCount }}</span>
          </div>
        </div>
      </div>
      
      <!-- 右侧：搜索商品 -->
      <div class="panel">
        <h2>🔍 搜索商品</h2>
        <p class="desc">使用IK分词器搜索商品名称</p>
        
        <div class="search-box">
          <input 
            v-model="keyword" 
            @keyup.enter="search"
            placeholder="输入关键词搜索，如：苹果、手机、iPhone..."
          >
          <button @click="search" :disabled="searching">
            {{ searching ? '搜索中...' : '搜索' }}
          </button>
        </div>
        
        <div v-if="searchMessage" class="message info">
          {{ searchMessage }}
        </div>
        
        <div class="results">
          <div v-if="results.length === 0 && !searching" class="empty">
            暂无搜索结果，请先添加商品或输入关键词搜索
          </div>
          
          <div v-for="item in results" :key="item.id" class="product-card">
            <div class="product-header">
              <h3>{{ item.name }}</h3>
              <span class="price">¥{{ item.price }}</span>
            </div>
            <p class="description">{{ item.description || '暂无描述' }}</p>
            <div class="product-meta">
              <span class="tag category">{{ item.category }}</span>
              <span class="tag brand">{{ item.brand || '无品牌' }}</span>
              <span :class="['tag', 'stock-' + item.stockStatus]">
                {{ getStockText(item.stockStatus) }}
              </span>
              <span class="tag price-range">{{ item.priceRange }}</span>
            </div>
            <div class="product-extra">
              <span>库存：{{ item.stock }}</span>
              <span>热度：{{ item.hotScore?.toFixed(2) }}</span>
              <span :class="['status', item.status === 1 ? 'on' : 'off']">
                {{ item.statusText }}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios'

export default {
  name: 'App',
  data() {
    return {
      product: {
        name: '',
        description: '',
        price: null,
        stock: null,
        category: '手机',
        brand: '',
        status: 1
      },
      keyword: '',
      results: [],
      mysqlCount: 0,
      esCount: 0,
      loading: false,
      searching: false,
      message: '',
      messageType: 'success',
      searchMessage: ''
    }
  },
  mounted() {
    this.loadCounts()
    // 每5秒刷新一次数量
    setInterval(this.loadCounts, 5000)
  },
  methods: {
    // 添加商品
    async addProduct() {
      this.loading = true
      this.message = ''
      
      try {
        await axios.post('/api/products', this.product)
        this.message = '✅ 商品已添加到MySQL，等待同步到ES...'
        this.messageType = 'success'
        
        // 清空表单
        this.product = {
          name: '',
          description: '',
          price: null,
          stock: null,
          category: '手机',
          brand: '',
          status: 1
        }
        
        // 刷新数量
        setTimeout(this.loadCounts, 1000)
      } catch (error) {
        this.message = '❌ 添加失败：' + (error.response?.data?.message || error.message)
        this.messageType = 'error'
      } finally {
        this.loading = false
      }
    },
    
    // 搜索商品
    async search() {
      if (!this.keyword.trim()) {
        this.searchMessage = '请输入搜索关键词'
        return
      }
      
      this.searching = true
      this.searchMessage = ''
      
      try {
        const response = await axios.get('/api/search?keyword=' + encodeURIComponent(this.keyword))
        this.results = response.data
        this.searchMessage = `找到 ${this.results.length} 个结果（使用IK分词器）`
      } catch (error) {
        this.searchMessage = '搜索失败：' + (error.response?.data?.message || error.message)
      } finally {
        this.searching = false
      }
    },
    
    // 加载统计数量
    async loadCounts() {
      try {
        // 获取MySQL商品数
        const mysqlRes = await axios.get('/api/products')
        this.mysqlCount = mysqlRes.data.length
        
        // 获取ES文档数
        const esRes = await axios.get('/api/search/count')
        this.esCount = esRes.data.count
      } catch (error) {
        console.log('加载数量失败', error)
      }
    },
    
    // 获取库存状态文本
    getStockText(status) {
      const map = {
        'out_of_stock': '缺货',
        'low_stock': '低库存',
        'in_stock': '库存充足'
      }
      return map[status] || status
    }
  }
}
</script>

<style>
.app {
  min-height: 100vh;
}

.header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 30px;
  text-align: center;
}

.header h1 {
  font-size: 28px;
  margin-bottom: 10px;
}

.header p {
  opacity: 0.9;
  font-size: 14px;
}

.container {
  display: flex;
  gap: 20px;
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.panel {
  flex: 1;
  background: white;
  border-radius: 12px;
  padding: 24px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.panel h2 {
  margin-bottom: 8px;
  color: #333;
}

.desc {
  color: #666;
  font-size: 14px;
  margin-bottom: 20px;
}

.form-group {
  margin-bottom: 16px;
}

.form-group label {
  display: block;
  margin-bottom: 6px;
  font-weight: 500;
  color: #333;
  font-size: 14px;
}

.form-group input,
.form-group textarea,
.form-group select {
  width: 100%;
  padding: 10px 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
  transition: border-color 0.2s;
}

.form-group input:focus,
.form-group textarea:focus,
.form-group select:focus {
  outline: none;
  border-color: #667eea;
}

.form-row {
  display: flex;
  gap: 12px;
}

.form-row .form-group {
  flex: 1;
}

button {
  width: 100%;
  padding: 12px;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 16px;
  cursor: pointer;
  transition: opacity 0.2s;
}

button:hover:not(:disabled) {
  opacity: 0.9;
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.message {
  margin-top: 16px;
  padding: 12px;
  border-radius: 6px;
  font-size: 14px;
}

.message.success {
  background: #d4edda;
  color: #155724;
}

.message.error {
  background: #f8d7da;
  color: #721c24;
}

.message.info {
  background: #d1ecf1;
  color: #0c5460;
}

.stats {
  margin-top: 20px;
  padding-top: 20px;
  border-top: 1px solid #eee;
}

.stat-item {
  display: flex;
  justify-content: space-between;
  padding: 8px 0;
  font-size: 14px;
}

.stat-value {
  font-weight: bold;
  color: #667eea;
}

.search-box {
  display: flex;
  gap: 10px;
  margin-bottom: 16px;
}

.search-box input {
  flex: 1;
  padding: 12px;
  border: 1px solid #ddd;
  border-radius: 6px;
  font-size: 14px;
}

.search-box button {
  width: auto;
  padding: 12px 24px;
}

.results {
  max-height: 600px;
  overflow-y: auto;
}

.empty {
  text-align: center;
  padding: 60px 20px;
  color: #999;
}

.product-card {
  background: #f8f9fa;
  border-radius: 8px;
  padding: 16px;
  margin-bottom: 12px;
}

.product-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 8px;
}

.product-header h3 {
  font-size: 16px;
  color: #333;
}

.price {
  font-size: 18px;
  font-weight: bold;
  color: #e74c3c;
}

.description {
  color: #666;
  font-size: 13px;
  margin-bottom: 12px;
  line-height: 1.5;
}

.product-meta {
  display: flex;
  gap: 8px;
  flex-wrap: wrap;
  margin-bottom: 10px;
}

.tag {
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 12px;
}

.tag.category {
  background: #e3f2fd;
  color: #1976d2;
}

.tag.brand {
  background: #f3e5f5;
  color: #7b1fa2;
}

.tag.stock-out_of_stock {
  background: #ffebee;
  color: #c62828;
}

.tag.stock-low_stock {
  background: #fff3e0;
  color: #ef6c00;
}

.tag.stock-in_stock {
  background: #e8f5e9;
  color: #2e7d32;
}

.tag.price-range {
  background: #e0f2f1;
  color: #00695c;
}

.product-extra {
  display: flex;
  gap: 16px;
  font-size: 12px;
  color: #666;
}

.status {
  padding: 2px 8px;
  border-radius: 4px;
}

.status.on {
  background: #e8f5e9;
  color: #2e7d32;
}

.status.off {
  background: #ffebee;
  color: #c62828;
}

@media (max-width: 900px) {
  .container {
    flex-direction: column;
  }
}
</style>
