package com.example.canal.config;

import org.apache.http.HttpHost;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Elasticsearch配置类
 * 
 * 配置ES客户端连接你本地已安装的ES
 */
@Configuration
public class ElasticsearchConfig {
    
    @Value("${elasticsearch.host:127.0.0.1}")
    private String host;
    
    @Value("${elasticsearch.port:9200}")
    private int port;
    
    /**
     * 创建ES客户端
     */
    @Bean
    public RestHighLevelClient restHighLevelClient() {
        return new RestHighLevelClient(
                RestClient.builder(new HttpHost(host, port))
        );
    }
}
