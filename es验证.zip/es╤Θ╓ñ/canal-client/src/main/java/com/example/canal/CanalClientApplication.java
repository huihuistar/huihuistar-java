package com.example.canal;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Canal客户端启动类
 * 
 * 功能：
 * 1. 连接Canal Server监听MySQL的binlog变化
 * 2. 接收数据变化消息
 * 3. 进行ETL处理（补全字段）
 * 4. 同步到Elasticsearch
 * 
 * 启动顺序：
 * 1. 先启动MySQL、Canal Server、RabbitMQ、ES
 * 2. 再启动backend模块（创建数据库表）
 * 3. 最后启动canal-client模块
 */
@SpringBootApplication
public class CanalClientApplication {
    public static void main(String[] args) {
        SpringApplication.run(CanalClientApplication.class, args);
        System.out.println("========================================");
        System.out.println("Canal客户端已启动");
        System.out.println("正在监听MySQL变化...");
        System.out.println("========================================");
    }
}
