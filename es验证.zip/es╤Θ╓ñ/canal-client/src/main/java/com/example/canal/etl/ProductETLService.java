package com.example.canal.etl;

import com.alibaba.fastjson.JSON;
import com.example.canal.es.ElasticsearchService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 商品ETL处理服务
 * 
 * ETL = Extract（抽取）+ Transform（转换）+ Load（加载）
 * 
 * 功能：
 * 1. Extract: 从Canal接收MySQL原始数据
 * 2. Transform: 数据清洗 + 补全字段
 * 3. Load: 写入Elasticsearch
 * 
 * 补全的字段：
 * - priceRange: 价格区间（0-100, 100-500, 500-1000, 1000+）
 * - stockStatus: 库存状态（out_of_stock, low_stock, in_stock）
 * - hotScore: 热度评分（基于价格和库存计算）
 * - statusText: 状态文本（上架/下架）
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ProductETLService {
    
    private final ElasticsearchService elasticsearchService;
    
    private static final String INDEX_NAME = "products";
    
    /**
     * 处理INSERT操作
     */
    public void processInsert(Map<String, Object> data) {
        try {
            // 1. ETL转换
            Map<String, Object> transformedData = transform(data);
            
            // 2. 写入ES
            Long id = Long.valueOf(data.get("id").toString());
            elasticsearchService.indexDocument(INDEX_NAME, id, transformedData);
            
            Map<String, Object> extraFields = new HashMap<>();
            extraFields.put("priceRange", transformedData.get("priceRange"));
            extraFields.put("stockStatus", transformedData.get("stockStatus"));
            extraFields.put("hotScore", transformedData.get("hotScore"));
            log.info("ETL处理完成，商品已同步到ES，ID：{}，补全字段：{}", id, extraFields);
        } catch (Exception e) {
            log.error("ETL处理INSERT失败", e);
        }
    }
    
    /**
     * 处理UPDATE操作
     */
    public void processUpdate(Map<String, Object> data) {
        try {
            // 1. ETL转换
            Map<String, Object> transformedData = transform(data);
            
            // 2. 更新ES
            Long id = Long.valueOf(data.get("id").toString());
            elasticsearchService.indexDocument(INDEX_NAME, id, transformedData);
            
            log.info("ETL处理完成，商品已更新到ES，ID：{}", id);
        } catch (Exception e) {
            log.error("ETL处理UPDATE失败", e);
        }
    }
    
    /**
     * 处理DELETE操作
     */
    public void processDelete(Map<String, Object> data) {
        try {
            Long id = Long.valueOf(data.get("id").toString());
            elasticsearchService.deleteDocument(INDEX_NAME, id);
            
            log.info("ETL处理完成，商品已从ES删除，ID：{}", id);
        } catch (Exception e) {
            log.error("ETL处理DELETE失败", e);
        }
    }
    
    /**
     * ETL转换逻辑
     * 
     * 原始字段 -> 补全字段
     */
    private Map<String, Object> transform(Map<String, Object> source) {
        Map<String, Object> result = new HashMap<>(source);
        
        // 1. 补全价格区间
        BigDecimal price = new BigDecimal(source.getOrDefault("price", "0").toString());
        result.put("priceRange", calculatePriceRange(price));
        
        // 2. 补全库存状态
        Integer stock = Integer.valueOf(source.getOrDefault("stock", "0").toString());
        result.put("stockStatus", calculateStockStatus(stock));
        
        // 3. 补全热度评分（价格越高、库存越多，热度越高）
        result.put("hotScore", calculateHotScore(price, stock));
        
        // 4. 补全状态文本
        Integer status = Integer.valueOf(source.getOrDefault("status", "1").toString());
        result.put("statusText", status == 1 ? "上架" : "下架");
        
        // 5. 数据清洗：确保price是数字类型
        result.put("price", price.doubleValue());
        
        return result;
    }
    
    /**
     * 计算价格区间
     */
    private String calculatePriceRange(BigDecimal price) {
        double p = price.doubleValue();
        if (p < 100) return "0-100";
        if (p < 500) return "100-500";
        if (p < 1000) return "500-1000";
        return "1000+";
    }
    
    /**
     * 计算库存状态
     */
    private String calculateStockStatus(Integer stock) {
        if (stock == null || stock <= 0) return "out_of_stock";      // 缺货
        if (stock < 10) return "low_stock";                          // 低库存
        return "in_stock";                                           // 库存充足
    }
    
    /**
     * 计算热度评分
     * 算法：价格 * 0.01 + 库存 * 0.1
     */
    private Double calculateHotScore(BigDecimal price, Integer stock) {
        if (stock == null) stock = 0;
        return price.doubleValue() * 0.01 + stock * 0.1;
    }
}
