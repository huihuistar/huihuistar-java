package com.example.canal.config;

import org.springframework.amqp.core.AcknowledgeMode;
import org.springframework.amqp.rabbit.config.SimpleRabbitListenerContainerFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * RabbitMQ 配置
 * 
 * 只配置消费者监听器，不自动创建队列、交换机或绑定
 * 所有队列、交换机和绑定请在 RabbitMQ 管理界面手动创建：
 * 
 * 1. 创建 queue: canal.queue (类型: durable)
 * 2. 创建 exchange: canal.exchange (类型: fanout)
 * 3. 绑定: canal.exchange -> canal.queue (routing key 留空)
 */
@Configuration
public class RabbitMQConfig {
    
    public static final String QUEUE_NAME = "canal.queue";
    
    /**
     * 配置 RabbitMQ 监听器容器工厂
     */
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setAcknowledgeMode(AcknowledgeMode.AUTO);
        factory.setConcurrentConsumers(1);
        factory.setMaxConcurrentConsumers(1);
        return factory;
    }
}
