package com.example.canal.mq;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.example.canal.etl.ProductETLService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

import java.util.Map;

/**
 * Canal RabbitMQ 消息消费者
 * 
 * 从 RabbitMQ 消费 Canal 发送的 binlog 变更消息
 * 消息格式为 FlatMessage（JSON）
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CanalMessageConsumer {
    
    private final ProductETLService productETLService;
    
    /**
     * 监听 Canal 队列
     * 
     * 消息格式示例：
     * {
     *   "data": [{"id": "1", "name": "苹果15", "price": "9999.00"}],
     *   "database": "demo_db",
     *   "table": "product",
     *   "type": "INSERT",
     *   "ts": 1234567890
     * }
     */
    @RabbitListener(queues = "canal.queue", containerFactory = "rabbitListenerContainerFactory")
    public void handleCanalMessage(String message) {
        try {
            log.debug("收到Canal消息：{}", message);
            
            JSONObject jsonMessage = JSON.parseObject(message);
            String database = jsonMessage.getString("database");
            String table = jsonMessage.getString("table");
            String type = jsonMessage.getString("type");
            
            // 只处理 demo_db.product 表
            if (!"demo_db".equals(database) || !"product".equals(table)) {
                log.debug("跳过非目标表消息：{}.{}", database, table);
                return;
            }
            
            switch (type.toUpperCase()) {
                case "INSERT":
                    handleInsert(jsonMessage);
                    break;
                case "UPDATE":
                    handleUpdate(jsonMessage);
                    break;
                case "DELETE":
                    handleDelete(jsonMessage);
                    break;
                default:
                    log.warn("未知操作类型：{}", type);
            }
            
        } catch (Exception e) {
            log.error("处理Canal消息失败：{}", message, e);
        }
    }
    
    private void handleInsert(JSONObject jsonMessage) {
        jsonMessage.getJSONArray("data").forEach(item -> {
            Map<String, Object> data = ((JSONObject) item).getInnerMap();
            log.info("处理INSERT操作，数据：{}", data);
            productETLService.processInsert(data);
        });
    }
    
    private void handleUpdate(JSONObject jsonMessage) {
        jsonMessage.getJSONArray("data").forEach(item -> {
            Map<String, Object> data = ((JSONObject) item).getInnerMap();
            log.info("处理UPDATE操作，数据：{}", data);
            productETLService.processUpdate(data);
        });
    }
    
    private void handleDelete(JSONObject jsonMessage) {
        jsonMessage.getJSONArray("data").forEach(item -> {
            Map<String, Object> data = ((JSONObject) item).getInnerMap();
            log.info("处理DELETE操作，数据：{}", data);
            productETLService.processDelete(data);
        });
    }
}
