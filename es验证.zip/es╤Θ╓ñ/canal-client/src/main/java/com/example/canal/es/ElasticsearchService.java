package com.example.canal.es;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.delete.DeleteRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.Map;

/**
 * Elasticsearch服务
 * 
 * 封装ES操作：
 * - 索引文档（新增/更新）
 * - 删除文档
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class ElasticsearchService {
    
    private final RestHighLevelClient restHighLevelClient;
    
    /**
     * 索引文档（新增或更新）
     * 
     * @param indexName 索引名
     * @param id 文档ID
     * @param data 文档数据
     */
    public void indexDocument(String indexName, Long id, Map<String, Object> data) {
        try {
            IndexRequest request = new IndexRequest(indexName)
                    .id(id.toString())
                    .source(data);
            
            restHighLevelClient.index(request, RequestOptions.DEFAULT);
            log.debug("ES文档索引成功，index：{}，id：{}", indexName, id);
        } catch (IOException e) {
            log.error("ES文档索引失败", e);
            throw new RuntimeException("索引文档失败", e);
        }
    }
    
    /**
     * 删除文档
     * 
     * @param indexName 索引名
     * @param id 文档ID
     */
    public void deleteDocument(String indexName, Long id) {
        try {
            DeleteRequest request = new DeleteRequest(indexName, id.toString());
            restHighLevelClient.delete(request, RequestOptions.DEFAULT);
            log.debug("ES文档删除成功，index：{}，id：{}", indexName, id);
        } catch (IOException e) {
            log.error("ES文档删除失败", e);
            throw new RuntimeException("删除文档失败", e);
        }
    }
}
