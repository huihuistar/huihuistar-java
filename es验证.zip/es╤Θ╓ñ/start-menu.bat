@echo off
chcp 65001 >nul
title 数据管道启动菜单
:menu
cls

echo ========================================
echo    数据管道启动菜单
echo ========================================
echo.
echo 请选择要启动的服务：
echo.
echo  [1] Elasticsearch
echo  [2] RabbitMQ
echo  [3] Canal Server
echo  [4] canal-client (IDEA中启动)
echo  [5] Backend (IDEA中启动)
echo  [6] Frontend
echo  [7] 启动全部
echo  [0] 退出
echo.
echo ========================================
echo.

set /p choice=请输入选项: 

echo.
echo 你选择了: %choice%
echo.

if "%choice%"=="0" goto exit_menu
if "%choice%"=="1" goto start_es
if "%choice%"=="2" goto start_rabbitmq
if "%choice%"=="3" goto start_canal
if "%choice%"=="4" goto start_canal_client
if "%choice%"=="5" goto start_backend
if "%choice%"=="6" goto start_frontend
if "%choice%"=="7" goto start_all

echo 无效的选项，请重新选择
timeout /t 2 >nul
goto menu

:start_all
echo [7] 启动全部服务...
call :do_start_es
call :do_start_rabbitmq
call :do_start_canal
call :do_start_canal_client
call :do_start_backend
call :do_start_frontend
goto end_menu

:start_es
call :do_start_es
goto end_menu

:start_rabbitmq
call :do_start_rabbitmq
goto end_menu

:start_canal
call :do_start_canal
goto end_menu

:start_canal_client
call :do_start_canal_client
goto end_menu

:start_backend
call :do_start_backend
goto end_menu

:start_frontend
call :do_start_frontend
goto end_menu

:do_start_es
echo.
echo [1] 启动 Elasticsearch...
start "Elasticsearch" cmd /c "cd /d D:\elasticsearch\bin && elasticsearch.bat"
timeout /t 5 /nobreak >nul
echo     Elasticsearch 启动中，请等待...
goto :eof

:do_start_rabbitmq
echo.
echo [2] 检查 RabbitMQ...
echo     RabbitMQ 作为Windows服务运行，请确保已启动
echo     管理界面: http://localhost:15672/
pause
goto :eof

:do_start_canal
echo.
echo [3] 启动 Canal Server...
cd /d D:\elasticsearch\canal
call start.bat
goto :eof

:do_start_canal_client
echo.
echo [4] 请在 IDEA 中手动启动 canal-client
echo     运行类: com.example.canal.CanalClientApplication
pause
goto :eof

:do_start_backend
echo.
echo [5] 请在 IDEA 中手动启动 Backend
echo     运行类: com.example.demo.DemoApplication
pause
goto :eof

:do_start_frontend
echo.
echo [6] 启动 Frontend...
start "Frontend" cmd /c "cd /d D:\data-pipeline-demo\frontend && npm run serve"
timeout /t 3 /nobreak >nul
goto :eof

:exit_menu
echo 退出...
exit /b 0

:end_menu
echo.
echo ========================================
echo 启动命令已执行完毕
echo ========================================
pause
goto menu
