@echo off
chcp 65001 >nul
title 启动中间件服务
cls

echo ========================================
echo    启动中间件服务
echo ========================================
echo.
echo 此脚本只启动中间件，Java程序请在IDEA中手动启动
echo.
echo  [1] Elasticsearch
echo  [2] RabbitMQ
echo  [3] Canal Server
echo  [4] 启动全部中间件
echo  [0] 退出
echo.
echo ========================================
echo.

set /p choice=请输入选项: 

echo.

if "%choice%"=="0" goto exit_menu
if "%choice%"=="1" goto start_es
if "%choice%"=="2" goto start_rabbitmq
if "%choice%"=="3" goto start_canal
if "%choice%"=="4" goto start_all

echo 无效的选项
timeout /t 2 >nul
goto exit_menu

:start_all
echo [1/3] 启动 Elasticsearch...
start "ES" cmd /c "cd /d D:\elasticsearch\bin && elasticsearch.bat"
timeout /t 5 /nobreak >nul
echo     √ Elasticsearch 启动中（等待10-20秒）
echo.

echo [2/3] 检查 RabbitMQ...
echo     √ RabbitMQ 作为Windows服务运行
echo     管理界面: http://localhost:15672/
echo.

echo [3/3] 启动 Canal Server...
cd /d D:\elasticsearch\canal\canal.deployer-1.1.8.tar\canal.deployer-1.1.8
call bin\startup.bat >nul 2>&1
echo     √ Canal Server 已启动
echo.

echo ========================================
echo 中间件启动完成！
echo ========================================
echo.
echo 接下来请在IDEA中启动：
echo   1. canal-client
echo   2. Backend
echo.
echo 然后在命令行启动前端：
echo   cd D:\data-pipeline-demo\frontend
echo   npm run serve
echo.
goto end_menu

:start_es
echo 启动 Elasticsearch...
start "ES" cmd /c "cd /d D:\elasticsearch\bin && elasticsearch.bat"
echo √ Elasticsearch 启动中（等待10-20秒）
goto end_menu

:start_rabbitmq
echo 检查 RabbitMQ...
echo √ RabbitMQ 作为Windows服务运行
echo   管理界面: http://localhost:15672/
goto end_menu

:start_canal
echo 启动 Canal Server...
cd /d D:\elasticsearch\canal\canal.deployer-1.1.8.tar\canal.deployer-1.1.8
call bin\startup.bat
echo √ Canal Server 已启动
goto end_menu

:exit_menu
echo 退出...
exit /b 0

:end_menu
echo.
pause
