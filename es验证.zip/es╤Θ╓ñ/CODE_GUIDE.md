# 代码详解文档 — data-pipeline-demo

> 本文档详细说明项目中每一个类的作用、每段代码的含义，以及数据从前端到 MySQL、再同步到 Elasticsearch 的完整流转路径。

---

## 目录

1. [项目整体架构](#项目整体架构)
2. [backend 模块 — 接收前端请求，操作 MySQL](#backend-模块)
   - [BackendApplication.java](#1-backendapplicationjava)
   - [entity/Product.java](#2-entityproductjava)
   - [repository/ProductRepository.java](#3-repositoryproductrepositoryjava)
   - [repository/ProductSearchRepository.java](#4-repositoryproductsearchrepositoryjava)
   - [service/ProductService.java](#5-serviceproductservicejava)
   - [service/SearchService.java](#6-servicesearchservicejava)
   - [controller/ProductController.java](#7-controllerproductcontrollerjava)
   - [controller/SearchController.java](#8-controllersearchcontrollerjava)
   - [document/ProductDocument.java](#9-documentproductdocumentjava)
   - [application.yml（backend）](#10-applicationymlbackend)
3. [canal-client 模块 — 监听变更，同步 ES](#canal-client-模块)
   - [CanalClientApplication.java](#1-canalclientapplicationjava)
   - [config/RabbitMQConfig.java](#2-configrabbitmqconfigjava)
   - [config/ElasticsearchConfig.java](#3-configelasticsearchconfigjava)
   - [mq/CanalMessageConsumer.java](#4-mqcanalmessageconsumerjava)
   - [etl/ProductETLService.java](#5-etlproductetlservicejava)
   - [es/ElasticsearchService.java](#6-eselasticsearchservicejava)
   - [application.yml（canal-client）](#7-applicationymlcanal-client)
4. [数据流转路径 — 写入链路](#数据流转路径--写入链路)
5. [数据流转路径 — 查询链路](#数据流转路径--查询链路)
6. [中间件说明](#中间件说明)

---

## 项目整体架构

```
前端 Vue (3000)
    │
    │  HTTP 请求
    ▼
backend 模块 (8080)
    │
    │  JPA / Hibernate
    ▼
MySQL (3306)  ←── 只写这里，不直接写 ES
    │
    │  binlog（二进制日志）
    ▼
Canal Server (11111)   ← 伪装成 MySQL Slave，监听 binlog
    │
    │  发送变更消息（JSON）
    ▼
RabbitMQ (5672)        ← canal.exchange（fanout） → canal.queue
    │
    │  消费消息
    ▼
canal-client 模块 (8081)
    │
    │  ETL 处理（补全字段）
    ▼
Elasticsearch (9200)   ← 最终存储，供搜索用
    │
    │  搜索查询
    ▼
backend 模块 → 前端
```

**核心设计思想：**  
业务写入只操作 MySQL，由 Canal 异步捕获变更，通过 RabbitMQ 传递给 canal-client，经过 ETL 处理后同步到 ES。查询走 ES，写入走 MySQL，读写分离，互不干扰。

---

## backend 模块

> 路径：`d:\data-pipeline-demo\backend\src\main\java\com\example\backend\`

### 1. BackendApplication.java

```java
@SpringBootApplication
public class BackendApplication {
    public static void main(String[] args) {
        SpringApplication.run(BackendApplication.class, args);
    }
}
```

**作用：** Spring Boot 启动类，程序入口。

`@SpringBootApplication` 是一个组合注解，等价于同时写了：
- `@Configuration`：标记这是配置类
- `@EnableAutoConfiguration`：启用 Spring Boot 自动配置
- `@ComponentScan`：扫描当前包下所有带 `@Component`、`@Service`、`@Controller` 注解的类

启动后会自动连接 MySQL，注册所有 Controller，开始监听 8080 端口。

---

### 2. entity/Product.java

```java
@Data
@Entity
@Table(name = "product")
public class Product {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false, length = 200)
    private String name;

    @Column(name = "price", nullable = false, precision = 10, scale = 2)
    private BigDecimal price;

    // 创建时自动设置时间
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }

    // 更新时自动刷新时间
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
}
```

**作用：** MySQL `product` 表的映射类（JPA 实体）。

关键注解说明：

| 注解 | 含义 |
|------|------|
| `@Entity` | 告诉 JPA 这个类对应数据库中的一张表 |
| `@Table(name = "product")` | 指定表名是 `product` |
| `@Id` | 该字段是主键 |
| `@GeneratedValue(strategy = GenerationType.IDENTITY)` | 主键自增（AUTO_INCREMENT） |
| `@Column(nullable = false)` | 对应的数据库列不允许为空 |
| `@PrePersist` | 新增前自动执行（设置创建时间） |
| `@PreUpdate` | 更新前自动执行（刷新更新时间） |
| `@Data`（Lombok） | 自动生成所有字段的 getter、setter、toString、equals、hashCode |

**字段含义：**
- `name`：商品名称
- `description`：商品描述（TEXT 类型，可以存很长的文字）
- `price`：价格，用 `BigDecimal` 而不是 `double`，避免浮点数精度问题
- `stock`：库存数量
- `category`：商品分类（如"手机"、"电脑"）
- `brand`：品牌（如"苹果"、"华为"）
- `status`：上下架状态，1=上架，0=下架，默认为 1

---

### 3. repository/ProductRepository.java

```java
@Repository
public interface ProductRepository extends JpaRepository<Product, Long> {
}
```

**作用：** MySQL 数据访问层，负责所有对 `product` 表的增删改查。

继承 `JpaRepository<Product, Long>` 后，Spring Data JPA 会**自动生成**以下方法，不需要手写任何 SQL：

| 方法 | 对应 SQL |
|------|---------|
| `save(product)` | INSERT 或 UPDATE |
| `findById(id)` | SELECT * FROM product WHERE id = ? |
| `findAll()` | SELECT * FROM product |
| `deleteById(id)` | DELETE FROM product WHERE id = ? |
| `count()` | SELECT COUNT(*) FROM product |

`<Product, Long>` 表示：操作的实体是 `Product`，主键类型是 `Long`。

---

### 4. repository/ProductSearchRepository.java

```java
@Repository
public interface ProductSearchRepository extends ElasticsearchRepository<ProductDocument, Long> {
    List<ProductDocument> findByNameContaining(String name);
    List<ProductDocument> findByCategory(String category);
    List<ProductDocument> findByBrand(String brand);
}
```

**作用：** ES 搜索数据访问层，负责对 Elasticsearch 的操作。

继承 `ElasticsearchRepository` 后，同样自动获得基础的增删改查能力。

额外定义的方法（Spring Data 会根据方法名自动生成查询语句）：
- `findByNameContaining(name)` → ES 查询：name 字段包含关键词的文档
- `findByCategory(category)` → ES 精确匹配：category 字段等于指定值
- `findByBrand(brand)` → ES 精确匹配：brand 字段等于指定值

---

### 5. service/ProductService.java

```java
@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    @Transactional
    public Product save(Product product) {
        return productRepository.save(product);
    }

    public List<Product> findAll() {
        return productRepository.findAll();
    }

    public Optional<Product> findById(Long id) {
        return productRepository.findById(id);
    }

    @Transactional
    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }
}
```

**作用：** 商品业务逻辑层，介于 Controller 和 Repository 之间。

关键注解说明：

| 注解 | 含义 |
|------|------|
| `@Service` | 标记为服务层 Bean，Spring 自动管理 |
| `@RequiredArgsConstructor`（Lombok） | 自动生成构造函数，注入 `productRepository` |
| `@Transactional` | 开启事务，操作失败时自动回滚 |

**注意：** 这里只操作 MySQL，**不操作 ES**。ES 的同步完全由 Canal + canal-client 完成，不在这里处理。这是"读写分离"设计的体现。

---

### 6. service/SearchService.java

```java
@Service
@RequiredArgsConstructor
public class SearchService {

    private final ProductSearchRepository productSearchRepository;
    private final ElasticsearchOperations elasticsearchOperations;

    public List<ProductDocument> search(String keyword) {
        // 构建多字段搜索条件：name 或 description 包含关键词
        Criteria criteria = new Criteria("name").contains(keyword)
                .or(new Criteria("description").contains(keyword));

        CriteriaQuery query = new CriteriaQuery(criteria);
        SearchHits<ProductDocument> searchHits = elasticsearchOperations.search(query, ProductDocument.class);

        return searchHits.getSearchHits().stream()
                .map(hit -> hit.getContent())
                .collect(Collectors.toList());
    }
}
```

**作用：** ES 搜索服务，封装所有与 Elasticsearch 的搜索交互。

`search(keyword)` 方法的执行过程：
1. 用 `Criteria` 构建搜索条件：在 `name` 或 `description` 字段中包含 keyword
2. 包装成 `CriteriaQuery`（ES 查询对象）
3. 通过 `elasticsearchOperations.search()` 发送给 ES
4. ES 用 IK 分词器对 keyword 分词后执行搜索
5. 把 `SearchHits` 里的结果提取出来，返回 `List<ProductDocument>`

`ElasticsearchOperations` 是 Spring Data ES 提供的高级操作接口，比直接用 REST API 方便很多。

---

### 7. controller/ProductController.java

```java
@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins = "*")
public class ProductController {

    private final ProductService productService;

    @PostMapping
    public ResponseEntity<Product> createProduct(@RequestBody Product product) {
        Product saved = productService.save(product);
        return ResponseEntity.ok(saved);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() { ... }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProduct(@PathVariable Long id) { ... }

    @PutMapping("/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @RequestBody Product product) { ... }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteProduct(@PathVariable Long id) { ... }
}
```

**作用：** 商品管理的 HTTP 接口层，接收前端请求，返回 JSON 响应。

关键注解说明：

| 注解 | 含义 |
|------|------|
| `@RestController` | 标记为 REST 控制器，方法返回值自动序列化为 JSON |
| `@RequestMapping("/api/products")` | 所有方法的路径前缀 |
| `@CrossOrigin(origins = "*")` | 允许跨域，前端（3000端口）才能访问后端（8080端口） |
| `@PostMapping` | 处理 POST 请求（新增） |
| `@GetMapping` | 处理 GET 请求（查询） |
| `@PutMapping` | 处理 PUT 请求（更新） |
| `@DeleteMapping` | 处理 DELETE 请求（删除） |
| `@RequestBody` | 把请求体 JSON 自动反序列化为 Product 对象 |
| `@PathVariable` | 从 URL 路径中取参数，如 `/api/products/1` 里的 `1` |
| `ResponseEntity` | 带 HTTP 状态码的响应包装器 |

**对外暴露的接口：**

| 请求方式 | 路径 | 功能 |
|---------|------|------|
| POST | /api/products | 新增商品 |
| GET | /api/products | 查询所有商品 |
| GET | /api/products/{id} | 查询单个商品 |
| PUT | /api/products/{id} | 更新商品 |
| DELETE | /api/products/{id} | 删除商品 |

---

### 8. controller/SearchController.java

```java
@RestController
@RequestMapping("/api/search")
@CrossOrigin(origins = "*")
public class SearchController {

    private final SearchService searchService;

    @GetMapping
    public ResponseEntity<List<ProductDocument>> search(@RequestParam String keyword) {
        List<ProductDocument> results = searchService.search(keyword);
        return ResponseEntity.ok(results);
    }

    @GetMapping("/all")
    public ResponseEntity<Iterable<ProductDocument>> getAll() { ... }

    @GetMapping("/count")
    public ResponseEntity<Map<String, Long>> count() { ... }

    @GetMapping("/{id}")
    public ResponseEntity<ProductDocument> getById(@PathVariable Long id) { ... }
}
```

**作用：** 搜索接口层，所有与 ES 搜索相关的请求都走这里。

`@RequestParam String keyword` 表示从 URL 参数中取值，例如 `/api/search?keyword=苹果手机` 会把 `苹果手机` 传入 keyword。

**对外暴露的接口：**

| 请求方式 | 路径 | 功能 |
|---------|------|------|
| GET | /api/search?keyword=xxx | 全文搜索（走 ES） |
| GET | /api/search/all | 查询 ES 所有文档 |
| GET | /api/search/count | 统计 ES 文档数量 |
| GET | /api/search/{id} | 根据 ID 查 ES 文档 |

---

### 9. document/ProductDocument.java

```java
@Data
@Document(indexName = "products")
public class ProductDocument {
    @Id
    private Long id;

    @Field(type = FieldType.Text, analyzer = "ik_max_word", searchAnalyzer = "ik_smart")
    private String name;

    @Field(type = FieldType.Text, analyzer = "ik_max_word", searchAnalyzer = "ik_smart")
    private String description;

    @Field(type = FieldType.Scaled_Float, scalingFactor = 100)
    private BigDecimal price;

    @Field(type = FieldType.Keyword)
    private String category;

    // ETL补全字段
    private String priceRange;    // 价格区间
    private String stockStatus;   // 库存状态
    private Double hotScore;      // 热度评分
    private String statusText;    // 状态文本
}
```

**作用：** ES 文档的映射类，定义了 `products` 索引的字段结构（等同于 MySQL 里的建表语句）。

关键注解说明：

| 注解 | 含义 |
|------|------|
| `@Document(indexName = "products")` | 对应 ES 中的 `products` 索引 |
| `@Field(type = FieldType.Text, analyzer = "ik_max_word")` | 该字段用 IK 细粒度分词存储（建立更多词条索引） |
| `searchAnalyzer = "ik_smart"` | 搜索时用 IK 智能分词（减少无意义词条，提高精度） |
| `@Field(type = FieldType.Keyword)` | 不分词，用于精确过滤（如按分类过滤） |
| `@Field(type = FieldType.Scaled_Float, scalingFactor = 100)` | 高精度浮点数，乘以100后作为整数存储，避免精度问题 |

**与 Product 实体的区别：**
- `Product` → MySQL 表映射，字段少，是原始数据
- `ProductDocument` → ES 文档映射，字段多，包含 ETL 补全的字段

---

### 10. application.yml（backend）

```yaml
server:
  port: 8080

spring:
  datasource:
    url: jdbc:mysql://localhost:3306/demo_db
    username: root
    password: 123456

  jpa:
    hibernate:
      ddl-auto: update    # 启动时自动根据实体类更新表结构（不删数据）
    show-sql: true        # 在控制台打印执行的 SQL

  elasticsearch:
    rest:
      uris: http://127.0.0.1:9200

  rabbitmq:
    host: localhost
    port: 5672
    username: guest
    password: guest

logging:
  level:
    com.example.backend: DEBUG  # 打印 DEBUG 级别日志，方便排查问题
```

**作用：** backend 模块的配置文件，集中管理所有连接参数和行为配置。

`ddl-auto: update` 的含义：启动时检查实体类，如果数据库表不存在就创建，如果字段不一致就更新，但不删除已有数据。

---

## canal-client 模块

> 路径：`d:\data-pipeline-demo\canal-client\src\main\java\com\example\canal\`

### 1. CanalClientApplication.java

```java
@SpringBootApplication
public class CanalClientApplication {
    public static void main(String[] args) {
        SpringApplication.run(CanalClientApplication.class, args);
    }
}
```

**作用：** canal-client 的启动类，端口 8081。

启动后会：
1. 连接 RabbitMQ，开始监听 `canal.queue` 队列
2. 连接 Elasticsearch，准备写入数据

---

### 2. config/RabbitMQConfig.java

```java
@Configuration
public class RabbitMQConfig {

    public static final String QUEUE_NAME = "canal.queue";

    /**
     * 配置消费者监听器容器工厂
     */
    @Bean
    public SimpleRabbitListenerContainerFactory rabbitListenerContainerFactory(ConnectionFactory connectionFactory) {
        SimpleRabbitListenerContainerFactory factory = new SimpleRabbitListenerContainerFactory();
        factory.setConnectionFactory(connectionFactory);
        factory.setAcknowledgeMode(AcknowledgeMode.AUTO);  // 自动确认消费
        factory.setConcurrentConsumers(1);                 // 并发消费者数量
        factory.setMaxConcurrentConsumers(1);              // 最大并发数
        return factory;
    }
}
```

**作用：** RabbitMQ 消费端配置。

**为什么只有这些，没有创建 exchange 和 queue 的代码？**  
因为 canal.exchange 和 canal.queue 是由 Canal Server 负责创建的，canal-client 只需要监听消费即可。如果在这里重复创建 exchange，会因为类型冲突（Canal 用 fanout，Spring 默认用 direct）导致报错。所以这里只配置监听器工厂，不做任何创建操作。

关键配置说明：

| 配置 | 含义 |
|------|------|
| `AcknowledgeMode.AUTO` | 消息消费成功后自动 ACK（告诉 MQ 消息已处理） |
| `setConcurrentConsumers(1)` | 同时只有 1 个消费者线程（保证消息顺序处理） |
| `SimpleRabbitListenerContainerFactory` | 监听器容器工厂，管理 `@RabbitListener` 的创建和运行 |

`QUEUE_NAME` 是常量，定义队列名称。`@RabbitListener` 注解引用这个名字来决定监听哪个队列。

---

### 3. config/ElasticsearchConfig.java

```java
@Configuration
public class ElasticsearchConfig {

    @Value("${elasticsearch.host:127.0.0.1}")
    private String host;

    @Value("${elasticsearch.port:9200}")
    private int port;

    @Bean
    public RestHighLevelClient restHighLevelClient() {
        return new RestHighLevelClient(
                RestClient.builder(new HttpHost(host, port))
        );
    }
}
```

**作用：** 创建 ES 客户端 Bean，供 `ElasticsearchService` 注入使用。

`@Value("${elasticsearch.host:127.0.0.1}")` 的含义：从 `application.yml` 中读取 `elasticsearch.host` 的值，如果没有配置则默认使用 `127.0.0.1`。

`RestHighLevelClient` 是 ES 官方提供的 Java 客户端，支持索引、删除、搜索等所有操作。

---

### 4. mq/CanalMessageConsumer.java

```java
@Slf4j
@Component
@RequiredArgsConstructor
public class CanalMessageConsumer {

    private final ProductETLService productETLService;

    @RabbitListener(queues = "canal.queue", containerFactory = "rabbitListenerContainerFactory")
    public void handleCanalMessage(String message) {
        // 1. 解析 JSON 消息
        JSONObject jsonMessage = JSON.parseObject(message);
        String database = jsonMessage.getString("database");
        String table = jsonMessage.getString("table");
        String type = jsonMessage.getString("type");

        // 2. 只处理 demo_db.product 表
        if (!"demo_db".equals(database) || !"product".equals(table)) {
            return;
        }

        // 3. 根据操作类型分发
        switch (type.toUpperCase()) {
            case "INSERT": handleInsert(jsonMessage); break;
            case "UPDATE": handleUpdate(jsonMessage); break;
            case "DELETE": handleDelete(jsonMessage); break;
        }
    }

    private void handleInsert(JSONObject jsonMessage) {
        // 从 data 数组中取出每一行数据，逐条交给 ETL 处理
        jsonMessage.getJSONArray("data").forEach(item -> {
            Map<String, Object> data = ((JSONObject) item).getInnerMap();
            productETLService.processInsert(data);
        });
    }
    // handleUpdate、handleDelete 同理
}
```

**作用：** RabbitMQ 消息消费者，是整个同步链路的入口。

**Canal 发来的消息长什么样？**

```json
{
  "database": "demo_db",
  "table": "product",
  "type": "INSERT",
  "ts": 1744527234000,
  "data": [
    {
      "id": "5",
      "name": "苹果手机15",
      "price": "9999.00",
      "stock": "100",
      "category": "手机",
      "brand": "苹果",
      "status": "1",
      "created_at": "2026-04-13 20:00:00"
    }
  ]
}
```

注意：Canal 发来的所有字段值都是**字符串类型**，比如 `price` 是 `"9999.00"` 而不是数字 `9999.00`。这就是为什么 ETL 里要做类型转换。

**过滤逻辑：** Canal 会监听所有符合 `filter.regex` 的表变更，但为了安全，消费者代码里再做一次过滤，确保只处理 `demo_db.product` 的变更。

---

### 5. etl/ProductETLService.java

```java
@Slf4j
@Service
@RequiredArgsConstructor
public class ProductETLService {

    private final ElasticsearchService elasticsearchService;
    private static final String INDEX_NAME = "products";

    // 处理新增
    public void processInsert(Map<String, Object> data) {
        Map<String, Object> transformedData = transform(data);  // ETL 转换
        Long id = Long.valueOf(data.get("id").toString());
        elasticsearchService.indexDocument(INDEX_NAME, id, transformedData);  // 写 ES
    }

    // 处理更新（和新增逻辑相同，ES 的 index 操作自动覆盖）
    public void processUpdate(Map<String, Object> data) { ... }

    // 处理删除
    public void processDelete(Map<String, Object> data) {
        Long id = Long.valueOf(data.get("id").toString());
        elasticsearchService.deleteDocument(INDEX_NAME, id);
    }

    /**
     * ETL 核心转换逻辑
     */
    private Map<String, Object> transform(Map<String, Object> source) {
        Map<String, Object> result = new HashMap<>(source);  // 复制原始数据

        // 补全价格区间
        BigDecimal price = new BigDecimal(source.getOrDefault("price", "0").toString());
        result.put("priceRange", calculatePriceRange(price));

        // 补全库存状态
        Integer stock = Integer.valueOf(source.getOrDefault("stock", "0").toString());
        result.put("stockStatus", calculateStockStatus(stock));

        // 补全热度评分
        result.put("hotScore", calculateHotScore(price, stock));

        // 补全状态文本
        Integer status = Integer.valueOf(source.getOrDefault("status", "1").toString());
        result.put("statusText", status == 1 ? "上架" : "下架");

        // 数据清洗：把 price 字符串转成数字
        result.put("price", price.doubleValue());

        return result;
    }

    private String calculatePriceRange(BigDecimal price) {
        double p = price.doubleValue();
        if (p < 100)   return "0-100";
        if (p < 500)   return "100-500";
        if (p < 1000)  return "500-1000";
        return "1000+";
    }

    private String calculateStockStatus(Integer stock) {
        if (stock == null || stock <= 0) return "out_of_stock";  // 缺货
        if (stock < 10)                  return "low_stock";      // 低库存
        return "in_stock";                                        // 库存充足
    }

    private Double calculateHotScore(BigDecimal price, Integer stock) {
        if (stock == null) stock = 0;
        return price.doubleValue() * 0.01 + stock * 0.1;
    }
}
```

**作用：** ETL（Extract 抽取 → Transform 转换 → Load 加载）处理服务，是数据质量的关键环节。

**为什么需要 ETL？**  
Canal 从 MySQL 拿到的是原始数据，缺少搜索需要的衍生字段。ETL 做了两件事：
1. **数据清洗**：把字符串类型的 price 转为数字
2. **字段补全**：根据原始字段计算出额外的业务字段

**补全的字段：**

| 字段 | 来源 | 示例 |
|------|------|------|
| `priceRange` | 根据 price 计算 | price=299 → "100-500" |
| `stockStatus` | 根据 stock 计算 | stock=5 → "low_stock" |
| `hotScore` | price × 0.01 + stock × 0.1 | price=1000, stock=50 → 15.0 |
| `statusText` | 根据 status 翻译 | status=1 → "上架" |

---

### 6. es/ElasticsearchService.java

```java
@Slf4j
@Service
@RequiredArgsConstructor
public class ElasticsearchService {

    private final RestHighLevelClient restHighLevelClient;

    /**
     * 索引文档（新增或覆盖更新）
     */
    public void indexDocument(String indexName, Long id, Map<String, Object> data) {
        IndexRequest request = new IndexRequest(indexName)
                .id(id.toString())   // 文档 ID = 商品 ID
                .source(data);       // 文档内容

        restHighLevelClient.index(request, RequestOptions.DEFAULT);
    }

    /**
     * 删除文档
     */
    public void deleteDocument(String indexName, Long id) {
        DeleteRequest request = new DeleteRequest(indexName, id.toString());
        restHighLevelClient.delete(request, RequestOptions.DEFAULT);
    }
}
```

**作用：** 封装所有对 Elasticsearch 的底层操作，使用 `RestHighLevelClient` 直接发 HTTP 请求到 ES。

`IndexRequest` 就是 ES 的"写入/更新文档"请求。当同一个 id 的文档已经存在时，ES 会直接覆盖（相当于 upsert 操作），所以新增和更新用的是同一个方法。

`DeleteRequest` 就是 ES 的"删除文档"请求，根据 id 删除指定文档。

---

### 7. application.yml（canal-client）

```yaml
server:
  port: 8081

spring:
  rabbitmq:
    host: localhost
    port: 5672
    username: guest
    password: guest
    listener:
      simple:
        acknowledge-mode: auto   # 消息消费成功后自动 ACK
        concurrency: 1           # 并发消费者数量
        max-concurrency: 1       # 最大并发数

elasticsearch:
  host: 127.0.0.1
  port: 9200

logging:
  level:
    com.example.canal: DEBUG
```

**作用：** canal-client 模块的配置。

注意：这里 ES 的配置写在根级别（`elasticsearch:`），而不是 `spring.elasticsearch:`，这是因为 canal-client 用的是原生的 `RestHighLevelClient`，通过 `@Value` 读取自定义配置，而不是 Spring Data ES 的自动配置。

---

## 数据流转路径 — 写入链路

以"前端添加一个商品"为例，完整的函数调用链如下：

### 第一段：前端 → MySQL

```
① 前端 Vue 发送 HTTP POST 请求
   POST http://localhost:8080/api/products
   Body: { "name": "苹果15", "price": 9999, "stock": 100, "category": "手机", "brand": "苹果" }

② ProductController.createProduct(@RequestBody Product product)
   接收 JSON，自动反序列化为 Product 对象

③ ProductService.save(product)
   调用 Repository 保存

④ ProductRepository.save(product)
   Spring Data JPA 自动生成 SQL，执行写入：
   INSERT INTO product (name, price, stock, ...) VALUES (...)

⑤ MySQL 写入成功，product 表新增一行
   同时 MySQL binlog（二进制日志）记录这次 INSERT 操作
```

### 第二段：MySQL → RabbitMQ（由 Canal 完成）

```
⑥ Canal Server（后台运行）伪装成 MySQL 从库，实时读取 binlog
   发现 demo_db.product 表发生 INSERT 操作

⑦ Canal 把变更内容序列化为 JSON（FlatMessage 格式）：
   {
     "database": "demo_db",
     "table": "product",
     "type": "INSERT",
     "data": [{"id": "5", "name": "苹果15", "price": "9999.00", ...}]
   }

⑧ Canal 将 JSON 消息发送到 RabbitMQ
   发送目标：canal.exchange（fanout 类型）
   
⑨ RabbitMQ 的 fanout exchange 把消息广播给所有绑定的队列
   消息进入 canal.queue
```

### 第三段：RabbitMQ → Elasticsearch（canal-client 完成）

```
⑩ CanalMessageConsumer.handleCanalMessage(String message)
   @RabbitListener 监听到 canal.queue 有新消息

⑪ 解析 JSON，提取 database="demo_db", table="product", type="INSERT"
   校验：只处理 demo_db.product 的变更

⑫ switch(type) → 路由到 handleInsert(jsonMessage)

⑬ 遍历 data 数组，对每行数据调用：
   ProductETLService.processInsert(data)

⑭ ProductETLService.transform(data)
   对原始数据进行 ETL 转换：
   - price "9999.00"（字符串）→ 9999.0（double）
   - priceRange 补全：9999 > 1000 → "1000+"
   - stockStatus 补全：stock=100 → "in_stock"
   - hotScore 计算：9999 × 0.01 + 100 × 0.1 = 109.99
   - statusText 补全：status=1 → "上架"

⑮ ElasticsearchService.indexDocument("products", 5L, transformedData)
   构建 IndexRequest，通过 RestHighLevelClient 发送 HTTP 请求到 ES：
   PUT http://localhost:9200/products/_doc/5
   Body: { "name": "苹果15", "price": 9999.0, "priceRange": "1000+", ... }

⑯ Elasticsearch 索引文档，写入完成
   商品可被搜索到
```

---

## 数据流转路径 — 查询链路

以"前端搜索'苹果手机'"为例：

```
① 前端 Vue 发送 HTTP GET 请求
   GET http://localhost:8080/api/search?keyword=苹果手机

② SearchController.search(@RequestParam String keyword)
   接收 keyword="苹果手机"

③ SearchService.search("苹果手机")
   构建搜索条件：
   Criteria criteria = new Criteria("name").contains("苹果手机")
                        .or(new Criteria("description").contains("苹果手机"))

④ elasticsearchOperations.search(query, ProductDocument.class)
   把条件转换为 ES DSL 查询语句，发送给 ES

⑤ Elasticsearch 用 IK 分词器对"苹果手机"分词：
   → ["苹果", "手机", "苹果手机"]
   在 products 索引的 name、description 字段中搜索包含以上词条的文档

⑥ ES 返回匹配的文档列表（按相关度评分排序）

⑦ SearchService 提取 SearchHits 中的内容，转换为 List<ProductDocument>

⑧ SearchController 包装为 ResponseEntity，返回 JSON 给前端

⑨ 前端渲染搜索结果
```

---

## 中间件说明

### Canal Server

- **本质：** 伪装成 MySQL 的从库（Slave），通过 MySQL 的主从复制协议实时获取 binlog
- **关键配置文件：** `canal.deployer-1.1.8.tar\canal.deployer-1.1.8\conf\`
  - `canal.properties`：全局配置（serverMode=rabbitmq、RabbitMQ 连接信息）
  - `example/instance.properties`：实例配置（MySQL 连接、订阅哪张表）
- **订阅过滤：** `canal.instance.filter.regex=demo_db\\.product`（只监听这张表）
- **消息格式：** FlatMessage（JSON 扁平格式），每个字段值都是字符串

### RabbitMQ

- **canal.exchange：** fanout 类型，Canal Server 创建并管理，消息广播给所有绑定的队列
- **canal.queue：** 持久化队列，canal-client 消费这里的消息
- **绑定关系：** canal.exchange → canal.queue（routing key 为空，因为 fanout 不需要）
- **注意：** exchange 和 queue 由 Canal 自动创建，绑定需要手动在管理界面操作一次

### Elasticsearch

- **索引名：** `products`
- **分词器：** IK（ik_max_word 存储时细分，ik_smart 搜索时智能分词）
- **文档 ID：** 使用商品的 MySQL 主键 ID，保证一一对应

---

*文档最后更新：2026-04-14*
